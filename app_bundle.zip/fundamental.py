"""Fundamental & Quality Agent - free-data business quality and valuation.

Primary data path (works even when Yahoo's `.info` is crumb-blocked):
  - yfinance fast_info  -> market cap
  - quarterly income stmt -> revenue / net income TTM + YoY, margins
  - quarterly balance sheet -> debt, equity -> D/E, ROE
  - quarterly cash flow -> free cash flow

Enrichment path (opportunistic, may be unavailable):
  - yfinance `.info` -> PE, insider holding (promoter proxy), growth fields

Valuation vs peers: PE/PB of the shortlist are compared against the median of
the *same industry group* within the analysed pool (never invented numbers).
"""
from __future__ import annotations

import numpy as np

from agents.base import BaseAgent
from core.models import Q_DEGRADED, Q_OK, Q_UNAVAILABLE, verdict_from_score
from utils.helpers import clamp, r2


class FundamentalAgent(BaseAgent):
    name = "Fundamental & Quality Agent"
    description = "Results, balance sheet, valuation vs peers (free data only)"

    def analyze(self, symbol: str, fund: dict, info: dict,
                peer_stats: dict) -> "AgentReport":  # noqa: F821
        try:
            return self._analyze(symbol, fund, info, peer_stats)
        except Exception as e:  # noqa: BLE001
            return self.fallback(symbol, why=str(e))

    # ------------------------------------------------------------------
    def _analyze(self, symbol, fund, info, peer_stats):
        if not fund and not info:
            return self.report(
                verdict="UNAVAILABLE", score=None, confidence=0.0,
                data_quality=Q_UNAVAILABLE,
                key_points=["No free fundamental data available for this symbol right now."],
                risks=["Fundamental quality unknown - conviction must be capped."],
                details={}, symbol=symbol)

        g = lambda k, d=None: (fund or {}).get(k, d)  # noqa: E731
        ig = lambda k, d=None: (info or {}).get(k, d)  # noqa: E731

        roe = g("roe")
        if roe is None and ig("returnOnEquity") is not None:
            roe = ig("returnOnEquity") * 100
        de = g("de_ratio")
        if de is None and ig("debtToEquity") is not None:
            de = ig("debtToEquity") / 100.0
        margin = g("margin_ttm")
        if margin is None and ig("profitMargins") is not None:
            margin = ig("profitMargins") * 100
        rev_g = g("rev_yoy")
        if rev_g is None and ig("revenueGrowth") is not None:
            rev_g = ig("revenueGrowth") * 100
        ni_g = g("ni_yoy")
        if ni_g is None and ig("earningsGrowth") is not None:
            ni_g = ig("earningsGrowth") * 100
        fcf = g("fcf_ttm")
        pe = ig("trailingPE") or g("pe")
        pb = g("pb")
        insiders = ig("heldPercentInsiders")          # proxy for promoter holding
        industry = ig("industry") or "Unknown"

        # ---------------- profitability (30) ------------------------------
        prof = 0.0
        if roe is not None:
            if roe >= 20: prof += 12
            elif roe >= 15: prof += 9
            elif roe >= 10: prof += 6
            elif roe > 0: prof += 2
        if margin is not None:
            if margin >= 15: prof += 10
            elif margin >= 8: prof += 7
            elif margin >= 3: prof += 4
            elif margin > 0: prof += 1
        if fcf is not None:
            prof += 8 if fcf > 0 else 0

        # ---------------- growth (25) --------------------------------------
        gro = 0.0
        for v, w in ((rev_g, 12), (ni_g, 13)):
            if v is None:
                continue
            if v >= 20: gro += w
            elif v >= 10: gro += w * 0.75
            elif v >= 0: gro += w * 0.45
            elif v >= -10: gro += w * 0.15

        # ---------------- balance sheet (25) --------------------------------
        bal = 0.0
        if de is not None:
            if de <= 0.5: bal += 12
            elif de <= 1.0: bal += 10
            elif de <= 2.0: bal += 6
            elif de <= 3.0: bal += 3
        if insiders is not None:
            bal += 5 if insiders >= 45 else (3 if insiders >= 25 else 1)
        else:
            bal += 2  # unknown -> neutral nudge, disclosed in details

        # ---------------- valuation vs peers (20) ----------------------------
        val = 0.0
        val_method = "absolute bands"
        peer_pe = (peer_stats or {}).get("pe_median")
        n_peers = (peer_stats or {}).get("n", 0)
        if pe is not None and peer_pe and n_peers >= 2:
            ratio = pe / peer_pe
            val_method = f"vs industry median PE {peer_pe:.1f} (n={n_peers})"
            if ratio <= 0.8: val += 10
            elif ratio <= 1.1: val += 8
            elif ratio <= 1.5: val += 5
            elif ratio <= 2.0: val += 2
        elif pe is not None:
            if pe <= 25: val += 10
            elif pe <= 35: val += 7
            elif pe <= 50: val += 4
            else: val += 1
        # rich P/B gets a small haircut for financials-neutral fairness
        if pb is not None:
            if pb <= 3: val += 4
            elif pb <= 6: val += 2
        else:
            val += 2
        fpe = ig("forwardPE")
        if fpe is not None and pe is not None and fpe < pe * 0.9:
            val += 6  # visible earnings growth ahead
        elif fpe is not None:
            val += 3

        score = clamp(prof + gro + bal + val, 0, 100)
        verdict = verdict_from_score(score)

        # red flags -----------------------------------------------------------
        flags = []
        if de is not None and de > 2.5:
            flags.append(f"High leverage: D/E {de:.2f}")
        if margin is not None and margin < 0:
            flags.append("Negative operating margins (TTM)")
        if ni_g is not None and ni_g < -20:
            flags.append(f"Net income down {abs(ni_g):.0f}% YoY")
        if fcf is not None and fcf < 0:
            flags.append("Negative free cash flow (TTM)")

        q = Q_OK if (info and fund) else (Q_DEGRADED if (info or fund) else Q_UNAVAILABLE)
        conf = clamp(55 + (15 if fund else 0) + (10 if info else 0)
                     + (5 if fund.get("quarters_covered", 0) >= 5 else 0), 20, 85)

        def fmt(x, suf=""):
            return "-" if x is None else f"{x:,.1f}{suf}"

        kps = [
            f"TTM revenue growth {fmt(rev_g, '%')} | net income growth {fmt(ni_g, '%')} | margin {fmt(margin, '%')}",
            f"ROE {fmt(roe, '%')} | D/E {fmt(de)} | FCF(TTM) {'positive' if (fcf or 0) > 0 else 'negative/na'}",
            f"PE {fmt(pe)} | PB {fmt(pb)} ({val_method})",
            f"Insider/promoter holding proxy: {fmt(insiders, '%') if insiders is not None else 'unavailable (free-source limitation)'}",
        ]
        risks = flags + [
            "Quarterly-statement data can lag; verify latest results before acting",
        ]
        if not info:
            risks.append("Yahoo `.info` unavailable on this network - derived metrics only")
        details = {
            "roe_pct": r2(roe), "de_ratio": r2(de), "margin_ttm_pct": r2(margin),
            "rev_yoy_pct": r2(rev_g), "ni_yoy_pct": r2(ni_g), "fcf_ttm": None if fcf is None else r2(fcf),
            "pe": r2(pe), "pb": r2(pb), "forward_pe": r2(fpe) if fpe is not None else None,
            "insider_holding_pct": r2(insiders) if insiders is not None else None,
            "industry": industry, "valuation_method": val_method,
            "subscores": {"profitability(30)": r2(prof), "growth(25)": r2(gro),
                          "balance_sheet(25)": r2(bal), "valuation(20)": r2(val)},
            "quarters_covered": fund.get("quarters_covered"),
        }
        return self.report(verdict=verdict, score=score, confidence=conf,
                           data_quality=q, key_points=kps, risks=risks,
                           details=details, symbol=symbol)


def build_peer_stats(infos: dict[str, dict], fundas: dict[str, dict]) -> dict:
    """Median PE/PB per industry across the deep-dive pool (never fabricated)."""
    by_ind: dict[str, dict[str, list]] = {}
    for sym, info in (infos or {}).items():
        ind = (info or {}).get("industry") or "Unknown"
        f = fundas.get(sym, {})
        pe = (info or {}).get("trailingPE") or f.get("pe")
        pb = f.get("pb")
        slot = by_ind.setdefault(ind, {"pe": [], "pb": []})
        if pe:
            slot["pe"].append(float(pe))
        if pb:
            slot["pb"].append(float(pb))
    return {
        "industries": {
            k: {"pe_median": float(np.median(v["pe"])) if v["pe"] else None,
                "pb_median": float(np.median(v["pb"])) if v["pb"] else None,
                "n": max(len(v["pe"]), len(v["pb"]))}
            for k, v in by_ind.items()
        }
    }
