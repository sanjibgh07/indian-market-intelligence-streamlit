"""Research orchestrator - runs the full multi-agent pipeline.

Pipeline stages (each stage is failure-isolated; a broken source degrades a
report's data_quality instead of crashing the run):

  1. DATA      batch price download (universe + Nifty + VIX + macro tickers)
  2. SCREEN    liquidity filter + Technical Agent on every usable symbol
  3. MACRO     FII/DII + macro snapshot -> Macro Agent; breadth -> Regime Agent
  4. DEEP      fundamentals + news + Risk Agent on the shortlist
  5. MOTHER    Mother Agent cross-verification, vetoes, final 0-2 picks
  6. REPORT    markdown research report

The `progress` callback lets the Streamlit app render per-stage status:
    progress(stage_key, stage_label, percent, message)
"""
from __future__ import annotations

import time

import numpy as np
import pandas as pd

from agents.fundamental import FundamentalAgent, build_peer_stats
from agents.macro import MacroAgent
from agents.mother import MotherAgent
from agents.news import NewsAgent
from agents.regime import RegimeAgent
from agents.risk import RiskAgent
from agents.technical import TechnicalAgent
from analysis import indicators as ta
from config.settings import SECTOR_INDEX_MAP, universe_for_scope
from core.models import Candidate, MarketContext, ResearchResult
from data import demo as demo_data
from data import nse_client, news_client, yf_client
from data.macro_client import (fetch_macro_snapshot, fetch_nifty_history,
                               fetch_vix_history)
from engine.report import build_markdown
from utils.helpers import ist_stamp


class ResearchOrchestrator:
    def __init__(self, cfg, log=print):
        self.cfg = cfg
        self.log = log
        self.notes: list[str] = []

    def note(self, msg: str):
        self.notes.append(msg)
        self.log(f"[orchestrator] {msg}")

    # ------------------------------------------------------------------
    def run(self, progress=None) -> ResearchResult:
        cfg = self.cfg
        P = progress or (lambda *a, **k: None)
        result = ResearchResult(
            as_of=ist_stamp(), mode="DEMO" if cfg.demo else "LIVE",
            config_summary=cfg.summary(), data_notes=self.notes)

        # ---------------- stage 1: data ----------------------------------
        P("data", "Stage 1/6 - Market data", 4,
          "Downloading Nifty, VIX, macro tickers and universe prices (free sources)...")
        if cfg.demo:
            self.note("DEMO MODE: all data below is synthetic and clearly labelled.")
        universe = universe_for_scope(cfg)
        symbols = [s for s, _, _ in universe]
        meta = {s: (n, sec) for s, n, sec in universe}

        nifty_df = (demo_data.synth_prices("NIFTY", drift_bias=0.30, base=24000.0,
                                           vol_override=0.16)
                    if cfg.demo else fetch_nifty_history("1y"))
        vix_s = demo_data.synth_vix() if cfg.demo else fetch_vix_history("6mo")
        vix_close = float(vix_s.iloc[-1]) if vix_s is not None and len(vix_s) else None
        if nifty_df is None or len(nifty_df) < 60:
            self.note("Nifty history unavailable - regime agent will be degraded.")
            nifty_df = nifty_df or pd.DataFrame()

        if cfg.demo:
            prices = {s: demo_data.synth_prices(s, drift_bias=0.35 if i % 3 == 0 else 0.0)
                      for i, s in enumerate(symbols)}
        else:
            prices = yf_client.download_prices(symbols, cfg.period, log=self.log)

        usable: dict[str, pd.DataFrame] = {}
        for sym, df in prices.items():
            if df is None or len(df) < cfg.min_rows:
                continue
            adv = ta.avg_daily_turnover_cr(df, 20)
            if adv == adv and adv >= cfg.adv_min_cr:
                usable[sym] = df
        if cfg.demo:
            usable = prices  # demo data already liquid-ish
        result.universe_scanned = len(universe)
        result.universe_usable = len(usable)
        P("data", "Stage 1/6 - Market data", 14,
          f"Usable symbols after data/liquidity filter: {len(usable)}/{len(universe)}")

        macro_raw = demo_data.synth_macro_snapshot() if cfg.demo else fetch_macro_snapshot(SECTOR_INDEX_MAP, log=self.log)

        # ---------------- stage 2: technical screen ------------------------
        P("screen", "Stage 2/6 - Technical screening", 18,
          f"Scoring {len(usable)} symbols on trend/momentum/structure/volume...")
        tech_agent = TechnicalAgent()
        tech_reports = {}
        for i, (sym, df) in enumerate(usable.items()):
            tech_reports[sym] = tech_agent.analyze(sym, meta.get(sym, (sym, ""))[0],
                                                   df, nifty_df["Close"] if len(nifty_df) else None)
            if (i + 1) % 25 == 0:
                P("screen", "Stage 2/6 - Technical screening",
                  18 + int(16 * (i + 1) / max(len(usable), 1)),
                  f"Screened {i + 1}/{len(usable)} symbols")
        ranked = sorted(((sym, r.score) for sym, r in tech_reports.items()
                         if r.score is not None), key=lambda x: x[1], reverse=True)
        shortlist = [s for s, _ in ranked[: cfg.shortlist_size]]
        result.shortlist = shortlist
        P("screen", "Stage 2/6 - Technical screening", 34,
          f"Shortlist for deep dive: {', '.join(shortlist) if shortlist else 'none'}")

        # ---------------- stage 3: macro & regime ---------------------------
        P("macro", "Stage 3/6 - Macro & Regime", 36, "FII/DII flows, currency, crude, VIX, sectors...")
        fii_rows = demo_data.synth_fii_dii(cfg.fii_sessions) if cfg.demo else nse_client.fetch_fii_dii(cfg.fii_sessions, log=self.log)
        if not fii_rows:
            self.note("FII/DII flows unavailable from free NSE endpoints on this network "
                      "- macro agent uses a neutral, disclosed assumption.")
        nifty_ret20 = None
        if len(nifty_df) > 21:
            nifty_ret20 = float(nifty_df["Close"].iloc[-1] / nifty_df["Close"].iloc[-21] - 1) * 100

        macro_agent = MacroAgent()
        macro_report = macro_agent.analyze(macro_raw, fii_rows, nifty_ret20)
        P("macro", "Stage 3/6 - Macro & Regime", 42, "Computing breadth and regime classification...")
        breadth = self._breadth(usable)
        mnews = demo_data.synth_market_news() if cfg.demo else news_client.fetch_market_news(log=self.log)
        mood = NewsAgent().analyze_market(mnews)
        regime_agent = RegimeAgent()
        regime_report = regime_agent.analyze(
            nifty_df, vix_close, breadth,
            macro_report.score if macro_report else None,
            (sum((r.get("fii_net") or 0.0) for r in fii_rows[:5]) if fii_rows else None),
            mood.get("mood"))
        market = MarketContext(regime=regime_report, macro=macro_report,
                               breadth=breadth, nifty_history=nifty_df)
        market.nifty = regime_report.details.get("levels", {}) if regime_report else {}
        market.nifty["scenarios"] = regime_report.details.get("scenarios", {}) if regime_report else {}
        market.outlook_text = regime_report.details.get("outlook_text", "") if regime_report else ""
        result.market = market
        regime_name = regime_report.details.get("regime", "UNKNOWN") if regime_report else "UNKNOWN"
        P("macro", "Stage 3/6 - Macro & Regime", 46,
          f"Regime: {regime_name} | Macro score: {macro_report.score if macro_report else 'n/a'}")

        # ---------------- stage 4: deep dive --------------------------------
        P("deep", "Stage 4/6 - Deep dive", 48,
          f"Fundamentals, news and risk for {len(shortlist)} shortlisted names...")
        fund_agent, news_agent, risk_agent = FundamentalAgent(), NewsAgent(), RiskAgent()
        infos: dict[str, dict] = {}
        fundas: dict[str, dict] = {}
        candidates: list[Candidate] = []

        tailwind_fn = macro_agent.sector_tailwind
        for i, sym in enumerate(shortlist):
            name, sector = meta.get(sym, (sym, "UNKNOWN"))
            df = usable[sym]
            spot = float(df["Close"].iloc[-1])
            pct = 48 + int(30 * (i + 1) / max(len(shortlist), 1))
            P("deep", "Stage 4/6 - Deep dive", pct, f"[{i + 1}/{len(shortlist)}] {name} ({sym})...")

            if cfg.demo:
                f_data, info = demo_data.synth_fundamentals(sym), demo_data.synth_info(sym)
            else:
                f_data = yf_client.fetch_quarterly_fundamentals(sym, log=self.log)
                time.sleep(cfg.request_pause)
                info = yf_client.fetch_info(sym, log=self.log)
                if info:
                    time.sleep(cfg.request_pause)
            infos[sym], fundas[sym] = info, f_data

            articles = (demo_data.synth_symbol_news(sym, name, cfg.news_days) if cfg.demo
                        else news_client.fetch_symbol_news(sym, name, cfg.news_days,
                                                           cfg.news_max_per_symbol, log=self.log))
            peer = self._peer_stats_for(sym, info, infos, fundas)
            cand = Candidate(symbol=sym, name=name, sector=sector, spot=spot)
            cand.tech = tech_reports.get(sym)
            cand.fund = fund_agent.analyze(sym, f_data, info, peer)
            cand.news = news_agent.analyze_symbol(sym, articles)
            cand.risk = risk_agent.analyze(sym, df, nifty_df["Close"] if len(nifty_df) else None,
                                           spot, cfg.adv_min_cr, cfg.capital,
                                           cfg.risk_per_trade_pct, cfg.max_position_pct)
            cand.sector_tailwind = tailwind_fn(sector, macro_report.details if macro_report else None)
            candidates.append(cand)

        result.candidates = candidates
        P("deep", "Stage 4/6 - Deep dive", 78,
          f"Deep dive complete for {len(candidates)} candidates")

        # ---------------- stage 5: mother agent ------------------------------
        P("mother", "Stage 5/6 - Mother Agent", 82,
          "Cross-verifying reports, applying risk filters, selecting 0-2 ideas...")
        mother = MotherAgent()
        picks, rejected, final_text, overall_conf = mother.decide(candidates, market, cfg)
        result.picks = picks
        result.rejected = rejected
        result.final_text = final_text
        P("mother", "Stage 5/6 - Mother Agent", 92,
          (f"{len(picks)} pick(s): " + ", ".join(c.symbol for c in picks))
          if picks else "No high-conviction idea this week")

        # ---------------- stage 6: report --------------------------------------
        P("report", "Stage 6/6 - Report", 94, "Compiling the research report...")
        result.data_notes = list(self.notes)
        result.report_md = build_markdown(result, cfg)
        P("report", "Stage 6/6 - Report", 100, "Research run complete.")
        return result

    # ------------------------------------------------------------------
    def _breadth(self, usable: dict[str, pd.DataFrame]) -> dict:
        closes = {s: df["Close"] for s, df in usable.items()}
        b50 = ta.pct_above_ma(closes, 50)
        b200 = ta.pct_above_ma(closes, 200)
        highs, lows = ta.new_highs_lows(closes, 20)
        adv = sum(1 for s, df in usable.items()
                  if len(df) > 21 and df["Close"].iloc[-1] > df["Close"].iloc[-21])
        return {
            "pct_above_50dma": float(b50) if b50 == b50 else 50.0,
            "pct_above_200dma": float(b200) if b200 == b200 else 50.0,
            "new_20d_highs": highs, "new_20d_lows": lows,
            "pct_up_20d": 100.0 * adv / max(len(usable), 1),
            "n_stocks": len(usable),
        }

    def _peer_stats_for(self, sym, info, infos, fundas) -> dict:
        """Median PE of same-industry members already fetched (honest, limited)."""
        ind = (info or {}).get("industry")
        if not ind:
            return {}
        pes = []
        for s2, i2 in infos.items():
            if s2 == sym or (i2 or {}).get("industry") != ind:
                continue
            f2 = fundas.get(s2, {})
            pe = (i2 or {}).get("trailingPE") or f2.get("pe")
            if pe:
                pes.append(float(pe))
        if len(pes) < 2:
            return {}
        return {"pe_median": float(np.median(pes)), "n": len(pes)}
