"""Smoke test: run the full pipeline end-to-end and print the final verdict.

Usage:
    python tests/smoke_test.py --demo                 # fast, synthetic data
    python tests/smoke_test.py --live --tiny          # real data, 8-symbol universe
    python tests/smoke_test.py --live --save out.md   # real data, full universe + save
"""
from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config.settings import Config          # noqa: E402
from engine.orchestrator import ResearchOrchestrator  # noqa: E402
from data import yf_client                  # noqa: E402

TINY_UNIVERSE = "RELIANCE, HDFCBANK, INFY, TATASTEEL, BEL, DLF, TATAPOWER, TITAN"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--demo", action="store_true", help="synthetic data, offline")
    ap.add_argument("--live", action="store_true", help="real free data")
    ap.add_argument("--tiny", action="store_true", help="small universe for speed")
    ap.add_argument("--save", default="", help="save report markdown to this path")
    args = ap.parse_args()

    demo = args.demo or not args.live
    cfg = Config(demo=demo)
    if args.tiny:
        cfg.scope = "CUSTOM"
        cfg.custom_symbols = TINY_UNIVERSE
        cfg.shortlist_size = 6

    if not demo:
        # make sure the per-symbol fallback knows the window
        yf_client.set_period_for_fallback(cfg.period)

    print(f"=== Multi-agent research run | mode={'DEMO' if demo else 'LIVE'} ===")
    last_stage = [""]

    def progress(stage_key, stage_label, pct, msg):
        if stage_key != last_stage[0]:
            print(f"\n--- {stage_label} ---")
            last_stage[0] = stage_key
        print(f"  [{pct:3d}%] {msg}")

    result = ResearchOrchestrator(cfg, log=lambda *a: None).run(progress)

    print("\n" + "=" * 78)
    print("FINAL OUTPUT (Mother Agent)")
    print("=" * 78)
    print(result.final_text)

    print("\n--- scoreboard ---")
    for c in sorted(result.candidates, key=lambda x: -x.composite):
        print(f"  {c.symbol:<12} composite={c.composite:5.1f} "
              f"tech={c.tech.score if c.tech else '-'} "
              f"fund={c.fund.score if c.fund else '-'} "
              f"news={c.news.score if c.news else '-'} "
              f"risk={c.risk.score if c.risk else '-'} "
              f"{'PICK' if c in result.picks else ('REJ: ' + c.reject_reason[:50])}")

    if args.save:
        os.makedirs(os.path.dirname(os.path.abspath(args.save)), exist_ok=True)
        with open(args.save, "w", encoding="utf-8") as f:
            f.write(result.report_md)
        print(f"\nReport saved to {args.save} ({len(result.report_md)} chars)")

    print("\nSMOKE TEST " + ("PASS" if result.final_text else "FAIL"))
    return 0 if result.final_text else 1


if __name__ == "__main__":
    raise SystemExit(main())
