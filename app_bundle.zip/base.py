"""Base class shared by all specialist agents."""
from __future__ import annotations

from core.models import AgentReport
from utils.helpers import ist_stamp


class BaseAgent:
    """Common plumbing: name, report construction, IST stamping."""

    name: str = "BaseAgent"
    description: str = ""

    def report(self, *, verdict: str, score: float | None, confidence: float,
               data_quality: str, key_points: list[str], risks: list[str],
               details: dict, symbol: str | None = None) -> AgentReport:
        return AgentReport(
            agent_name=self.name,
            verdict=verdict,
            score=None if score is None else round(float(score), 1),
            confidence=round(float(confidence), 1),
            data_quality=data_quality,
            key_points=key_points,
            risks=risks,
            details=details,
            symbol=symbol,
            as_of=ist_stamp(),
        )

    def fallback(self, symbol: str | None = None, why: str = "analysis failed") -> AgentReport:
        """Safe neutral report used whenever the agent itself errors out."""
        print(f"[agent-fallback] {self.name}{'' if not symbol else ' (' + symbol + ')'}: {why}")
        return self.report(
            verdict="UNAVAILABLE", score=None, confidence=0.0,
            data_quality="UNAVAILABLE",
            key_points=[f"Agent could not produce an analysis ({why})."],
            risks=["Decision made without this agent's input - treat as degraded."],
            details={"error": why}, symbol=symbol,
        )
