#!/usr/bin/env bash
# Convenience launcher - Indian Equity Multi-Agent Research System
set -e
cd "$(dirname "$0")"

if [ ! -d ".venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv .venv
    source .venv/bin/activate
    pip install -r requirements.txt
else
    source .venv/bin/activate
fi

echo "Starting Streamlit app: http://localhost:8501"
streamlit run app.py
