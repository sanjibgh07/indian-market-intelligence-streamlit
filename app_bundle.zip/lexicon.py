"""Keyword lexicon for free-RSS financial news sentiment.

Simple, transparent, auditable: substring matching with a hand-built finance
lexicon. Not transformer-grade, but deterministic, free and good enough to
flag the tone of headlines for a 1-4 week decision.
"""
from __future__ import annotations

# Positive tone phrases (lowercase substrings)
POSITIVE = [
    "upgrade", "raises target", "raise target", "buy rating", "overweight",
    "outperform", "beats estimates", "beats expectations", "profit surges",
    "profit jumps", "profit rises", "net profit up", "revenue up", "record profit",
    "record quarter", "strong quarter", "strong results", "beats street",
    "order win", "order wins", "wins order", "bags order", "secures order",
    "new order", "large order", "approval", "usfda nod", "usfda approval",
    "dividend", "bonus issue", "buyback", "expansion", "capacity expansion",
    "joint venture", "acquisition", "stake in", "partnership", "rally",
    "surge", "jumps", "hits 52-week high", "all-time high", "all time high",
    "inflow", "upgraded to buy", "initiates coverage with buy", "top pick",
    "multibagger", "brokerages bullish", "bullish", "margin expansion",
    "margin improves", "demand recovery", "price hike", "rate cut", "rate-cut",
    "stimulus", "boost", "growth outlook raised", "guidance raised",
]

# Negative tone phrases
NEGATIVE = [
    "downgrade", "sell rating", "underweight", "underperform",
    "misses estimates", "misses expectations", "profit falls", "profit drops",
    "profit slumps", "profit declines", "net profit down", "revenue down",
    "weak quarter", "weak results", "loss widens", "posts loss", "cuts guidance",
    "cuts target", "trim target", "profit warning", "demand slowdown",
    "slowdown", "slump", "plunge", "tumbles", "falls", "slides", "drops",
    "hits 52-week low", "outflow", "stake sale", "block deal sell",
    "resign", "steps down", "quit", "penalty", "fine of", "tax demand",
    "gst notice", "probe", "investigation", "raid", "lawsuit", "court",
    "recall", "dispute", "delay in", "deferred", "margin pressure",
    "cost pressure", "headwinds", "caution", "drag", "bearish", "warning",
    "cut forecasts", "cut estimates", "below estimates", "valuation rich",
    "expensive valuation", "downgraded to sell", "reduce",
]

# Hard red flags: any hit means the News Agent vetoes the idea for the
# Mother Agent (fundamental-integrity events are not tradable risks).
RED_FLAGS = [
    "fraud", "scam", "sebi bans", "sebi bar", "sebi order against",
    "arrest", "arrested", "auditor resign", "cfo resign", "cfo quits",
    " Hindenburg", "short seller attack", "default on", "defaults on",
    "insolvency", "bankruptcy", "nclt insolvency", "pledge",
    "promoter pledge", "accounting irregular", "money laundering",
    "enforcement directorate", "ed summons", "class action",
    "delisting notice", "suspended from trading",
]

# Softer warnings that lower the score but do not veto.
WARNINGS = [
    "downgrade", "sell rating", "profit warning", "stake sale",
    "penalty", "probe", "investigation", "tax demand", "resign",
    "margin pressure", "demand slowdown",
]


def score_headlines(headlines: list[str]) -> dict:
    """Score a list of headline strings.

    Returns dict with:
      net          : weighted (pos - neg) hits
      pos, neg     : total hits
      n            : number of headlines
      tone         : 0-100 score (50 = neutral)
      flags        : red-flag phrases found
      warnings     : warning phrases found
    """
    pos = neg = 0
    flags: list[str] = []
    warns: list[str] = []
    for text in headlines:
        t = f" {text.lower()} "
        p = sum(1 for w in POSITIVE if w in t)
        n = sum(1 for w in NEGATIVE if w in t)
        pos += p
        neg += n
        for f in RED_FLAGS:
            if f.strip() and f.lower() in t:
                flags.append(f.strip())
        for w in WARNINGS:
            if w in t:
                warns.append(w)
    n_heads = max(len(headlines), 1)
    net = pos - neg
    # tanh squashing keeps the score bounded and coverage-aware
    import math
    tone = 50.0 + 50.0 * math.tanh(net / max(2.0, math.sqrt(n_heads)))
    tone = max(0.0, min(100.0, tone))
    return {
        "net": net, "pos": pos, "neg": neg, "n": len(headlines),
        "tone": tone,
        "flags": sorted(set(flags)),
        "warnings": sorted(set(warns)),
    }
