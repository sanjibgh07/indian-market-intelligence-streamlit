"""Free macro data via Yahoo tickers: USD/INR, Brent crude, S&P 500, India VIX
and NSE sector indices. All public, all free.
"""
from __future__ import annotations

import pandas as pd

from config.settings import SECTOR_INDEX_MAP
from utils.helpers import CACHE, cached, safe_call
from data.yf_client import _clean, NIFTY, INDIA_VIX

MACRO_TICKERS = {
    "usdinr": ["INR=X", "USDINR=X"],     # first available wins
    "crude":  ["BZ=F", "CL=F"],          # Brent preferred, WTI fallback
    "spx":    ["^GSPC"],
    "vix":    ["^INDIAVIX"],
}


def _series(symbol: str, period: str = "6mo") -> pd.Series:
    def _p():
        import yfinance as yf
        df = yf.download(symbol, period=period, interval="1d",
                         auto_adjust=True, progress=False)
        df = _clean(df)
        if df is None or len(df) == 0:
            return None
        return df["Close"].dropna()
    return cached(f"macro|{symbol}|{period}", lambda: safe_call(_p, default=None, label=f"macro {symbol}"), cache=CACHE)


def _changes(s: pd.Series) -> dict:
    if s is None or len(s) < 6:
        return {}
    out = {"last": float(s.iloc[-1])}
    if len(s) > 5:
        out["chg_5d"] = (s.iloc[-1] / s.iloc[-6] - 1) * 100
    if len(s) > 20:
        out["chg_20d"] = (s.iloc[-1] / s.iloc[-21] - 1) * 100
    return out


def fetch_macro_snapshot(sector_map: dict | None = None, log=print) -> dict:
    """Snapshot of macro drivers + sector index performance.

    Returns {'usdinr': {...}, 'crude': {...}, 'spx': {...}, 'vix': {...},
             'sectors': {sector: {'chg_5d','chg_20d','last'}}}
    """
    def _p():
        out: dict = {}
        for key, candidates in MACRO_TICKERS.items():
            for sym in candidates:
                ch = _changes(_series(sym))
                if ch:
                    ch["symbol"] = sym
                    out[key] = ch
                    break
        smap = sector_map if sector_map is not None else SECTOR_INDEX_MAP
        sectors: dict = {}
        for sector, idx in smap.items():
            if not idx:
                continue
            ch = _changes(_series(idx, period="3mo"))
            if ch:
                sectors[sector] = ch
        out["sectors"] = sectors
        return out
    return cached("macro_snapshot", lambda: _safe(_p, log), cache=CACHE) or {}


def _safe(fn, log=print):
    try:
        return fn()
    except Exception as e:  # noqa: BLE001
        log(f"[macro] snapshot failed: {type(e).__name__}: {e}")
        return {}


def fetch_nifty_history(period: str = "6mo") -> pd.DataFrame:
    def _p():
        import yfinance as yf
        df = yf.download(NIFTY, period=period, interval="1d",
                         auto_adjust=True, progress=False)
        return _clean(df)
    out = cached(f"nifty|{period}", lambda: safe_call(_p, default=None, label="nifty history"), cache=CACHE)
    return out if out is not None and len(out) else pd.DataFrame()


def fetch_vix_history(period: str = "6mo") -> pd.Series:
    def _p():
        import yfinance as yf
        df = yf.download(INDIA_VIX, period=period, interval="1d",
                         auto_adjust=True, progress=False)
        df = _clean(df)
        return None if df is None or df.empty else df["Close"].dropna()
    return cached(f"vix|{period}", lambda: safe_call(_p, default=None, label="vix history"), cache=CACHE)
