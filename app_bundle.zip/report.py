"""Markdown research report builder - the downloadable deliverable."""
from __future__ import annotations

from utils.helpers import ist_stamp

DISCLAIMER = """
> **Disclaimer:** This report is automated educational research output generated
> from free public data sources. It is **not investment advice**. The system is
> not a SEBI-registered research analyst or investment adviser. Expected returns
> are model-derived probabilistic estimates (ATR/structure based), not guarantees.
> Markets can invalidate any setup overnight. Trade at your own risk and consult
> a SEBI-registered adviser.
"""


def build_markdown(result, cfg) -> str:
    mkt = result.market or None
    L: list[str] = []
    title = "Indian Equity Multi-Agent Research Report"
    if result.mode == "DEMO":
        title += "  (DEMO - SYNTHETIC DATA)"
    L.append(f"# {title}")
    L.append("")
    L.append(f"Generated: {result.as_of or ist_stamp()} | Mode: **{result.mode}** | "
             f"Universe scanned: {result.universe_scanned} | Usable: {result.universe_usable} | "
             f"Deep-dive shortlist: {len(result.shortlist)}")
    L.append("")
    L.append("---")
    L.append("")
    L.append("## Mother Agent - Final Verdict")
    L.append("")
    L.append(result.final_text or "No final verdict produced.")
    L.append("")
    L.append("---")
    L.append("")

    # ---------------- market context ------------------------------
    if mkt:
        L.append("## Market Context (Nifty + Macro)")
        L.append("")
        if mkt.regime:
            d = mkt.regime.details
            lv, sc = d.get("levels", {}), d.get("scenarios", {})
            rs = "n/a" if mkt.regime.score is None else f"{mkt.regime.score:.0f}"
            L.append(f"**Regime: {d.get('regime', 'UNKNOWN')}** | Regime score "
                     f"{rs}/100 | Confidence {mkt.regime.confidence:.0f}%")
            L.append("")
            if lv:
                L.append("| Nifty level | Value |")
                L.append("|---|---|")
                for k, label in (("spot", "Spot"), ("ema20", "20-DMA (EMA)"),
                                 ("ema50", "50-DMA (EMA)"), ("ema200", "200-DMA (EMA)"),
                                 ("resistance_1", "Resistance (3m high zone)"),
                                 ("support_1", "Support 1"), ("support_2", "Support 2"),
                                 ("atr21", "ATR(21)"),
                                 ("expected_move_4w_1sigma", "4-week expected move (1 sigma)")):
                    v = lv.get(k)
                    L.append(f"| {label} | {v:,.0f} |" if isinstance(v, (int, float)) else f"| {label} | - |")
                L.append("")
            if sc:
                L.append("| 4-week scenario | Probability | Level(s) |")
                L.append("|---|---|---|")
                b, ba, be = sc.get("bull", {}), sc.get("base", {}), sc.get("bear", {})
                L.append(f"| Bull | {b.get('prob', '-')}% | target {b.get('target', 0):,.0f} (stretch {b.get('stretch', 0):,.0f}) |")
                L.append(f"| Base | {ba.get('prob', '-')}% | {ba.get('range_low', 0):,.0f} - {ba.get('range_high', 0):,.0f} |")
                L.append(f"| Bear | {be.get('prob', '-')}% | target {be.get('target', 0):,.0f} (stretch {be.get('stretch', 0):,.0f}) |")
                L.append("")
        if mkt.macro:
            d = mkt.macro.details
            L.append(f"**Macro risk-appetite score: "
                     f"{'n/a' if mkt.macro.score is None else f'{mkt.macro.score:.0f}'}/100 "
                     f"({mkt.macro.verdict})** | Confidence {mkt.macro.confidence:.0f}%")
            L.append("")
            tw = d.get("sector_tailwind", {})
            if tw:
                L.append("Sector tailwind (20-day momentum based): " +
                         ", ".join(f"{k} {v:.0f}" for k, v in
                                   sorted(tw.items(), key=lambda kv: -kv[1])))
                L.append("")
        if mkt.breadth:
            b = mkt.breadth
            L.append(f"Breadth: {b.get('pct_above_50dma', 0):.0f}% above 50-DMA | "
                     f"{b.get('pct_above_200dma', 0):.0f}% above 200-DMA | "
                     f"{b.get('new_20d_highs', 0)} new 20d highs vs {b.get('new_20d_lows', 0)} lows")
            L.append("")

    # ---------------- candidates table ------------------------------
    L.append("## Candidate Scoreboard")
    L.append("")
    if result.candidates:
        L.append("| Symbol | Name | Sector | Spot | Tech | Fund | News | Risk | Sector TW | Composite | Status |")
        L.append("|---|---|---|---:|---:|---:|---:|---:|---:|---:|---|")
        for c in sorted(result.candidates, key=lambda x: -x.composite):
            L.append(
                f"| {c.symbol} | {c.name} | {c.sector} | {c.spot:,.1f} | "
                f"{c.tech.score if c.tech and c.tech.score is not None else '-'} | "
                f"{c.fund.score if c.fund and c.fund.score is not None else '-'} | "
                f"{c.news.score if c.news and c.news.score is not None else '-'} | "
                f"{c.risk.score if c.risk and c.risk.score is not None else '-'} | "
                f"{c.sector_tailwind:.0f} | **{c.composite:.0f}** | "
                f"{'PICK' if c in result.picks else ('Rejected: ' + c.reject_reason[:60])} |")
        L.append("")
    else:
        L.append("No candidates reached the deep-dive stage.")
        L.append("")

    # ---------------- per-pick details ------------------------------
    for i, c in enumerate(result.picks, 1):
        p = c.plan
        L.append(f"## Pick {i}: {c.name} ({c.symbol})")
        L.append("")
        L.append(f"- **Sector:** {c.sector} | **Spot:** {c.spot:,.1f} | "
                 f"**Conviction:** {c.conviction} ({c.composite:.0f}/100)")
        L.append(f"- **Expected Return:** +{p.ret_low_pct:.1f}% to +{p.ret_high_pct:.1f}% "
                 f"in ~{p.horizon_days} days (cap {cfg.max_hold_days} days)")
        L.append(f"- **Entry:** up to {p.entry:,.1f} | **Stop:** {p.stop:,.1f} (-{p.stop_pct:.1f}%) | "
                 f"**Targets:** {p.target_low:,.1f} / {p.target_high:,.1f} | **R:R:** ~{p.rr_ratio:.1f}")
        L.append(f"- **Position size:** {p.shares:,} shares (~{p.position_pct:.1f}% of "
                 f"Rs {cfg.capital:,.0f}; max loss at stop Rs {p.risk_amount:,.0f})")
        L.append(f"- **Invalidation:** {p.invalidation}")
        L.append(f"- {p.time_stop}")
        L.append("")
        for rep, label in ((c.tech, "Technical"), (c.fund, "Fundamental & Quality"),
                           (c.news, "News & Sentiment"), (c.risk, "Risk")):
            if rep is None:
                continue
            L.append(f"### {label} Agent - {rep.verdict} (score {rep.score if rep.score is not None else 'n/a'}, "
                     f"confidence {rep.confidence:.0f}%, data {rep.data_quality})")
            L.append("")
            for kp in rep.key_points:
                L.append(f"- {kp}")
            L.append("")
            if rep.risks:
                for rk in rep.risks[:4]:
                    L.append(f"- *Risk:* {rk}")
                L.append("")

    # ---------------- rejected ideas ------------------------------
    if result.rejected:
        L.append("## Rejected Ideas (Mother Agent cuts)")
        L.append("")
        for c in sorted(result.rejected, key=lambda x: -x.composite):
            L.append(f"- **{c.symbol}** (composite {c.composite:.0f}): {c.reject_reason}")
        L.append("")

    # ---------------- methodology ------------------------------
    L.append("## Methodology (transparent, free data only)")
    L.append("")
    L.append("Composite conviction = 0.35*Technical + 0.20*Fundamental + 0.15*News "
             "+ 0.15*Sector/Macro tailwind + 0.15*Risk, adjusted by the regime "
             "(max +6 / -10) and sector tailwind (+/-4). Hard gates: liquidity floor, "
             "risk-score floor, technical floor, news red flags, crisis-regime gate. "
             "Maximum 2 published picks; standing aside is a first-class outcome.")
    L.append("")
    L.append("Expected return: conservative target = nearest meaningful overhead "
             "resistance (3-month high / 20-day channel / 52-week high, each >=1.5% "
             "away) or a 1.2x-stop-distance projection; optimistic target = second "
             "resistance or an ATR(21) projection, always offering >=1.6x the stop "
             "distance and capped at +10%. At 52-week highs (price discovery) targets "
             "are pure ATR projections. Horizon = diffusion heuristic on the ATR "
             f"distance, capped at {cfg.max_hold_days} days. Ideas with reward-to-risk "
             "below 1.0 are rejected. Position size risks at most "
             f"{cfg.risk_per_trade_pct}% of capital between entry and stop.")
    L.append("")
    L.append("Data sources: Yahoo Finance (prices, statements - `.NS` symbols), "
             "NSE public FII/DII endpoint (when reachable), Google News RSS, "
             "Economic Times / Moneycontrol / Business Standard RSS, Yahoo macro "
             "tickers (USD/INR, Brent, S&P 500, India VIX, NSE sector indices).")
    L.append("")
    for note in result.data_notes:
        L.append(f"- *Data note:* {note}")
    if result.data_notes:
        L.append("")
    L.append(DISCLAIMER.strip())
    L.append("")
    return "\n".join(L)
