# Indian Equity Multi-Agent Research System (NSE/BSE)

A fully working, end-to-end **multi-agent stock research system for the Indian equity market**.
Seven agents screen the liquid NSE universe, cross-verify each other, and a **Mother Agent**
publishes **at most 1-2 high-conviction ideas for a holding period of up to 4 weeks (28 days)** -
each with an expected-return range, exact day horizon, invalidation level and position size -
plus a **4-week Nifty outlook** with key levels and scenario odds.

Built **exclusively on free data sources**. No paid APIs, no API keys, no LLM calls.
Every agent is a deterministic, rule-based quantitative module: same inputs -> same outputs.

```
Web app (Streamlit):  streamlit run app.py
CLI run:              python tests/smoke_test.py --live            (full universe)
                      python tests/smoke_test.py --live --tiny     (8 symbols, fast)
                      python tests/smoke_test.py --demo            (synthetic data, offline)
```

---

## 1. The Agent Team

| # | Agent | What it does (free inputs only) | Output |
|---|-------|--------------------------------|--------|
| 1 | **Mother Agent** (`agents/mother.py`) | Collects every specialist report, cross-verifies signals, applies hard veto rules, ranks by composite conviction, publishes **0, 1 or 2** stocks (or "No high-conviction idea this week"). Only the Mother Agent issues recommendations. | Final recommendation lines, trade plans, 4-week outlook text, confidence & disclaimer |
| 2 | **Technical Agent** (`agents/technical.py`) | Price action, volume, EMA 20/50/200 stack, RSI(14), MACD, ADX/DI, Donchian breakouts, 3-month/52-week structure, relative strength vs Nifty (20d & 63d), up/down volume skew. Classifies the setup: BREAKOUT / PULLBACK-IN-TREND / TREND-CONTINUATION / RANGE / WEAK. | Score 0-100, verdict, key levels, risks |
| 3 | **Fundamental & Quality Agent** (`agents/fundamental.py`) | Derived from yfinance quarterly statements (crumb-free): revenue/net-income TTM + YoY, margins, ROE, D/E, FCF; valuation vs same-industry peers within the analysed pool; insider-holding proxy from `.info` when reachable (disclosed when not). | Score 0-100, quality flags, valuation method |
| 4 | **News & Sentiment Agent** (`agents/news.py`) | Google News RSS per symbol (`when:14d`) + ET / Moneycontrol / Business Standard market feeds. Recency-weighted keyword tone; **hard red-flag veto list** (fraud, SEBI action, auditor exit, insolvency, promoter pledge...). | Score 0-100, tone, red flags, warnings |
| 5 | **Macro & Sector Agent** (`agents/macro.py`) | FII/DII cash flows (NSE public endpoint, when reachable), USD/INR, Brent, S&P 500, India VIX (Yahoo tickers), sector-index momentum table -> per-sector tailwind scores. Unavailable drivers are neutralised **and disclosed** - never fabricated. | Risk-appetite score 0-100, sector tailwind map |
| 6 | **Risk Agent** (`agents/risk.py`) | Liquidity floor (20d avg turnover in Rs crore), annualised volatility + 1y percentile, ATR%, beta, 6m drawdown; ATR/swing-based stop; position sizing (risk % of capital, max position cap). | Risk score 0-100, stop level, share count |
| 7 | **Market Regime Agent** (`agents/regime.py`) | Nifty vs EMAs, ADX, India VIX, market breadth (% of universe above 50/200-DMA, 20d highs/lows) -> regime classification (STRONG BULL ... CRISIS-RISK) + **4-week Nifty outlook** with support/resistance and bull/base/bear scenario odds. | Regime, levels, scenarios, narrative |

**Decision rules enforced by the Mother Agent** (all thresholds in `config/settings.py`):

- Liquidity floor: 20-day avg turnover >= Rs 75 crore (configurable)
- Technical score >= 55 and Risk score >= 45
- Any news red flag -> veto
- Composite conviction >= 68 (slider in the app) where composite =
  `0.35*Technical + 0.20*Fundamental + 0.15*News + 0.15*Sector tailwind + 0.15*Risk`,
  adjusted by regime (+6/-10), sector (+/-4) and cross-verification penalties
- Crisis regimes (CORRECTION / CRISIS-RISK) require composite >= 74 and tech >= 70
- Reward-to-risk below 1.0 -> rejected ("nearest resistance too close to entry")
- Max 2 picks, different sectors preferred; if nothing clears the bar:
  **"No high-conviction idea this week"** - standing aside is a first-class outcome.

---

## 2. Free Data Sources (and honest limits)

| Source | Used for | Status |
|--------|----------|--------|
| `yfinance` (`.NS` suffix) | Batch OHLCV for the universe, Nifty, India VIX, USD/INR, Brent, S&P 500, NSE sector indices, quarterly income/balance/cash-flow statements, market cap | Works broadly; Yahoo's `.info` endpoint needs a "crumb" that is rate-limited/blocked on some networks. The system detects this and falls back to statements-derived metrics automatically. |
| NSE public endpoint (`fiidiiTradeReact`), or `nsepython` if installed | FII/DII daily cash flows | NSE blocks many non-Indian IPs (HTTP 403). When blocked, the Macro agent discloses "FII/DII unavailable" and uses a neutral assumption. No numbers are invented. |
| Google News RSS | Per-symbol headline tone (14-day window) | Free, no key |
| Economic Times / Moneycontrol / Business Standard RSS | Market-wide mood for the Regime Agent | Free, no key |

> Design principle: **if a free source is unreachable, the affected agent reports
> `data_quality = DEGRADED/UNAVAILABLE` and the Mother Agent caps conviction accordingly.**
> The system never fabricates data. Demo mode (`--demo`) generates seeded synthetic data,
> is watermarked on every output, and exists purely to let you verify the UI offline.

---

## 3. Setup & Run

Requirements: **Python 3.10+** (tested on 3.12).

```bash
# 1. create a virtual environment (optional but recommended)
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate

# 2. install dependencies (all free/open-source)
pip install -r requirements.txt

# 3. launch the web application
streamlit run app.py
```

Open the URL Streamlit prints (default `http://localhost:8501`), pick the universe
(NIFTY 100 / NIFTY 50 / custom), tune risk parameters if you want, and press
**Run Full Multi-Agent Research**. A live full-universe run takes ~1-3 minutes
(demo mode is instant). Expand each agent's report, read the Mother Agent's final
recommendation and the 4-week Nifty outlook, and **download the Markdown research report**.

CLI alternatives (same pipeline, prints to console, saves report with `--save`):

```bash
python tests/smoke_test.py --live                 # full NIFTY 100 universe
python tests/smoke_test.py --live --tiny          # quick 8-symbol test
python tests/smoke_test.py --live --save out.md   # save the markdown report
python tests/smoke_test.py --demo                 # offline synthetic walkthrough
python tests/app_test.py                          # UI-level test (Streamlit AppTest)
```

Optional: `pip install nsepython` - if present, the FII/DII fetcher uses it first;
otherwise the built-in NSE client (plain `requests`) is used. Neither is required.

---

## 4. What the Output Looks Like

The Mother Agent's final block follows this exact format (see
`examples/sample_report_LIVE_full_universe.md` for a real full-universe run):

```
**Final Recommendation**
Stock 1: DLF (DLF) | Expected Return: +6.2% to +8.2% in ~28 days (<= 28 days)
         | Conviction: HIGH (75/100) | Thesis: ... | Key Risks: ... | Invalidation: ...
         - Trade plan: entry up to 755.0; stop 716.3 (-5.1%); targets 801.4 / 816.9;
           R:R ~1.2 | size 33 shares (~24.9% of Rs 100,000 capital, max risk Rs 1,500)
Stock 2: ... (or nothing)

**4-Week Nifty Outlook**
Regime: STRONG BULL. ... base case (40%) is a 24,617-25,614 grind; a push toward
26,469 (48% odds) needs the index to hold above 23,413; a break below 23,413 opens
23,056 (12% odds)... Key levels - resistance / support-1 / support-2 / 50-DMA / 200-DMA.

**Confidence & Disclaimer**
Overall confidence: HIGH (83/100). ... not investment advice ...
```

Expected returns are **model-derived estimates**: conservative target = nearest
meaningful overhead resistance (or a 1.2x-stop-distance projection), optimistic
target >= 1.6x the stop distance, capped at +10% and by ATR multiples; at 52-week
highs (price discovery) targets are pure ATR projections. The horizon uses a
diffusion heuristic on the ATR distance, always capped at 28 days.

---

## 5. Project Structure

```
indian-equity-multiagent/
├── app.py                     # Streamlit web application (entry point)
├── requirements.txt           # free/open-source dependencies only
├── README.md
├── ARCHITECTURE.md            # detailed architecture & methodology
├── config/
│   └── settings.py            # universe (NIFTY 50 + Next 50), sector map, all knobs
├── core/
│   └── models.py              # AgentReport / Candidate / TradePlan / ResearchResult
├── data/
│   ├── yf_client.py           # yfinance: batch prices, statements, market cap
│   ├── nse_client.py          # NSE FII/DII (nsepython -> built-in client -> disclosed gap)
│   ├── news_client.py         # Google News RSS + ET/MC/BS feeds
│   ├── macro_client.py        # USD/INR, crude, S&P, VIX, sector indices
│   └── demo.py                # seeded synthetic data for offline demo mode
├── analysis/
│   ├── indicators.py          # pure pandas/numpy indicator library
│   └── lexicon.py             # transparent news sentiment lexicon + red flags
├── agents/
│   ├── base.py                # BaseAgent + safe fallback reports
│   ├── technical.py           # Agent 2
│   ├── fundamental.py         # Agent 3
│   ├── news.py                # Agent 4
│   ├── macro.py               # Agent 5
│   ├── risk.py                # Agent 6
│   ├── regime.py              # Agent 7
│   └── mother.py              # Agent 1 - final authority
├── engine/
│   ├── orchestrator.py        # 6-stage pipeline with progress callbacks
│   └── report.py              # markdown research-report builder
├── utils/helpers.py           # safe_call, TTL cache, IST time, formatting
├── tests/
│   ├── smoke_test.py          # end-to-end pipeline test (demo / live / tiny)
│   └── app_test.py            # UI test via Streamlit AppTest
├── examples/                  # real generated sample reports
└── .streamlit/config.toml     # clean light theme
```

---

## 6. Customisation

- **Universe** - edit `UNIVERSE_NIFTY_50` / `UNIVERSE_NIFTY_NEXT_50` in
  `config/settings.py` (index constituents change periodically; stale tickers are
  skipped gracefully), or choose CUSTOM in the app sidebar.
- **Risk knobs** - capital, risk per trade, max position %, liquidity floor,
  conviction threshold: sidebar in the app, defaults in `Config`.
- **Agent weights** - `COMPOSITE_WEIGHTS` in `config/settings.py`.
- **Red flags / lexicon** - `analysis/lexicon.py` (plain word lists, easy to audit).

---

## 7. Troubleshooting

| Symptom | Meaning / fix |
|---------|---------------|
| "FII/DII flows unavailable ... neutral assumption" note | NSE blocks this network (common outside India). Install `nsepython` or run from an Indian IP; otherwise the note is expected behaviour. |
| `Crumb fetch rate-limited (HTTP 429)` in the console | Yahoo throttled `.info`. Harmless: fundamentals fall back to statements-derived metrics automatically. |
| Some tickers missing from the scoreboard | Ticker renamed/delisted (e.g. post-demerger Tata Motors). Remove/replace it in the universe config. |
| Empty universe / all agents degraded | No network access. Run `--demo` to verify the app, or check firewalls. |
| Run seems slow (1-3 min) | Normal for ~105 symbols + statements + news. Demo mode is instant. |

---

## 8. Disclaimer

This project is **educational research software**, not investment advice. It is **not**
a SEBI-registered research analyst or investment adviser. Expected returns are
probabilistic model estimates, not guarantees; markets can invalidate any setup
overnight. Use it to structure your own research, and consult a SEBI-registered
adviser before trading.
