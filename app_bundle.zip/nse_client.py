"""Free NSE public-data client: FII/DII cash-market activity.

Strategy (in order):
  1. If the optional `nsepython` package is installed, use it.
  2. Else use a built-in minimal NSE client (requests + cookie warm-up).
  3. If NSE blocks the network (common for non-Indian IPs, HTTP 403),
     return [] - the Macro agent then explicitly marks FII/DII as
     UNAVAILABLE and uses a neutral assumption. We never fabricate flows.

Endpoint used (public, free):
  https://www.nseindia.com/api/fiidiiTradeReact
"""
from __future__ import annotations

import time
from datetime import datetime

import requests

from utils.helpers import CACHE, cached, ist_stamp

UA_HEADERS = {
    "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                   "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"),
    "Accept": "*/*",
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": "https://www.nseindia.com/",
}

FII_DII_URL = "https://www.nseindia.com/api/fiidiiTradeReact"


def _parse_date(s: str):
    for fmt in ("%d-%b-%Y", "%d-%b-%y", "%Y-%m-%d"):
        try:
            return datetime.strptime(s, fmt).date()
        except (TypeError, ValueError):
            continue
    return None


def _via_nsepython(log=print) -> list[dict]:
    try:
        from nsepython import nsefetch  # optional dependency
        raw = nsefetch(FII_DII_URL)
        return _normalise(raw)
    except Exception as e:  # noqa: BLE001
        log(f"[nse] nsepython path failed: {type(e).__name__}: {e}")
        return []


def _via_builtin(log=print) -> list[dict]:
    s = requests.Session()
    s.headers.update(UA_HEADERS)
    try:
        s.get("https://www.nseindia.com", timeout=8)          # cookie warm-up
        time.sleep(0.4)
        r = s.get(FII_DII_URL, timeout=8)
        if r.status_code != 200:
            log(f"[nse] FII/DII endpoint status={r.status_code} (NSE may block this network)")
            return []
        return _normalise(r.json())
    except Exception as e:  # noqa: BLE001
        log(f"[nse] built-in client failed: {type(e).__name__}: {e}")
        return []


def _normalise(raw) -> list[dict]:
    """NSE rows look like:
       {'category': 'FII/FPI **', 'date': '06-Nov-2026', 'buyValue': ...,
        'sellValue': ..., 'netValue': ...}   (values in Rs crore)
    """
    if isinstance(raw, dict):
        raw = raw.get("data", [])
    rows: dict[str, dict] = {}
    for it in raw or []:
        try:
            cat = str(it.get("category", "")).upper()
            d = _parse_date(str(it.get("date", "")))
            if d is None:
                continue
            slot = rows.setdefault(d.isoformat(), {"date": d})
            net = it.get("netValue")
            if "FII" in cat or "FPI" in cat:
                slot["fii_net"] = float(net) if net is not None else None
            elif "DII" in cat:
                slot["dii_net"] = float(net) if net is not None else None
        except (TypeError, ValueError, AttributeError):
            continue
    out = [v for v in rows.values() if "fii_net" in v or "dii_net" in v]
    out.sort(key=lambda x: x["date"], reverse=True)
    return out


def fetch_fii_dii(sessions: int = 5, log=print) -> list[dict]:
    """Return the most recent `sessions` trading days:
       [{'date': date, 'fii_net': float_cr, 'dii_net': float_cr}, ...] (newest first)
       Empty list => unavailable (never fabricated).
    """
    def _p():
        rows = _via_nsepython(log=log)
        if not rows:
            rows = _via_builtin(log=log)
        return rows[:sessions]
    got = cached(f"fiidii|{sessions}", lambda: _p(), cache=CACHE)
    return got or []
