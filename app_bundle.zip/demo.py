"""DEMO MODE: synthetic data generator.

When there is no network access (or the user wants a deterministic UI
walkthrough), the pipeline can run entirely on seeded synthetic data.
Every output produced in this mode is labelled DEMO - synthetic data.
Nothing here is ever used unless Config.demo=True.
"""
from __future__ import annotations

import hashlib
import math
from datetime import datetime, timedelta, timezone

import numpy as np
import pandas as pd

from config.settings import SECTOR_INDEX_MAP

SEED = 42


def _seed_for(text: str) -> int:
    return int(hashlib.md5(f"{SEED}:{text}".encode()).hexdigest()[:8], 16)


def _business_dates(n: int) -> pd.DatetimeIndex:
    end = pd.Timestamp(datetime.now(timezone.utc).date())
    return pd.bdate_range(end=end, periods=n)


def synth_prices(symbol: str, drift_bias: float = 0.0, n: int = 260,
                 base: float | None = None, vol_override: float | None = None) -> pd.DataFrame:
    """Geometric-Brownian-motion OHLCV with a per-symbol drift.

    `drift_bias` (annualised, e.g. 0.25 = +25%/yr) lets the demo nudge
    some names into uptrends so the pipeline can demonstrate picks.
    """
    rng = np.random.default_rng(_seed_for(symbol))
    dt = 1.0 / 252.0
    base = base if base is not None else (150 + (rng.random() * 3500))
    vol = vol_override if vol_override is not None else (0.18 + rng.random() * 0.30)
    mu = drift_bias + (rng.random() - 0.5) * 0.4
    rets = rng.normal(mu * dt, vol * math.sqrt(dt), n)
    close = base * np.cumprod(1 + rets)
    dates = _business_dates(n)
    spread = np.abs(rng.normal(0.012, 0.004, n))
    high = close * (1 + spread)
    low = close * (1 - spread * rng.random(n))
    op = np.concatenate([[close[0]], close[:-1]])
    volume = (5e5 + rng.random(n) * 4.5e6) * (1 + np.abs(rets) * 30)
    return pd.DataFrame(
        {"Open": op, "High": high, "Low": low, "Close": close, "Volume": volume},
        index=dates,
    )


def synth_vix(n: int = 260) -> pd.Series:
    """India VIX-like mean-reverting series around 14."""
    rng = np.random.default_rng(_seed_for("VIXLEVEL"))
    vals = [13.5]
    for _ in range(n - 1):
        nxt = vals[-1] + 0.9 * (13.5 - vals[-1]) + rng.normal(0, 0.8)
        vals.append(max(9.0, min(28.0, nxt)))
    return pd.Series(vals, index=_business_dates(n), name="Close")


def synth_fundamentals(symbol: str) -> dict:
    rng = np.random.default_rng(_seed_for("fin" + symbol))
    rev = 8e9 * (1 + rng.random() * 20)
    return {
        "rev_ttm": rev,
        "rev_yoy": float(rng.normal(11, 8)),
        "rev_qoq": float(rng.normal(3, 3)),
        "ni_ttm": rev * (0.05 + rng.random() * 0.16),
        "ni_yoy": float(rng.normal(14, 12)),
        "margin_ttm": float(5 + rng.random() * 18),
        "debt": rev * rng.random() * 0.8,
        "equity": rev * (0.4 + rng.random()),
        "de_ratio": float(rng.gamma(2.0, 0.35)),
        "roe": float(rng.normal(16, 7)),
        "fcf_ttm": rev * (0.02 + rng.random() * 0.1),
        "market_cap": rev * (2.5 + rng.random() * 8),
        "pe": float(rng.uniform(12, 55)),
        "pb": float(rng.uniform(1.5, 9)),
        "quarters_covered": 5,
    }


def synth_info(symbol: str) -> dict:
    rng = np.random.default_rng(_seed_for("info" + symbol))
    return {
        "trailingPE": float(rng.uniform(12, 55)),
        "forwardPE": float(rng.uniform(10, 45)),
        "returnOnEquity": float(rng.normal(0.16, 0.07)),
        "debtToEquity": float(rng.gamma(2.0, 0.3) * 100),
        "profitMargins": float(rng.uniform(0.03, 0.22)),
        "revenueGrowth": float(rng.normal(0.11, 0.08)),
        "earningsGrowth": float(rng.normal(0.14, 0.12)),
        "heldPercentInsiders": float(rng.uniform(25, 72)),
        "recommendationKey": rng.choice(["buy", "hold", "buy", "buy"]),
        "targetMeanPrice": float(rng.uniform(0.9, 1.3) * 1000),
        "industry": "Demo Industry",
    }


def synth_fii_dii(sessions: int = 5) -> list[dict]:
    rng = np.random.default_rng(_seed_for("fii"))
    rows = []
    d = datetime.now(timezone.utc).date()
    for i in range(sessions):
        d = d - timedelta(days=1)
        while d.weekday() >= 5:
            d = d - timedelta(days=1)
        rows.append({
            "date": d,
            "fii_net": float(rng.normal(500, 2500)),
            "dii_net": float(rng.normal(1200, 1500)),
        })
    return rows


def synth_symbol_news(symbol: str, name: str, days: int = 14) -> list[dict]:
    rng = np.random.default_rng(_seed_for("news" + symbol))
    templates = [
        (f"{name} shares in focus after strong quarterly results", 5),
        (f"Brokerages positive on {name}, raise target price", 4),
        (f"{symbol}: management guides for healthy demand outlook", 3),
        (f"{name} trades flat amid mixed market cues", 0),
        (f"Analysts flag rich valuation in {name} after rally", -4),
        (f"{name} announces capacity expansion plan", 4),
        (f"{symbol} slips 2% as sector peers decline", -3),
    ]
    out = []
    for tpl, _s in templates:
        if rng.random() < 0.65:
            age = int(rng.integers(0, days))
            out.append({
                "title": tpl,
                "source": "DemoFeed",
                "utc": datetime.now(timezone.utc) - timedelta(days=age),
                "age_days": age,
            })
    return out


def synth_market_news() -> list[dict]:
    heads = [
        "Nifty ends higher as banks and IT lead gains",
        "FIIs turn net buyers in cash market after three sessions",
        "India VIX cools off below 14, market volatility eases",
        "Crude oil steady; RBI policy expected to hold rates",
        "Midcap index outperforms for third straight week",
        "Global cues mixed as US indices hover near record highs",
    ]
    return [{"title": h, "source": "DemoFeed", "utc": None, "age_days": 1} for h in heads]


def synth_macro_snapshot() -> dict:
    rng = np.random.default_rng(_seed_for("macro"))
    return {
        "usdinr": {"last": 88.6, "chg_5d": float(rng.normal(0.1, 0.3)), "chg_20d": float(rng.normal(0.4, 0.6)), "symbol": "INR=X"},
        "crude": {"last": 71.0, "chg_5d": float(rng.normal(0.0, 1.5)), "chg_20d": float(rng.normal(-1.5, 3)), "symbol": "BZ=F"},
        "spx": {"last": 6100.0, "chg_5d": float(rng.normal(0.3, 0.8)), "chg_20d": float(rng.normal(2, 3)), "symbol": "^GSPC"},
        "vix": {"last": 13.4, "chg_5d": float(rng.normal(-2, 4)), "chg_20d": float(rng.normal(-6, 8)), "symbol": "^INDIAVIX"},
        "sectors": {
            s: {"last": 1000.0, "chg_5d": float(rng.normal(0.5, 1.2)),
                "chg_20d": float(rng.normal(1.5, 2.5))}
            for s in SECTOR_INDEX_MAP if SECTOR_INDEX_MAP[s]
        },
    }
