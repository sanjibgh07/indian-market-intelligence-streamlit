# Indian Equity Multi-Agent Research Report

Generated: 09-Nov-2026 16:28 IST | Mode: **LIVE** | Universe scanned: 8 | Usable: 8 | Deep-dive shortlist: 6

---

## Mother Agent - Final Verdict

**Final Recommendation**

**Stock 1: DLF (DLF)** | Expected Return: **+6.2% to +8.2% in ~28 days (<= 28 days)** | Conviction: HIGH (74/100) | Thesis: Breakout setup; RS vs Nifty +5.2% (20d); fundamentals adequate (ROE 10%, D/E 0.0); news tone supportive; risk agent: LOW RISK | Key Risks: Price 3.5 ATR above EMA20 - extended, chase risk; Break of EMA50 (677.5) would invalidate the trend structure; Warnings: probe | Invalidation: Daily close below 716.3 (-5.1%; breaks the 4-week structure). Setup also void if Nifty loses 23,413.

  - Trade plan: entry up to 755.0; stop 716.3 (-5.1%); targets 801.4 / 816.9; R:R ~1.2 | size 33 shares (~24.9% of Rs 100,000 capital, max risk Rs 1,500)
  - Time stop: if neither target is hit by day 28 and the position is below +1%, exit and reassess.

**Stock 2: TITAN (TITAN)** | Expected Return: **+6.3% to +8.4% in ~28 days (<= 28 days)** | Conviction: HIGH (71/100) | Thesis: Range setup; RS vs Nifty +2.3% (20d); fundamentals adequate (ROE 39%, D/E 2.2); news tone supportive; risk agent: LOW RISK | Key Risks: Price 3.5 ATR above EMA20 - extended, chase risk; Break of EMA50 (4,647.9) would invalidate the trend structure; Keyword sentiment is coarse; earnings-day tone can flip fast | Invalidation: Daily close below 4,743.3 (-5.2%; breaks the 4-week structure). Setup also void if Nifty loses 23,413.

  - Trade plan: entry up to 5,005.0; stop 4,743.3 (-5.2%); targets 5,319.1 / 5,423.8; R:R ~1.2 | size 4 shares (~20.0% of Rs 100,000 capital, max risk Rs 1,500)
  - Time stop: if neither target is hit by day 28 and the position is below +1%, exit and reassess.

**4-Week Nifty Outlook**

Regime: STRONG BULL. Nifty is in a strong uptrend above rising 50/200-DMA with healthy breadth - dips are being bought. Breadth: 100% of the tracked universe above its 50-DMA and 50% above the 200-DMA. 4-week expected move (1 sigma, from ATR): about +/-5.7% around 25,045. Over the next four weeks the base case (40%) is a 24,617-25,614 grind; a push toward 26,469 (48% odds, stretch 27,324) needs the index to hold above 23,413; a break below 23,413 opens 23,056 (12% odds, stretch 22,273), with deeper support near 21,520 (200-DMA zone 24,011).

Key levels - resistance: 25,757 | support-1: 23,413 | support-2: 21,520 | 50-DMA: 23,413 | 200-DMA: 24,011

Scenario odds: Bull 48% (target 26,469) | Base 40% (24,617-25,614) | Bear 12% (target 23,056)

**Confidence & Disclaimer**

Overall confidence: **HIGH** (80/100). Confidence reflects data quality and signal agreement across agents; it is not a probability of profit.

Generated 09-Nov-2026 16:28 IST by the Indian Equity Multi-Agent Research System. Expected returns are model-derived probabilistic estimates from volatility and structure, NOT guarantees. Markets can invalidate any setup overnight. This is educational research output, not investment advice; the system is not a SEBI-registered research analyst or adviser. Consult a registered adviser and read scheme documents before trading.

---

## Market Context (Nifty + Macro)

**Regime: STRONG BULL** | Regime score 79/100 | Confidence 70%

| Nifty level | Value |
|---|---|
| Spot | 25,045 |
| 20-DMA (EMA) | 23,550 |
| 50-DMA (EMA) | 23,413 |
| 200-DMA (EMA) | 24,011 |
| Resistance (3m high zone) | 25,757 |
| Support 1 | 23,413 |
| Support 2 | 21,520 |
| ATR(21) | 311 |
| 4-week expected move (1 sigma) | 1,424 |

| 4-week scenario | Probability | Level(s) |
|---|---|---|
| Bull | 48% | target 26,469 (stretch 27,324) |
| Base | 40% | 24,617 - 25,614 |
| Bear | 12% | target 23,056 (stretch 22,273) |

**Macro risk-appetite score: 66/100 (RISK-ON)** | Confidence 72%

Sector tailwind (20-day momentum based): IT 72, BANKS 72, NBFC/FINANCIALS 72, INSURANCE 72, AUTO 72, PHARMA 72, HEALTHCARE 72, FMCG 72, CONSUMER 72, RETAIL 72, ENERGY 72, OIL & GAS 72, POWER 72, METALS 72, CEMENT 72, INFRA 72, LOGISTICS 72, DEFENCE 72, CAPITAL GOODS 72, DIVERSIFIED 72, REALTY 72

Breadth: 100% above 50-DMA | 50% above 200-DMA | 4 new 20d highs vs 0 lows

## Candidate Scoreboard

| Symbol | Name | Sector | Spot | Tech | Fund | News | Risk | Sector TW | Composite | Status |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|---|
| DLF | DLF | CUSTOM | 755.0 | 74.0 | 49.0 | 89.4 | 88.0 | 50 | **74** | PICK |
| TITAN | TITAN | CUSTOM | 5,005.0 | 64.0 | 50.0 | 87.8 | 90.0 | 50 | **71** | PICK |
| RELIANCE | RELIANCE | CUSTOM | 1,324.4 | 66.0 | 48.0 | 97.8 | 74.0 | 50 | **71** | Rejected: Rank 3: outside top 2 (max picks cap) |
| BEL | BEL | CUSTOM | 394.5 | 48.0 | 65.0 | 79.0 | 90.0 | 50 | **67** | Rejected: Technical score 48 below floor 55 |
| HDFCBANK | HDFCBANK | CUSTOM | 798.2 | 74.0 | 16.0 | 71.0 | 84.0 | 50 | **65** | Rejected: Composite conviction 65 below threshold 68 |
| INFY | INFY | CUSTOM | 1,154.1 | 62.0 | 52.4 | 60.0 | 70.0 | 50 | **64** | Rejected: Composite conviction 64 below threshold 68 |

## Pick 1: DLF (DLF)

- **Sector:** CUSTOM | **Spot:** 755.0 | **Conviction:** HIGH (74/100)
- **Expected Return:** +6.2% to +8.2% in ~28 days (cap 28 days)
- **Entry:** up to 755.0 | **Stop:** 716.3 (-5.1%) | **Targets:** 801.4 / 816.9 | **R:R:** ~1.2
- **Position size:** 33 shares (~24.9% of Rs 100,000; max loss at stop Rs 1,500)
- **Invalidation:** Daily close below 716.3 (-5.1%; breaks the 4-week structure). Setup also void if Nifty loses 23,413.
- Time stop: if neither target is hit by day 28 and the position is below +1%, exit and reassess.

### Technical Agent - STRONG BULLISH (score 74.0, confidence 73%, data OK)

- Close 755.0 | EMA20/50/200: 698.4 / 677.5 / 655.0
- RSI(14) 76.3 | ADX(14) 24.7 (+DI 35 vs -DI 10)
- MACD hist +9.07 (rising) | 20d return +16.4%
- RS vs Nifty: 20d +5.2% | 63d +15.7%
- Cleared 20-day Donchian high (752.9) | +0.3% vs 3-month high
- Setup: BREAKOUT | ATR(14) 17.6 (2.3% of price)

- *Risk:* Price 3.5 ATR above EMA20 - extended, chase risk
- *Risk:* Break of EMA50 (677.5) would invalidate the trend structure
- *Risk:* Sector/market-wide shock overrides stock setup

### Fundamental & Quality Agent - NEUTRAL (score 49.0, confidence 85%, data OK)

- TTM revenue growth -53.6% | net income growth 70.6% | margin 71.6%
- ROE 10.0% | D/E 0.0 | FCF(TTM) negative/na
- PE 40.9 | PB 4.1 (absolute bands)
- Insider/promoter holding proxy: unavailable (free-source limitation)

- *Risk:* Quarterly-statement data can lag; verify latest results before acting

### News & Sentiment Agent - STRONG BULLISH (score 89.4, confidence 80%, data OK)

- 25 headlines in last 14 days | weighted tone 89/100 (pos 8 vs neg 3 keyword hits)
- [o] DLF Share Price - Upstox
- [+] DLF to invest ₹3,750 cr in JV with Everstone to buy stake in IREO India - Business Standard
- [-] DLF Shares Slump on Fresh CCI Probe - NDTV Profit
- [o] Diwali 2026 Stock Picks: NSE, DLF, Apollo Hospitals, Jindal Steels & More; Brokerages' Views - ETV Bharat

- *Risk:* Warnings: probe
- *Risk:* Headlines are free-RSS only - no paid newsroom coverage

### Risk Agent - LOW RISK (score 88.0, confidence 70%, data OK)

- Liquidity: 20d avg turnover Rs 186 cr (PASS vs Rs 75 cr floor)
- Volatility: 20d annualised 22% (1y percentile 18) | ATR 2.3% of price
- Beta vs Nifty 1.54 | 6-month max drawdown -10.2%
- Suggested stop: 716.3 (-5.1%) = max(63d swing low - 0.5 ATR, spot - 2.2 ATR), bounded 2.5-9%
- Position size: 33 shares (Rs 24,915, 24.9% of capital) for max 1.5% capital risk = Rs 1,500

- *Risk:* Gap risk: overnight/global gaps can jump past the 716.3 stop
- *Risk:* Illiquid tape on result days: use limit orders near VWAP

## Pick 2: TITAN (TITAN)

- **Sector:** CUSTOM | **Spot:** 5,005.0 | **Conviction:** HIGH (71/100)
- **Expected Return:** +6.3% to +8.4% in ~28 days (cap 28 days)
- **Entry:** up to 5,005.0 | **Stop:** 4,743.3 (-5.2%) | **Targets:** 5,319.1 / 5,423.8 | **R:R:** ~1.2
- **Position size:** 4 shares (~20.0% of Rs 100,000; max loss at stop Rs 1,500)
- **Invalidation:** Daily close below 4,743.3 (-5.2%; breaks the 4-week structure). Setup also void if Nifty loses 23,413.
- Time stop: if neither target is hit by day 28 and the position is below +1%, exit and reassess.

### Technical Agent - BULLISH (score 64.0, confidence 83%, data OK)

- Close 5,005.0 | EMA20/50/200: 4,617.4 / 4,647.9 / 4,478.0
- RSI(14) 74.0 | ADX(14) 39.2 (+DI 36 vs -DI 14)
- MACD hist +89.12 (rising) | 20d return +13.5%
- RS vs Nifty: 20d +2.3% | 63d -0.6%
- Below 20-day Donchian high (5,013.9) | -3.2% vs 3-month high
- Setup: RANGE | ATR(14) 119.0 (2.4% of price)

- *Risk:* Price 3.5 ATR above EMA20 - extended, chase risk
- *Risk:* Break of EMA50 (4,647.9) would invalidate the trend structure
- *Risk:* Sector/market-wide shock overrides stock setup

### Fundamental & Quality Agent - NEUTRAL (score 50.0, confidence 85%, data OK)

- TTM revenue growth 37.3% | net income growth 119.3% | margin 8.1%
- ROE 38.5% | D/E 2.2 | FCF(TTM) negative/na
- PE 63.1 | PB 24.3 (absolute bands)
- Insider/promoter holding proxy: unavailable (free-source limitation)

- *Risk:* Quarterly-statement data can lag; verify latest results before acting

### News & Sentiment Agent - STRONG BULLISH (score 87.8, confidence 80%, data OK)

- 25 headlines in last 14 days | weighted tone 88/100 (pos 6 vs neg 2 keyword hits)
- [o] Titan Company Share Price - Upstox
- [o] Titan Company (TITAN) Share Price Today (NSE), Market News - TechGraph
- [o] Diwali stock picks 2026: Titan, ICICI Bank, HDFC Bank, BSE, Eternal among 25 stocks with up to 46% upside... -
- [o] Titan shares shine after Q2 results; Three analysts expect the stock to test ₹6,000 levels - CNBC TV18 - Linke

- *Risk:* Keyword sentiment is coarse; earnings-day tone can flip fast
- *Risk:* Headlines are free-RSS only - no paid newsroom coverage

### Risk Agent - LOW RISK (score 90.0, confidence 70%, data OK)

- Liquidity: 20d avg turnover Rs 412 cr (PASS vs Rs 75 cr floor)
- Volatility: 20d annualised 24% (1y percentile 67) | ATR 2.4% of price
- Beta vs Nifty 1.10 | 6-month max drawdown -16.8%
- Suggested stop: 4,743.3 (-5.2%) = max(63d swing low - 0.5 ATR, spot - 2.2 ATR), bounded 2.5-9%
- Position size: 4 shares (Rs 20,020, 20.0% of capital) for max 1.5% capital risk = Rs 1,500

- *Risk:* Gap risk: overnight/global gaps can jump past the 4,743.3 stop
- *Risk:* Illiquid tape on result days: use limit orders near VWAP

## Rejected Ideas (Mother Agent cuts)

- **RELIANCE** (composite 71): Rank 3: outside top 2 (max picks cap)
- **BEL** (composite 67): Technical score 48 below floor 55
- **HDFCBANK** (composite 65): Composite conviction 65 below threshold 68
- **INFY** (composite 64): Composite conviction 64 below threshold 68

## Methodology (transparent, free data only)

Composite conviction = 0.35*Technical + 0.20*Fundamental + 0.15*News + 0.15*Sector/Macro tailwind + 0.15*Risk, adjusted by the regime (max +6 / -10) and sector tailwind (+/-4). Hard gates: liquidity floor, risk-score floor, technical floor, news red flags, crisis-regime gate. Maximum 2 published picks; standing aside is a first-class outcome.

Expected return: conservative target = nearest meaningful overhead resistance (3-month high / 20-day channel / 52-week high, each >=1.5% away) or a 1.2x-stop-distance projection; optimistic target = second resistance or an ATR(21) projection, always offering >=1.6x the stop distance and capped at +10%. At 52-week highs (price discovery) targets are pure ATR projections. Horizon = diffusion heuristic on the ATR distance, capped at 28 days. Ideas with reward-to-risk below 1.0 are rejected. Position size risks at most 1.5% of capital between entry and stop.

Data sources: Yahoo Finance (prices, statements - `.NS` symbols), NSE public FII/DII endpoint (when reachable), Google News RSS, Economic Times / Moneycontrol / Business Standard RSS, Yahoo macro tickers (USD/INR, Brent, S&P 500, India VIX, NSE sector indices).

- *Data note:* FII/DII flows unavailable from free NSE endpoints on this network - macro agent uses a neutral, disclosed assumption.

> **Disclaimer:** This report is automated educational research output generated
> from free public data sources. It is **not investment advice**. The system is
> not a SEBI-registered research analyst or investment adviser. Expected returns
> are model-derived probabilistic estimates (ATR/structure based), not guarantees.
> Markets can invalidate any setup overnight. Trade at your own risk and consult
> a SEBI-registered adviser.
