"""News & Sentiment Agent - free RSS headlines -> tone, coverage, red flags.

Sources: Google News RSS (per symbol, `when:14d`), plus ET / Moneycontrol /
Business Standard feeds for market mood (used by the Regime Agent).

Sentiment = transparent keyword lexicon (analysis/lexicon.py), recency-weighted.
Hard red flags (fraud, SEBI action, auditor exit, insolvency...) produce a
veto that the Mother Agent must respect.
"""
from __future__ import annotations

from agents.base import BaseAgent
from analysis.lexicon import POSITIVE, NEGATIVE, RED_FLAGS, score_headlines
from core.models import Q_DEGRADED, Q_OK, verdict_from_score
from utils.helpers import clamp, r2

# recency weights: <=3 days full weight, <=7d 0.7, else 0.4
def _w(age) -> float:
    if age is None:
        return 0.5
    if age <= 3:
        return 1.0
    if age <= 7:
        return 0.7
    return 0.4


class NewsAgent(BaseAgent):
    name = "News & Sentiment Agent"
    description = "Recent events and headline tone from free RSS sources"

    def analyze_symbol(self, symbol: str, articles: list[dict]) -> "AgentReport":  # noqa: F821
        try:
            return self._analyze_symbol(symbol, articles)
        except Exception as e:  # noqa: BLE001
            return self.fallback(symbol, why=str(e))

    # ------------------------------------------------------------------
    def _analyze_symbol(self, symbol, articles):
        if not articles:
            return self.report(
                verdict="NEUTRAL", score=50.0, confidence=25.0,
                data_quality=Q_DEGRADED,
                key_points=["No recent headlines found in free feeds - low coverage."],
                risks=["News vacuum: an undisclosed event cannot be ruled out."],
                details={"n_headlines": 0}, symbol=symbol)

        heads = [a["title"] for a in articles]
        ages = [a.get("age_days") for a in articles]
        lex = score_headlines(heads)

        # recency-weighted tone
        wnet = 0.0
        wt = 0.0
        for t, age in zip(heads, ages):
            tl = f" {t.lower()} "
            p = sum(1 for w in POSITIVE if w in tl)
            n = sum(1 for w in NEGATIVE if w in tl)
            wnet += _w(age) * (p - n)
            wt += _w(age)
        import math
        tone_w = 50.0 + 50.0 * math.tanh(wnet / max(1.5, math.sqrt(max(wt, 1.0))))
        tone_w = clamp(tone_w, 0, 100)

        n = len(heads)
        flags = lex["flags"]
        score = tone_w
        if flags:
            score = min(score, 15.0)   # red flag crushes the news score
        verdict = verdict_from_score(score)

        conf = clamp(35 + n * 2.0, 30, 80)
        q = Q_OK if n >= 4 else Q_DEGRADED

        kps = [
            f"{n} headlines in last 14 days | weighted tone {tone_w:.0f}/100 "
            f"(pos {lex['pos']} vs neg {lex['neg']} keyword hits)",
        ]
        for h in heads[:4]:
            tl = f" {h.lower()} "
            tag = "+" if any(w in tl for w in POSITIVE) else \
                  ("-" if any(w in tl for w in NEGATIVE) else "o")
            kps.append(f"[{tag}] {h[:110]}")
        if flags:
            kps.append("RED FLAGS: " + ", ".join(sorted(set(flags))))

        risks = (["Red-flag news detected - Mother Agent must veto this idea."] if flags else []) + \
                [f"Warnings: {', '.join(sorted(set(lex['warnings'])))}" if lex["warnings"] else
                 "Keyword sentiment is coarse; earnings-day tone can flip fast",
                 "Headlines are free-RSS only - no paid newsroom coverage"]

        details = {
            "n_headlines": n,
            "pos_hits": lex["pos"], "neg_hits": lex["neg"],
            "weighted_tone": r2(tone_w),
            "red_flags": sorted(set(flags)),
            "warnings": sorted(set(lex["warnings"])),
            "headlines": heads[:10],
        }
        return self.report(verdict=verdict, score=score, confidence=conf,
                           data_quality=q, key_points=kps, risks=risks,
                           details=details, symbol=symbol)

    # ------------------------------------------------------------------
    def analyze_market(self, articles: list[dict]) -> dict:
        """Market-wide mood (0-100) consumed by the Regime Agent."""
        heads = [a["title"] for a in (articles or [])]
        if not heads:
            return {"mood": 50.0, "n": 0, "quality": "UNAVAILABLE"}
        lex = score_headlines(heads)
        return {"mood": r2(lex["tone"]), "n": len(heads), "quality": "OK",
                "flags": lex["flags"]}
