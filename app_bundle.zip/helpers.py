"""Small shared helpers: safe calls, IST clock, formatting, tiny TTL cache."""
from __future__ import annotations

import functools
import time
import traceback
import warnings
from datetime import datetime, timezone, timedelta

warnings.filterwarnings("ignore")

IST = timezone(timedelta(hours=5, minutes=30))


def now_ist() -> datetime:
    return datetime.now(IST)


def ist_stamp(fmt: str = "%d-%b-%Y %H:%M IST") -> str:
    return now_ist().strftime(fmt)


def clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))


def r2(x) -> float:
    """Round to 2 decimals, tolerant of None/NaN."""
    try:
        f = float(x)
        return round(f, 2) if f == f else float("nan")
    except (TypeError, ValueError):
        return float("nan")


def rs(x, decimals: int = 1) -> str:
    """Format a rupee amount like Rs 1,23,456 (Indian grouping not critical)."""
    try:
        v = float(x)
        return f"Rs {v:,.{decimals}f}"
    except (TypeError, ValueError):
        return "Rs -"


def pct(x, decimals: int = 1) -> str:
    try:
        v = float(x)
        return f"{v:+.{decimals}f}%"
    except (TypeError, ValueError):
        return "-"


def safe_call(fn, *args, default=None, label: str = "", log=print, **kwargs):
    """Run fn and never raise: returns `default` on any failure.

    Every network/analysis call in the agents goes through this so a single
    flaky source can never crash a research run.
    """
    try:
        return fn(*args, **kwargs)
    except Exception as e:  # noqa: BLE001 - deliberately broad
        log(f"[safe_call] {label or fn.__name__} failed: {type(e).__name__}: {e}")
        if log is None:
            traceback.print_exc()
        return default


class TTLCache:
    """Minimal thread-unsafe TTL cache for fetches inside one process."""

    def __init__(self, ttl_seconds: int = 900, max_items: int = 512):
        self.ttl = ttl_seconds
        self.max_items = max_items
        self._store: dict = {}

    def get(self, key):
        hit = self._store.get(key)
        if not hit:
            return None
        stamp, value = hit
        if time.time() - stamp > self.ttl:
            self._store.pop(key, None)
            return None
        return value

    def set(self, key, value):
        if len(self._store) >= self.max_items:
            # drop the oldest ~25% to keep memory bounded
            for k in sorted(self._store, key=lambda k: self._store[k][0])[: self.max_items // 4]:
                self._store.pop(k, None)
        self._store[key] = (time.time(), value)


CACHE = TTLCache(ttl_seconds=900)


def cached(key: str, producer, cache: TTLCache | None = None):
    """Fetch-through cache helper used by the data layer."""
    c = cache or CACHE
    hit = c.get(key)
    if hit is not None:
        return hit
    value = producer()
    if value is not None:
        c.set(key, value)
    return value
