# System Architecture - Indian Equity Multi-Agent Research System

## 1. High-level data flow

```
                          +-----------------------------+
                          |        DATA LAYER (free)    |
                          |  yf_client   nse_client     |
                          |  news_client macro_client   |
                          |  demo (offline mode)        |
                          +--------------+--------------+
                                         |
              +--------------------------+---------------------------+
              |                          |                           |
              v                          v                           v
   +--------------------+   +-----------------------+   +----------------------+
   | Stage 1-2: SCREEN  |   | Stage 3: MACRO+REGIME |   | Stage 4: DEEP DIVE   |
   | liquidity filter   |   | FII/DII, USD/INR,     |   | fundamentals (stmts),|
   | Technical Agent on |   | crude, SPX, VIX,      |   | symbol news, risk:   |
   | every usable name  |   | sectors, breadth ->   |   | Fundamental, News,   |
   | -> shortlist (12)  |   | Macro + Regime agents |   | Risk agents          |
   +---------+----------+   +-----------+-----------+   +----------+-----------+
             |                          |                          |
             +--------------------------+--------------------------+
                                        v
                        +-------------------------------+
                        |  Stage 5: MOTHER AGENT        |
                        |  cross-verify, veto gates,    |
                        |  composite conviction ranking |
                        |  -> 0/1/2 picks + trade plans |
                        +---------------+---------------+
                                        v
                        +-------------------------------+
                        |  Stage 6: REPORT              |
                        |  markdown + Streamlit UI      |
                        +-------------------------------+
```

The orchestrator (`engine/orchestrator.py`) executes six stages and emits progress
callbacks that the Streamlit app renders as live status boxes. **Every agent call is
failure-isolated**: a broken source yields an `AgentReport` with
`data_quality = UNAVAILABLE` and a neutral score - the run never crashes on data.

## 2. Why rule-based agents (no LLM)

The spec requires free data only and a fully working system. LLM calls would (a) cost
money, (b) make outputs non-reproducible, (c) add a network dependency that can fail.
Each agent is therefore a deterministic quantitative module with an explicit scoring
function - auditable, testable, and free forever. The "multi-agent" behaviour
(specialisation, independent reporting, cross-verification, final arbitration) is
preserved through the `AgentReport` contract and the Mother Agent's veto logic.

## 3. The AgentReport contract

Every specialist returns the same dataclass (`core/models.py`):

```python
AgentReport(agent_name, verdict, score 0-100, confidence 0-100,
            data_quality OK|DEGRADED|UNAVAILABLE,
            key_points[], risks[], details{...}, symbol, as_of)
```

`score` = "how supportive is this agent of a 1-4 week long". `confidence` = how much
the agent trusts its own inputs (data coverage based). `data_quality` propagates
honestly: the Mother Agent neutralises missing fundamentals (score 50, -3 conviction,
conviction capped at MEDIUM) instead of pretending data exists.

## 4. Composite conviction & veto gates (Mother Agent)

```
composite = 0.35*Technical + 0.20*Fundamental + 0.15*News
          + 0.15*SectorTailwind + 0.15*Risk
          + regime_adjust  (clamp((regime_score-50)/50*8, -10, +6))
          + sector_adjust  (clamp((tailwind-50)/50*4, -4, +4))
          - 8  if tech >= 65 but news < 35   (contradiction penalty)
          - 3  if fundamentals unavailable
          - 4  if risk score < 55
```

Hard gates applied in order (a candidate failing any is rejected with the reason
recorded and shown in the UI/report):

1. liquidity: 20d avg turnover >= `adv_min_cr`
2. news red flags (fraud / SEBI action / auditor exit / insolvency / pledge ...)
3. Risk score >= `min_risk_score` (45)
4. Technical score >= `min_tech_score` (55)
5. crisis gate: in CORRECTION / CRISIS-RISK regimes require composite >= threshold+6
   and tech >= 70
6. conviction: composite >= `min_conviction` (68)
7. reward-to-risk >= 1.0 on the built trade plan

Then: rank by composite, enforce sector diversification (different sectors preferred;
same sector only if composite is 8+ above the first pick), cap at `max_picks` (<= 2).
Zero survivors -> **"No high-conviction idea this week"** with the closest candidates
and their rejection reasons listed.

## 5. Expected-return & horizon methodology

Inputs: spot, ATR(21), stop (from Risk Agent), structural levels (3-month high,
20-day Donchian, 52-week high).

- **Conservative target**: nearest *meaningful* overhead resistance (>= 1.5% above
  spot) within reach, else `spot + max(1.2*ATR21, 1.2*stop_distance)`.
- **Optimistic target**: second resistance, or 52-week high, or `spot + 2.4*ATR21`;
  always at least `1.6 * stop_distance` above spot; hard caps: `+3*ATR21` from
  structure and `+10%` absolute (28-day sanity bound).
- **Price-discovery rule**: at/within 2% of the 52-week high there is no overhead
  supply, so targets are pure ATR projections (no artificial ceiling at the high).
- **Horizon**: `days = clamp(round(9 * m^1.4), 8, 28)` where `m = (optimistic
  target - spot)/ATR21` - a diffusion-inspired scaling of distance-in-ATRs to time,
  always within the 4-week cap.
- **Position size**: `shares = floor(capital * risk% / (spot - stop))`, capped by
  `max_position_pct` of capital. Max loss at stop = capital * risk%.

## 6. Regime classification & 4-week Nifty outlook

Inputs: Nifty EMAs 20/50/200, ADX(14)/DI, 20-day return, India VIX, breadth
(% of the scanned universe above its 50/200-DMA - computed from the same batch
download, no extra cost), macro score, FII 5-session net, market-news mood.

| Condition (evaluated top-down) | Regime | Bull/Base/Bear priors |
|---|---|---|
| VIX > 26 or 20d return < -8% | CRISIS-RISK | 5/25/70 |
| below 200-DMA | CORRECTION | 10/35/55 |
| > 200-DMA, > 50-DMA, ret20 > 3%, breadth50 > 60%, ADX >= 20, +DI > -DI | STRONG BULL | 45/40/15 |
| > 200-DMA, > 50-DMA, ADX >= 18, +DI > -DI | BULL | 35/45/20 |
| > 200-DMA, < 50-DMA, breadth50 > 45% | BULL PULLBACK | 30/45/25 |
| > 200-DMA, < 50-DMA, breadth50 <= 45% | DISTRIBUTION | 15/45/40 |
| else | RANGE-BOUND | 25/50/25 |

The 4-week expected move is `ATR(21) * sqrt(21)` (1 sigma). Scenario levels are
expressed from that: bull target ~ +1 sigma (at least the 3-month resistance), base
range +/-0.3-0.4 sigma, bear target below support-1. Macro tilt nudges probabilities
by up to 8 points (renormalised). Support/resistance come from EMAs and 3-month
swings - never invented.

## 7. Data-source resilience matrix

| Failure | Detection | Behaviour |
|---|---|---|
| Yahoo `.info` crumb blocked (401/429) | empty info dict | fundamentals from quarterly statements + fast_info; `data_quality=DEGRADED`; conviction capped |
| NSE FII/DII 403 (non-Indian IP) | HTTP status / exception | macro driver neutralised + explicit "unavailable" note in report/UI |
| Single ticker dead (renamed/delisted) | missing in batch result | skipped from universe, logged |
| News feed down | feedparser exception / 0 entries | symbol news neutral (score 50, low confidence) |
| No network at all | all fetches fail | agents degrade; Mother likely outputs "No high-conviction idea" - or use `--demo` |

## 8. Web application

`app.py` (Streamlit):

- Sidebar: universe scope, max picks, deep-dive size, conviction threshold, capital,
  risk per trade, liquidity floor, demo toggle, **Run** button.
- Live per-stage status (`st.status`) driven by orchestrator progress callbacks.
- Results page: Mother Agent final recommendation as prominent bordered cards
  (with price + EMA chart per pick), 4-week Nifty outlook (narrative + levels table +
  scenario odds + Nifty chart), Macro/Regime agent expanders, candidate scoreboard
  table, per-candidate agent expanders, rejected-ideas list with reasons, data-quality
  notes, and a **Markdown report download**.
- Results persist in `st.session_state` across reruns; data layer has a 15-minute
  process-level TTL cache so sidebar tweaks do not refetch everything.

## 9. Testing

- `tests/smoke_test.py` - full pipeline end-to-end (demo / live / tiny universes),
  prints the mandated final-output format and saves the report.
- `tests/app_test.py` - Streamlit **AppTest**: renders the real app, checks the demo
  checkbox, clicks Run, and asserts the final recommendation, outlook, scoreboard and
  download control render without exceptions.
- Deterministic demo mode (seeded RNG per symbol) makes UI walkthroughs reproducible.

## 10. Limitations (by design, disclosed)

- Free-data ceiling: no real-time quotes, no options chain, no paid newsroom content.
- News sentiment is keyword-based - transparent but coarse.
- Peer valuation medians are computed within the deep-dive pool only (free data
  constraint); the valuation method used is always printed in the report.
- Promoter holding is approximated by Yahoo's insider-held % when `.info` is
  reachable; otherwise reported as unavailable.
- Index constituents are a config file - review them periodically (post-demerger
  tickers like Tata Motors may need updates).
