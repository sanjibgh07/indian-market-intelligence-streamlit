"""Market Regime Agent - Nifty regime classification + 4-week Nifty outlook.

Uses only free inputs: Nifty OHLCV, India VIX, market breadth computed from
the universe's batch price data, macro score and market-news mood.

Regimes: STRONG BULL | BULL | BULL PULLBACK | RANGE-BOUND | DISTRIBUTION |
CORRECTION | CRISIS-RISK. Each regime carries a scenario probability table
for the 4-week Nifty outlook (bull / base / bear) - probabilities are
regime priors, adjusted modestly by macro score, never claimed to be precise.
"""
from __future__ import annotations

import numpy as np

from agents.base import BaseAgent
from analysis import indicators as ta
from core.models import Q_DEGRADED, Q_OK, verdict_from_score
from utils.helpers import clamp, r2

REGIME_PRIORS = {
    #                    bull, base, bear
    "STRONG BULL":     (0.45, 0.40, 0.15),
    "BULL":            (0.35, 0.45, 0.20),
    "BULL PULLBACK":   (0.30, 0.45, 0.25),
    "RANGE-BOUND":     (0.25, 0.50, 0.25),
    "DISTRIBUTION":    (0.15, 0.45, 0.40),
    "CORRECTION":      (0.10, 0.35, 0.55),
    "CRISIS-RISK":     (0.05, 0.25, 0.70),
}
REGIME_SCORE = {
    "STRONG BULL": 78, "BULL": 68, "BULL PULLBACK": 58, "RANGE-BOUND": 50,
    "DISTRIBUTION": 42, "CORRECTION": 32, "CRISIS-RISK": 22,
}


class RegimeAgent(BaseAgent):
    name = "Market Regime Agent"
    description = "Nifty regime + 4-week index outlook with levels and scenarios"

    def analyze(self, nifty_df, vix_close: float | None, breadth: dict,
                macro_score: float | None, fii_net_5s: float | None,
                news_mood: float | None = None) -> "AgentReport":  # noqa: F821
        try:
            return self._analyze(nifty_df, vix_close, breadth, macro_score,
                                 fii_net_5s, news_mood)
        except Exception as e:  # noqa: BLE001
            return self.fallback(why=str(e))

    # ------------------------------------------------------------------
    def _analyze(self, nifty_df, vix_close, breadth, macro_score, fii5, mood):
        c = nifty_df["Close"]
        spot = float(c.iloc[-1])
        e20, e50, e200 = (float(ta.ema(c, n).iloc[-1]) for n in (20, 50, 200))
        atr21 = float(ta.atr(nifty_df, 21).iloc[-1])
        ret20 = float(c.iloc[-1] / c.iloc[-21] - 1) * 100 if len(c) > 21 else float("nan")
        ret63 = float(c.iloc[-1] / c.iloc[-64] - 1) * 100 if len(c) > 64 else float("nan")
        adx14, pdi, mdi = (float(x.iloc[-1]) for x in ta.adx(nifty_df, 14))
        swing_high = float(ta.recent_high(c, 63).iloc[-1])
        swing_low = float(ta.recent_low(c, 63).iloc[-1])
        vix = vix_close if vix_close else float("nan")

        above200 = spot > e200
        above50 = spot > e50
        b50 = breadth.get("pct_above_50dma", 50.0)
        b200 = breadth.get("pct_above_200dma", 50.0)

        # ---------------- regime classification ---------------------------
        if (vix == vix and vix > 26) or ret20 < -8:
            regime = "CRISIS-RISK"
        elif not above200:
            regime = "CORRECTION"
        elif above200 and above50 and ret20 > 3 and b50 > 60 and adx14 >= 20 and pdi > mdi:
            regime = "STRONG BULL"
        elif above200 and above50 and adx14 >= 18 and pdi > mdi:
            regime = "BULL"
        elif above200 and not above50:
            regime = "BULL PULLBACK" if b50 > 45 else "DISTRIBUTION"
        else:
            regime = "RANGE-BOUND"

        # small, transparent nudges from macro / flows / news mood
        adj = 0.0
        if macro_score is not None:
            adj += clamp((macro_score - 50) / 50 * 6, -6, 6)
        if fii5 is not None:
            adj += clamp(fii5 / 15000 * 4, -4, 4)
        if mood is not None:
            adj += clamp((mood - 50) / 50 * 2, -2, 2)
        r_score = clamp(REGIME_SCORE[regime] + adj, 0, 100)

        # ---------------- 4-week expected move --------------------------------
        em_4w = atr21 * np.sqrt(21)          # diffusion-scaled 4-week move (1 sigma)
        bull_p, base_p, bear_p = REGIME_PRIORS[regime]
        if macro_score is not None:  # re-normalise modestly toward macro tilt
            tilt = clamp((macro_score - 50) / 50, -1, 1) * 0.08
            bull_p = clamp(bull_p + tilt, 0.03, 0.85)
            bear_p = clamp(bear_p - tilt, 0.03, 0.85)
            tot = bull_p + base_p + bear_p
            bull_p, base_p, bear_p = bull_p / tot, base_p / tot, bear_p / tot

        levels = {
            "spot": r2(spot), "ema20": r2(e20), "ema50": r2(e50), "ema200": r2(e200),
            "resistance_1": r2(max(swing_high, spot + 0.5 * em_4w)),
            "support_1": r2(min(max(e50, swing_low), spot - 0.5 * em_4w)),
            "support_2": r2(min(e200, swing_low - 0.5 * em_4w)),
            "atr21": r2(atr21), "expected_move_4w_1sigma": r2(em_4w),
            "swing_high_3m": r2(swing_high), "swing_low_3m": r2(swing_low),
        }
        s1 = levels["support_1"]
        scenarios = {
            "bull": {"prob": round(bull_p * 100), "target": r2(max(spot + 1.0 * em_4w, levels["resistance_1"])),
                     "stretch": r2(spot + 1.6 * em_4w)},
            "base": {"prob": round(base_p * 100),
                     "range_low": r2(spot - 0.3 * em_4w),
                     "range_high": r2(spot + 0.4 * em_4w)},
            # bear targets must sit *below* support-1 to stay coherent
            "bear": {"prob": round(bear_p * 100), "target": r2(min(spot - 1.0 * em_4w, s1 - 0.25 * em_4w)),
                     "stretch": r2(min(spot - 1.6 * em_4w, s1 - 0.8 * em_4w))},
        }

        # ---------------- narrative -------------------------------------------
        regime_line = {
            "STRONG BULL": "Nifty is in a strong uptrend above rising 50/200-DMA with healthy breadth - dips are being bought.",
            "BULL": "Nifty is in an established uptrend; momentum is positive but not euphoric.",
            "BULL PULLBACK": "Long-term trend is up but the index is digesting gains below the 50-DMA - mixed tape.",
            "RANGE-BOUND": "Nifty is moving sideways without directional conviction - stock-specific action dominates.",
            "DISTRIBUTION": "Index above the 200-DMA but failing at highs with weak breadth - supply is active.",
            "CORRECTION": "Nifty is below its 200-DMA - the primary trend is down; longs need exceptional setups.",
            "CRISIS-RISK": "Volatility has spiked and/or the index is in a steep drawdown - capital-preservation mode.",
        }[regime]

        outlook = (
            f"Regime: {regime}. {regime_line} "
            f"Breadth: {b50:.0f}% of the tracked universe above its 50-DMA and {b200:.0f}% above the 200-DMA. "
            f"4-week expected move (1 sigma, from ATR): about +/-{em_4w / spot * 100:.1f}% around {spot:,.0f}. "
            f"Over the next four weeks the base case ({scenarios['base']['prob']}%) is a "
            f"{scenarios['base']['range_low']:,.0f}-{scenarios['base']['range_high']:,.0f} grind; "
            f"a push toward {scenarios['bull']['target']:,.0f} ({scenarios['bull']['prob']}% odds, "
            f"stretch {scenarios['bull']['stretch']:,.0f}) needs the index to hold above "
            f"{levels['support_1']:,.0f}; a break below {levels['support_1']:,.0f} opens "
            f"{scenarios['bear']['target']:,.0f} ({scenarios['bear']['prob']}% odds, "
            f"stretch {scenarios['bear']['stretch']:,.0f}), with deeper support near "
            f"{levels['support_2']:,.0f} (200-DMA zone {levels['ema200']:,.0f})."
        )

        kps = [
            f"Nifty {spot:,.1f} | EMA20/50/200 {e20:,.0f}/{e50:,.0f}/{e200:,.0f} | ADX {adx14:.0f}",
            f"Returns: 20d {ret20:+.1f}% | 63d {ret63:+.1f}% | India VIX {vix:.1f}",
            f"Breadth: {b50:.0f}% > 50-DMA, {b200:.0f}% > 200-DMA",
            f"4-week 1-sigma expected move: +/-{em_4w:,.0f} pts ({em_4w / spot * 100:.1f}%)",
        ]
        risks = [
            f"Regime flips quickly: a close below {levels['support_1']:,.0f} would downgrade the view",
            "Event risk inside 4 weeks (RBI/Fed/global headlines) can override regime statistics",
        ]

        details = {"regime": regime, "levels": levels, "scenarios": scenarios,
                   "macro_adjustment": r2(adj),
                   "breadth": {k: r2(v) for k, v in breadth.items()}}
        q = Q_OK if len(nifty_df) >= 200 else Q_DEGRADED
        rep = self.report(verdict=verdict_from_score(r_score), score=r_score,
                          confidence=clamp(60 + (10 if q == Q_OK else 0), 30, 85),
                          data_quality=q, key_points=kps, risks=risks,
                          details=details)
        # attach outlook pieces for the orchestrator/app
        rep.details["outlook_text"] = outlook
        return rep
