"""yfinance data client (free) - prices, market cap, quarterly statements.

All functions are fault-tolerant: they return empty/None on failure instead of
raising, and they pass through a small TTL cache so repeated Streamlit reruns
do not hammer Yahoo.
"""
from __future__ import annotations

import time
import warnings

import pandas as pd

warnings.filterwarnings("ignore")

from utils.helpers import CACHE, cached, safe_call

NIFTY = "^NSEI"
INDIA_VIX = "^INDIAVIX"


def _clean(df: pd.DataFrame) -> pd.DataFrame:
    """Normalise a yfinance OHLCV frame: tz-naive index, positive rows only."""
    if df is None or len(df) == 0:
        return pd.DataFrame()
    df = df.copy()
    # newer yfinance wraps even single-ticker frames in MultiIndex columns
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = [c[0] if isinstance(c, tuple) else c for c in df.columns]
    try:
        df.index = pd.to_datetime(df.index).tz_localize(None)
    except (TypeError, AttributeError):
        pass
    df = df.loc[:, ~pd.Index(df.columns).duplicated()]
    if not {"Open", "High", "Low", "Close", "Volume"}.issubset(df.columns):
        return pd.DataFrame()
    df = df[["Open", "High", "Low", "Close", "Volume"]].dropna(how="all")
    df = df[df["Close"].notna() & (df["Close"] > 0)]
    return df.sort_index()


def download_prices(symbols: list[str], period: str = "1y", log=print) -> dict[str, pd.DataFrame]:
    """Batch-download daily OHLCV for many NSE symbols (`.NS` suffix).

    Returns {symbol_without_suffix: DataFrame}. Symbols that Yahoo cannot
    resolve are silently dropped (logged once).
    """
    if not symbols:
        return {}
    tickers = [s if s.endswith(".NS") else f"{s}.NS" for s in symbols]
    set_period_for_fallback(period)  # used by the per-symbol fallback path

    def _dl(tick_list: list[str]):
        return yf_download(tick_list, period)

    raw = cached(f"prices|{period}|{','.join(sorted(tickers))}",
                 lambda: _retry_batch(_dl, tickers, log), cache=CACHE)
    if raw is None:
        return {}

    out: dict[str, pd.DataFrame] = {}
    if isinstance(raw.columns, pd.MultiIndex):
        # yfinance group_by='ticker' -> columns (ticker, field); handle the
        # (field, ticker) order too, and per-symbol fallback frames.
        lvl0 = {c[0] for c in raw.columns}
        lvl1 = {c[1] for c in raw.columns if len(c) > 1}
        if set(tickers) & lvl0:
            getter, have = (lambda t: raw[t]), set(tickers) & lvl0
        elif set(tickers) & lvl1:
            getter = lambda t: raw.xs(t, axis=1, level=1)  # noqa: E731
            have = set(tickers) & lvl1
        else:
            getter, have = None, set()
        for t in tickers:
            if t not in have:
                log(f"[yf] no data for {t}, skipping")
                continue
            df = _clean(getter(t))
            if len(df) >= 30:
                out[t[:-3]] = df
    else:  # single-symbol call
        df = _clean(raw)
        if len(df) >= 30 and tickers:
            out[tickers[0][:-3]] = df
    return out


def yf_download(tick_list: list[str], period: str):
    import yfinance as yf
    return yf.download(
        " ".join(tick_list), period=period, interval="1d",
        group_by="ticker", auto_adjust=True, progress=False, threads=True,
    )


def _retry_batch(dl, tickers: list[str], log=print, attempts: int = 2):
    """Batch download with one retry; falls back to per-symbol on repeated failure."""
    last_err = None
    for i in range(attempts):
        try:
            return dl(tickers)
        except Exception as e:  # noqa: BLE001
            last_err = e
            log(f"[yf] batch attempt {i + 1} failed: {type(e).__name__}: {e}")
            time.sleep(1.5)
    log(f"[yf] batch failed entirely ({last_err}); trying per-symbol fallback")
    out = None
    import pandas as pd
    frames = {}
    for t in tickers:
        try:
            import yfinance as yf
            d = yf.download(t, period=period_key(tickers), interval="1d",
                            auto_adjust=True, progress=False)
            if d is not None and len(d):
                frames[t] = d
        except Exception:  # noqa: BLE001
            continue
        time.sleep(0.1)
    if frames:
        out = pd.concat(frames, names=["Ticker", "Date"]).unstack(level=0)
        out.columns = out.columns.swaplevel(0, 1)
    return out


def period_key(_tickers: list[str]) -> str:
    # per-symbol fallback re-uses the same window
    return _PERIOD_HOLDER.get("p", "1y")


_PERIOD_HOLDER: dict = {"p": "1y"}


def set_period_for_fallback(period: str):
    _PERIOD_HOLDER["p"] = period


def fetch_index(symbol: str, period: str = "6mo") -> pd.DataFrame:
    """Download a single index/series (e.g. ^NSEI, ^INDIAVIX)."""
    def _p():
        import yfinance as yf
        df = yf.download(symbol, period=period, interval="1d",
                         auto_adjust=True, progress=False)
        return _clean(df)
    out = cached(f"index|{symbol}|{period}",
                 lambda: safe_call(_p, default=None, label=f"index {symbol}"), cache=CACHE)
    return out if out is not None and len(out) else pd.DataFrame()


def fetch_fast_info(symbol: str, log=print) -> dict:
    """Crumb-free quote facts: last price + market cap (works even when .info is blocked)."""
    def _p():
        import yfinance as yf
        fi = yf.Ticker(f"{symbol}.NS").fast_info
        return {
            "last_price": float(getattr(fi, "last_price", None) or 0) or None,
            "market_cap": float(getattr(fi, "market_cap", None) or 0) or None,
            "currency": getattr(fi, "currency", "INR"),
            "exchange": getattr(fi, "exchange", "NSE"),
        }
    return cached(f"fastinfo|{symbol}", lambda: safe_call(_p, default={}, label=f"fast_info {symbol}", log=log), cache=CACHE) or {}


def fetch_info(symbol: str, log=print) -> dict:
    """Best-effort rich `.info` (needs Yahoo crumb; blocked on some networks).

    Returns {} when unavailable - the fundamental agent falls back to
    statements-derived metrics in that case.
    """
    def _p():
        import yfinance as yf
        info = yf.Ticker(f"{symbol}.NS").info or {}
        return info if isinstance(info, dict) else {}
    return cached(f"info|{symbol}", lambda: safe_call(_p, default={}, label=f"info {symbol}", log=log), cache=CACHE) or {}


def _stmt(symbol: str, attr: str, log=print):
    def _p():
        import yfinance as yf
        t = yf.Ticker(f"{symbol}.NS")
        df = getattr(t, attr)
        if df is None or not len(df):
            return None
        return df
    return cached(f"{attr}|{symbol}", lambda: safe_call(_p, default=None, label=f"{attr} {symbol}", log=log), cache=CACHE)


def fetch_quarterly_fundamentals(symbol: str, log=print) -> dict:
    """Derive clean fundamentals from yfinance quarterly statements (crumb-free).

    Returns dict with: revenue_ttm, ni_ttm, rev_yoy, ni_yoy, q_rev_yoy,
    margin_ttm, debt, equity, de_ratio, roe, fcf_ttm, pe, pb, quarters_covered.
    Any missing piece stays None.
    """
    out: dict = {}

    inc = _stmt(symbol, "quarterly_income_stmt", log)
    bs = _stmt(symbol, "quarterly_balance_sheet", log)
    cf = _stmt(symbol, "quarterly_cash_flow", log)

    def col(df, *names):
        if df is None:
            return None
        for want in names:
            for idx in df.index:
                if str(idx).lower() == want.lower():
                    s = df.loc[idx].dropna()
                    if len(s):
                        return s.sort_index(ascending=False)  # newest first
        return None

    if inc is not None:
        rev = col(inc, "Total Revenue")
        ni = col(inc, "Net Income Common Stockholders", "Net Income")
        if rev is not None and len(rev) >= 5:
            out["rev_q1"] = float(rev.iloc[0]); out["rev_q5"] = float(rev.iloc[4])
            out["rev_ttm"] = float(rev.iloc[:4].sum())
            out["rev_yoy"] = (out["rev_q1"] / out["rev_q5"] - 1.0) * 100 if out["rev_q5"] else None
        if rev is not None and len(rev) >= 2:
            out["rev_qoq"] = (float(rev.iloc[0]) / float(rev.iloc[1]) - 1.0) * 100 if float(rev.iloc[1]) else None
        if ni is not None and len(ni) >= 5:
            out["ni_q1"] = float(ni.iloc[0]); out["ni_q5"] = float(ni.iloc[4])
            out["ni_ttm"] = float(ni.iloc[:4].sum())
            out["ni_yoy"] = (out["ni_q1"] / out["ni_q5"] - 1.0) * 100 if out["ni_q5"] else None
        if rev is not None and ni is not None and len(rev) >= 4 and len(ni) >= 4:
            r, n = float(rev.iloc[:4].sum()), float(ni.iloc[:4].sum())
            if r:
                out["margin_ttm"] = n / r * 100
        out["quarters_covered"] = int(len(inc.columns))

    if bs is not None:
        debt = col(bs, "Total Debt")
        eq = col(bs, "Stockholders Equity", "Common Stock Equity", "Total Equity Gross Minority Interest")
        if debt is not None and len(debt):
            out["debt"] = float(debt.iloc[0])
        if eq is not None and len(eq):
            out["equity"] = float(eq.iloc[0])
        if out.get("debt") is not None and out.get("equity") and out["equity"] > 0:
            out["de_ratio"] = out["debt"] / out["equity"]
            ni_ttm = out.get("ni_ttm")
            if ni_ttm:
                out["roe"] = ni_ttm / out["equity"] * 100

    if cf is not None:
        fcf = col(cf, "Free Cash Flow")
        if fcf is not None and len(fcf) >= 4:
            out["fcf_ttm"] = float(fcf.iloc[:4].sum())

    # valuation from fast_info market cap
    fi = fetch_fast_info(symbol, log=log)
    mcap = fi.get("market_cap")
    if mcap:
        out["market_cap"] = float(mcap)
        if out.get("ni_ttm"):
            out["pe"] = mcap / out["ni_ttm"] if out["ni_ttm"] > 0 else None
        if out.get("equity") and out["equity"] > 0:
            out["pb"] = mcap / out["equity"]
    return out
