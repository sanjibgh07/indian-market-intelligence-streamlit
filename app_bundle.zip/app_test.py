"""UI-level test using Streamlit's official AppTest framework.

Runs the real app.py, enables demo mode, clicks the run button, and verifies
that the Mother Agent's final recommendation, the Nifty outlook and the
download control actually render.

Usage:  python tests/app_test.py
"""
from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from streamlit.testing.v1 import AppTest  # noqa: E402


def main() -> int:
    at = AppTest.from_file(os.path.join(os.path.dirname(__file__), "..", "app.py"),
                           default_timeout=600)
    at.run()
    assert not at.exception, f"App raised: {at.exception}"

    # enable demo mode and trigger the run button
    demo_box = next((c for c in at.checkbox if "Demo mode" in (c.label or "")), None)
    if demo_box is not None:
        demo_box.check().run()
    btns = list(at.button)
    assert btns, "run button not found"
    btns[0].click()
    at.run()

    assert not at.exception, f"App raised during research run: {at.exception}"
    body = "\n".join(str(x.body) for x in at.markdown) + "\n" + \
           "\n".join(str(x.body) for x in at.info) + "\n" + \
           "\n".join(str(x.body) for x in at.warning) + "\n" + \
           "\n".join(str(x.body) for x in at.error) + "\n" + \
           "\n".join(str(x.value) for x in at.subheader) + "\n" + \
           "\n".join(str(x.label) for x in at.download_button)

    checks = {
        "final recommendation section": "Mother Agent" in body or "Final Recommendation" in body,
        "nifty outlook section": "4-Week Nifty Outlook" in body,
        "expected return text": "Expected Return" in body or "No high-conviction idea" in body,
        "download control": "Download" in body or "Download" in str([b.label for b in at.button]),
        "scoreboard": "Candidate Scoreboard" in body,
    }
    ok = True
    for name, passed in checks.items():
        print(f"[{'OK' if passed else 'FAIL'}] {name}")
        ok &= passed

    if not ok:
        print("\n---- captured body (first 3000 chars) ----")
        print(body[:3000])
    print("\nAPP TEST " + ("PASS" if ok else "FAIL"))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
