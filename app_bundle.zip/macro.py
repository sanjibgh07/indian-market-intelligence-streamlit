"""Macro & Sector Agent - FII/DII flows, USD/INR, crude, global cues, sectors.

Inputs are plain dicts from the data layer (all free sources). If a driver is
unavailable it contributes 0 (neutral) and is disclosed - never fabricated.

Output: risk-appetite score 0-100 + sector tailwind table (20-day sector
index momentum vs Nifty) used to adjust each candidate.
"""
from __future__ import annotations

import numpy as np

from agents.base import BaseAgent
from core.models import Q_DEGRADED, Q_OK, RISK_OFF, RISK_ON, verdict_from_score
from utils.helpers import clamp, r2


class MacroAgent(BaseAgent):
    name = "Macro & Sector Agent"
    description = "FII/DII flows, currency, crude, global cues, sector momentum"

    def analyze(self, macro: dict, fii_rows: list[dict], nifty_ret_20d: float | None = None) -> "AgentReport":  # noqa: F821
        try:
            return self._analyze(macro, fii_rows, nifty_ret_20d)
        except Exception as e:  # noqa: BLE001
            return self.fallback(why=str(e))

    # ------------------------------------------------------------------
    def _analyze(self, macro, fii_rows, nifty_ret_20d):
        g = lambda k: (macro or {}).get(k) or {}  # noqa: E731
        usdinr, crude, spx, vix = g("usdinr"), g("crude"), g("spx"), g("vix")

        score = 50.0
        kps: list[str] = []
        notes: list[str] = []
        available = 0

        # ---- FII / DII cash flows (Rs crore) -----------------------------
        fii5 = sum((r.get("fii_net") or 0.0) for r in (fii_rows or [])[:5])
        dii5 = sum((r.get("dii_net") or 0.0) for r in (fii_rows or [])[:5])
        if fii_rows:
            available += 1
            if fii5 > 3000:
                score += 12
            elif fii5 > 0:
                score += 7
            elif fii5 > -3000:
                score -= 4
            else:
                score -= 12
            if dii5 > 0:
                score += 5
            elif dii5 < -2000:
                score -= 5
            kps.append(f"FII net (5 sessions): {fii5:+,.0f} cr | DII net: {dii5:+,.0f} cr")
        else:
            notes.append("FII/DII flows unavailable (NSE blocks this network) - neutral assumption applied")

        # ---- USD/INR -------------------------------------------------------
        if usdinr:
            available += 1
            c20 = usdinr.get("chg_20d", 0.0)
            if c20 <= 0:
                score += 10
            elif c20 <= 0.5:
                score += 6
            elif c20 <= 1.5:
                score += 0
            else:
                score -= 8
            kps.append(f"USD/INR {usdinr.get('last', 0):.2f} | 20d change {c20:+.2f}% "
                       f"({'supportive' if c20 <= 0.5 else 'outflow pressure'})")
        else:
            notes.append("USD/INR unavailable - neutral")

        # ---- Crude -----------------------------------------------------------
        if crude:
            available += 1
            c20 = crude.get("chg_20d", 0.0)
            if c20 <= 0:
                score += 8
            elif c20 <= 5:
                score += 4
            elif c20 <= 10:
                score += 0
            else:
                score -= 6
            kps.append(f"Brent ${crude.get('last', 0):.1f} | 20d change {c20:+.1f}% "
                       f"({'benign' if c20 <= 5 else 'inflationary risk'})")
        else:
            notes.append("Crude unavailable - neutral")

        # ---- Global risk appetite (S&P 500) ---------------------------------
        if spx:
            available += 1
            c20 = spx.get("chg_20d", 0.0)
            if c20 > 0:
                score += 8
            elif c20 > -3:
                score += 3
            else:
                score -= 6
            kps.append(f"S&P 500 20d change {c20:+.1f}% (global cue)")
        else:
            notes.append("S&P 500 unavailable - neutral")

        # ---- India VIX ---------------------------------------------------------
        if vix:
            available += 1
            lvl = vix.get("last", 15.0)
            c5 = vix.get("chg_5d", 0.0)
            if lvl < 14:
                score += 8
            elif lvl < 18:
                score += 4
            elif lvl < 24:
                score += 0
            else:
                score -= 8
            kps.append(f"India VIX {lvl:.1f} ({'calm' if lvl < 15 else 'elevated' if lvl < 22 else 'stressed'}), 5d change {c5:+.1f}%")
        else:
            notes.append("India VIX unavailable - neutral")

        # ---- Nifty 20d momentum (context) --------------------------------------
        if nifty_ret_20d is not None:
            kps.append(f"Nifty 20-day return: {nifty_ret_20d:+.1f}%")

        # ---- Sector momentum table (tailwind per sector) ------------------------
        sectors = (macro or {}).get("sectors", {}) or {}
        tailwind: dict[str, float] = {}
        for sector, s in sectors.items():
            c20 = s.get("chg_20d", 0.0)
            if c20 >= 2.5:
                tw = 72.0
            elif c20 >= 0.5:
                tw = 62.0
            elif c20 >= -2.0:
                tw = 50.0
            elif c20 >= -5.0:
                tw = 40.0
            else:
                tw = 32.0
            tailwind[sector] = tw
        if sectors:
            top = sorted(sectors.items(), key=lambda kv: kv[1].get("chg_20d", -99), reverse=True)[:3]
            kps.append("Strongest sectors (20d): " +
                       "; ".join(f"{k} {v.get('chg_20d', 0):+.1f}%" for k, v in top))

        score = clamp(score, 0, 100)
        verdict = RISK_ON if score >= 62 else (RISK_OFF if score < 45 else "NEUTRAL")
        conf = clamp(40 + available * 8, 25, 85)
        q = Q_OK if available >= 4 else Q_DEGRADED

        details = {
            "fii_net_5s_cr": r2(fii5) if fii_rows else None,
            "dii_net_5s_cr": r2(dii5) if fii_rows else None,
            "usdinr": {k: r2(v) for k, v in usdinr.items() if isinstance(v, (int, float))},
            "crude": {k: r2(v) for k, v in crude.items() if isinstance(v, (int, float))},
            "spx": {k: r2(v) for k, v in spx.items() if isinstance(v, (int, float))},
            "vix": {k: r2(v) for k, v in vix.items() if isinstance(v, (int, float))},
            "sector_tailwind": {k: r2(v) for k, v in tailwind.items()},
            "drivers_available": available,
            "neutral_notes": notes,
        }
        risks = notes + [
            "Macro regime can flip on a single global event (crude spike, tariff, war headline)",
        ]
        return self.report(verdict=verdict, score=score, confidence=conf,
                           data_quality=q, key_points=kps, risks=risks,
                           details=details)

    def sector_tailwind(self, sector: str, details: dict | None = None) -> float:
        """Tailwind score 0-100 for a sector (50 = neutral/unknown).

        The orchestrator passes the macro report's details; if the sector is
        unmapped or data missing, 50 (neutral) is returned - never invented.
        """
        tw = (details or {}).get("sector_tailwind", {})
        return float(tw.get(sector, 50.0))
