@echo off
REM Convenience launcher - Indian Equity Multi-Agent Research System
cd /d "%~dp0"

if not exist ".venv" (
    echo Creating virtual environment...
    python -m venv .venv
    call .venv\Scripts\activate
    pip install -r requirements.txt
) else (
    call .venv\Scripts\activate
)

echo Starting Streamlit app: http://localhost:8501
streamlit run app.py
