"""Risk Agent - volatility, liquidity, stops, position sizing for 1-4 week holds.

Output score 0-100 = "how safe is this name for a 4-week tactical long"
(higher is better). Produces the stop level and position size consumed by the
Mother Agent's final recommendation.
"""
from __future__ import annotations

import numpy as np

from agents.base import BaseAgent
from analysis import indicators as ta
from core.models import Q_DEGRADED, Q_OK, verdict_from_score
from utils.helpers import clamp, r2


class RiskAgent(BaseAgent):
    name = "Risk Agent"
    description = "Volatility, liquidity, stop levels and position sizing"

    def analyze(self, symbol: str, df, bench_close, spot: float,
                adv_min_cr: float, capital: float,
                risk_per_trade_pct: float, max_position_pct: float) -> "AgentReport":  # noqa: F821
        try:
            return self._analyze(symbol, df, bench_close, spot, adv_min_cr,
                                 capital, risk_per_trade_pct, max_position_pct)
        except Exception as e:  # noqa: BLE001
            return self.fallback(symbol, why=str(e))

    # ------------------------------------------------------------------
    def _analyze(self, symbol, df, bench_close, spot, adv_min_cr,
                 capital, risk_pct, max_pos_pct):
        c = df["Close"]
        atr14 = float(ta.atr(df, 14).iloc[-1])
        atr_pct = atr14 / spot * 100
        vol20 = float(ta.realized_vol(c, 20).iloc[-1]) * 100
        vol_series = ta.realized_vol(c, 20).dropna().tail(250)
        vol_pctile = float((vol_series < vol_series.iloc[-1]).mean() * 100) if len(vol_series) > 60 else float("nan")
        dd6m = ta.max_drawdown(c, 126) * 100
        beta = ta.beta(c, bench_close) if bench_close is not None else float("nan")
        adv_cr = ta.avg_daily_turnover_cr(df, 20)
        low63 = float(ta.recent_low(c, 63).iloc[-1])

        # ---------------- stop level ---------------------------------------
        swing_stop = low63 - 0.5 * atr14
        atr_stop = spot - 2.2 * atr14
        stop = max(swing_stop, atr_stop)
        # keep the stop a sane distance away (>= 2.5% and <= 9% for a 4-week hold)
        stop = min(stop, spot * (1 - 0.025))
        stop = max(stop, spot * (1 - 0.09))
        stop_dist_pct = (spot - stop) / spot * 100

        # ---------------- liquidity ------------------------------------------
        liq_pass = adv_cr >= adv_min_cr
        liq_margin = adv_cr / adv_min_cr if adv_min_cr else float("nan")

        # ---------------- risk score -------------------------------------------
        score = 60.0
        if liq_pass:
            score += 8 if liq_margin >= 3 else 5
        else:
            score -= 25
        if vol20 < 25: score += 10
        elif vol20 < 35: score += 6
        elif vol20 < 50: score += 2
        else: score -= 6
        if vol_pctile == vol_pctile and vol_pctile > 85: score -= 6  # vol regime spiking
        if atr_pct < 1.5: score += 8
        elif atr_pct < 2.5: score += 5
        elif atr_pct < 3.5: score += 2
        else: score -= 4
        if beta == beta:
            score += 4 if beta < 1.2 else (2 if beta < 1.6 else 0)
        if dd6m > -12: score += 6
        elif dd6m > -20: score += 3
        if stop_dist_pct < 3.5: score -= 2      # too tight - noise will stop us out
        if stop_dist_pct > 8: score -= 4        # too wide - poor R:R for 4 weeks
        score = clamp(score, 0, 100)

        # ---------------- position sizing ----------------------------------------
        risk_amount = capital * risk_pct / 100.0
        per_share = spot - stop
        shares = int(risk_amount / per_share) if per_share > 0 else 0
        pos_value = shares * spot
        cap_value = capital * max_pos_pct / 100.0
        if pos_value > cap_value and pos_value > 0:
            shares = int(cap_value / spot)
            pos_value = shares * spot
        position_pct = pos_value / capital * 100 if capital else 0.0

        verdict = verdict_from_score(score)
        label = ("LOW RISK" if score >= 70 else
                 "ACCEPTABLE" if score >= 58 else
                 "ELEVATED" if score >= 48 else "HIGH RISK")

        kps = [
            f"Liquidity: 20d avg turnover Rs {adv_cr:,.0f} cr "
            f"({'PASS' if liq_pass else 'FAIL'} vs Rs {adv_min_cr:,.0f} cr floor)",
            f"Volatility: 20d annualised {vol20:.0f}% (1y percentile {vol_pctile:.0f}) | ATR {atr_pct:.1f}% of price",
            f"Beta vs Nifty {beta:.2f} | 6-month max drawdown {dd6m:.1f}%",
            f"Suggested stop: {stop:,.1f} (-{stop_dist_pct:.1f}%) = max(63d swing low - 0.5 ATR, spot - 2.2 ATR), bounded 2.5-9%",
            f"Position size: {shares:,} shares (Rs {pos_value:,.0f}, {position_pct:.1f}% of capital) "
            f"for max {risk_pct:.1f}% capital risk = Rs {risk_amount:,.0f}",
        ]
        risks = [
            f"Gap risk: overnight/global gaps can jump past the {stop:,.1f} stop",
            "Illiquid tape on result days: use limit orders near VWAP",
        ] + ([] if liq_pass else [f"LIQUIDITY FAIL: turnover Rs {adv_cr:,.0f} cr below floor - untradeable at size"])

        details = {
            "adv_cr": r2(adv_cr), "liq_pass": bool(liq_pass),
            "vol20_ann_pct": r2(vol20), "vol_pctile_1y": r2(vol_pctile),
            "atr14": r2(atr14), "atr_pct": r2(atr_pct),
            "beta": r2(beta), "max_dd_6m_pct": r2(dd6m),
            "stop": r2(stop), "stop_dist_pct": r2(stop_dist_pct),
            "shares": shares, "position_value": r2(pos_value),
            "position_pct": r2(position_pct), "risk_amount": r2(risk_amount),
            "risk_label": label,
        }
        q = Q_OK if len(df) >= 200 else Q_DEGRADED
        return self.report(verdict=label, score=score,
                           confidence=clamp(60 + (10 if len(df) >= 240 else 0), 30, 85),
                           data_quality=q, key_points=kps, risks=risks,
                           details=details, symbol=symbol)
