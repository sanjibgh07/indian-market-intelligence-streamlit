"""Technical indicators implemented in pure pandas/numpy.

No TA-Lib / pandas-ta dependency: everything here is standard, deterministic
and works everywhere. All functions accept/return pandas objects aligned to
the input index.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


# ---------------------------------------------------------------- averages ---
def sma(s: pd.Series, n: int) -> pd.Series:
    return s.rolling(n, min_periods=n).mean()


def ema(s: pd.Series, n: int) -> pd.Series:
    return s.ewm(span=n, adjust=False, min_periods=n).mean()


# ------------------------------------------------------------- oscillators ---
def rsi(close: pd.Series, n: int = 14) -> pd.Series:
    """Wilder's RSI."""
    delta = close.diff()
    gain = delta.clip(lower=0.0)
    loss = (-delta).clip(lower=0.0)
    avg_gain = gain.ewm(alpha=1.0 / n, adjust=False, min_periods=n).mean()
    avg_loss = loss.ewm(alpha=1.0 / n, adjust=False, min_periods=n).mean()
    with np.errstate(divide="ignore", invalid="ignore"):
        rs = avg_gain / avg_loss
        out = 100.0 - 100.0 / (1.0 + rs)
    out = out.replace([np.inf, -np.inf], 100.0)
    return out.fillna(50.0)


def macd(close: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9):
    line = ema(close, fast) - ema(close, slow)
    sig = line.ewm(span=signal, adjust=False, min_periods=signal).mean()
    hist = line - sig
    return line, sig, hist


def adx(df: pd.DataFrame, n: int = 14):
    """Wilder's ADX; returns (adx, +DI, -DI)."""
    h, l = df["High"], df["Low"]
    up = h.diff()
    dn = -l.diff()
    plus_dm = pd.Series(np.where((up > dn) & (up > 0), up, 0.0), index=df.index)
    minus_dm = pd.Series(np.where((dn > up) & (dn > 0), dn, 0.0), index=df.index)
    tr = true_range(df)
    atr_ = tr.ewm(alpha=1.0 / n, adjust=False, min_periods=n).mean()
    pdi = 100.0 * plus_dm.ewm(alpha=1.0 / n, adjust=False, min_periods=n).mean() / atr_
    mdi = 100.0 * minus_dm.ewm(alpha=1.0 / n, adjust=False, min_periods=n).mean() / atr_
    with np.errstate(divide="ignore", invalid="ignore"):
        dx = 100.0 * (pdi - mdi).abs() / (pdi + mdi)
    adx_line = dx.ewm(alpha=1.0 / n, adjust=False, min_periods=n).mean()
    return adx_line, pdi, mdi


# ------------------------------------------------------------- volatility ---
def true_range(df: pd.DataFrame) -> pd.Series:
    h, l, c = df["High"], df["Low"], df["Close"]
    pc = c.shift(1)
    return pd.concat([(h - l), (h - pc).abs(), (l - pc).abs()], axis=1).max(axis=1)


def atr(df: pd.DataFrame, n: int = 14) -> pd.Series:
    return true_range(df).ewm(alpha=1.0 / n, adjust=False, min_periods=n).mean()


def realized_vol(close: pd.Series, n: int = 20) -> pd.Series:
    """Annualised realized volatility from daily closes."""
    ret = close.pct_change()
    return ret.rolling(n, min_periods=n // 2).std() * np.sqrt(252.0)


def bollinger(close: pd.Series, n: int = 20, k: float = 2.0):
    mid = sma(close, n)
    sd = close.rolling(n, min_periods=n).std()
    return mid + k * sd, mid, mid - k * sd


# ------------------------------------------------------------- structure ---
def donchian_high(df: pd.DataFrame, n: int = 20) -> pd.Series:
    """Upper Donchian channel of the *previous* n sessions (breakout level)."""
    return df["High"].rolling(n, min_periods=n).max().shift(1)


def donchian_low(df: pd.DataFrame, n: int = 20) -> pd.Series:
    return df["Low"].rolling(n, min_periods=n).min().shift(1)


def recent_high(close: pd.Series, lookback: int = 63) -> pd.Series:
    """Highest close of the previous `lookback` sessions (excludes today)."""
    return close.rolling(lookback, min_periods=lookback // 2).max().shift(1)


def recent_low(close: pd.Series, lookback: int = 63) -> pd.Series:
    return close.rolling(lookback, min_periods=lookback // 2).min().shift(1)


def high_52w(close: pd.Series) -> pd.Series:
    return close.rolling(252, min_periods=60).max()


def low_52w(close: pd.Series) -> pd.Series:
    return close.rolling(252, min_periods=60).min()


# ------------------------------------------------------- risk / relative ---
def beta(stock_close: pd.Series, bench_close: pd.Series, n: int = 126) -> float:
    s = stock_close.pct_change().dropna().tail(n)
    b = bench_close.pct_change().dropna().tail(n)
    joined = pd.concat([s, b], axis=1, join="inner").dropna()
    if len(joined) < 30:
        return float("nan")
    var_b = float(joined.iloc[:, 1].var())
    if var_b <= 0:
        return float("nan")
    cov = float(joined.iloc[:, 0].cov(joined.iloc[:, 1]))
    return cov / var_b


def max_drawdown(close: pd.Series, n: int = 126) -> float:
    w = close.tail(n)
    if len(w) < 20:
        return float("nan")
    dd = (w / w.cummax()) - 1.0
    return float(dd.min())


def rel_return(stock_close: pd.Series, bench_close: pd.Series, n: int = 20) -> float:
    """Stock n-day return minus benchmark n-day return (relative strength)."""
    if len(stock_close) < n + 1 or len(bench_close) < n + 1:
        return float("nan")
    rs_ret = float(stock_close.iloc[-1] / stock_close.iloc[-n - 1] - 1.0)
    b_ret = float(bench_close.iloc[-1] / bench_close.iloc[-n - 1] - 1.0)
    return rs_ret - b_ret


def avg_daily_turnover_cr(df: pd.DataFrame, n: int = 20) -> float:
    """Average daily traded value in Rs crore (NSE prices are already INR)."""
    if df is None or len(df) == 0:
        return float("nan")
    to = (df["Close"] * df["Volume"]).tail(n)
    return float(to.mean() / 1e7)


def updown_volume_skew(df: pd.DataFrame, n: int = 10) -> float:
    """Average volume on up days / average volume on down days, last n days."""
    w = df.tail(n)
    up = w.loc[w["Close"] > w["Close"].shift(1).fillna(w["Close"]), "Volume"]
    dn = w.loc[w["Close"] < w["Close"].shift(1).fillna(w["Close"]), "Volume"]
    mu, md = (float(up.mean()) if len(up) else 0.0), (float(dn.mean()) if len(dn) else 0.0)
    if md <= 0:
        return 1.5 if mu > 0 else 1.0
    return mu / md


# ------------------------------------------------------------- utilities ---
def pct_above_ma(closes: dict[str, pd.Series], n: int) -> float:
    """Breadth helper: % of series trading above their n-period simple MA."""
    if not closes:
        return float("nan")
    above = 0
    total = 0
    for s in closes.values():
        if len(s) < n + 1:
            continue
        total += 1
        ma = s.rolling(n, min_periods=n).mean().iloc[-1]
        if s.iloc[-1] > ma:
            above += 1
    return 100.0 * above / total if total else float("nan")


def new_highs_lows(closes: dict[str, pd.Series], n: int = 20) -> tuple[int, int]:
    """Count of stocks at an n-session closing high / low (as of last bar)."""
    highs = lows = 0
    for s in closes.values():
        if len(s) < n + 1:
            continue
        w = s.tail(n)
        if s.iloc[-1] >= w.max() - 1e-9:
            highs += 1
        if s.iloc[-1] <= w.min() + 1e-9:
            lows += 1
    return highs, lows
