"""Free news client: Google News RSS (per symbol) + Indian market RSS feeds.

No API keys, no scraping behind paywalls - only public RSS endpoints.
"""
from __future__ import annotations

import re
import time
from datetime import datetime, timedelta, timezone
from urllib.parse import quote_plus

import feedparser

from config.settings import MARKET_RSS_FEEDS
from utils.helpers import CACHE, cached, ist_stamp

TIMEOUT = 10


def _entry_date(entry) -> datetime | None:
    for attr in ("published_parsed", "updated_parsed"):
        st = getattr(entry, attr, None)
        if st:
            try:
                import calendar
                return datetime.fromtimestamp(calendar.timegm(st), tz=timezone.utc)
            except (TypeError, ValueError, OverflowError):
                return None
    return None


def _parse_feed(url: str) -> list[dict]:
    d = feedparser.parse(url)
    out = []
    for e in d.entries[:40]:
        out.append({
            "title": re.sub(r"\s+", " ", getattr(e, "title", "")).strip(),
            "link": getattr(e, "link", ""),
            "source": getattr(getattr(e, "source", None), "title", "") or
                      (url.split("/")[2] if "/" in url else url),
            "utc": _entry_date(e),
        })
    return out


def _google_news_url(query: str, days: int) -> str:
    q = f"{query} when:{days}d"
    return (f"https://news.google.com/rss/search?q={quote_plus(q)}"
            f"&hl=en-IN&gl=IN&ceid=IN:en")


def _name_tokens(name: str) -> list[str]:
    """Words >=4 chars from the company name used to match headlines."""
    stop = {"industries", "corporation", "company", "limited", "india",
            "international", "enterprises", "laboratories", "technologies",
            "services", "solutions", "bank", "products", "motors"}
    toks = [t.lower() for t in re.split(r"[^A-Za-z]+", name or "")
            if len(t) >= 4 and t.lower() not in stop]
    return toks[:3]


def fetch_symbol_news(symbol: str, name: str, days: int = 14,
                      max_items: int = 25, log=print) -> list[dict]:
    """Headlines mentioning the company from Google News RSS (last `days`).

    Returns list of {'title','source','utc','age_days'} sorted newest first.
    """
    def _p():
        raw = safe_parse(_google_news_url(f"{symbol} OR {name} stock", days))
        sym_l, toks = symbol.lower(), _name_tokens(name)
        cutoff = datetime.now(timezone.utc) - timedelta(days=days + 1)
        out = []
        for it in raw:
            t = it["title"].lower()
            if sym_l not in t and not any(k in t for k in toks):
                continue
            utc = it["utc"]
            if utc and utc < cutoff:
                continue
            age = (datetime.now(timezone.utc) - utc).days if utc else None
            out.append({"title": it["title"], "source": it["source"],
                        "utc": utc, "age_days": age})
        return out[:max_items]
    return cached(f"snews|{symbol}|{days}",
                  lambda: _safe_wrapper(_p, log), cache=CACHE) or []


def _safe_wrapper(fn, log=print):
    try:
        return fn()
    except Exception as e:  # noqa: BLE001
        log(f"[news] fetch failed: {type(e).__name__}: {e}")
        return []


def safe_parse(url: str) -> list[dict]:
    try:
        return _parse_feed(url)
    except Exception:  # noqa: BLE001
        return []


def fetch_market_news(max_items: int = 40, log=print) -> list[dict]:
    """Aggregated market-wide headlines from ET / Moneycontrol / BS feeds."""
    def _p():
        out: list[dict] = []
        for src, url in MARKET_RSS_FEEDS:
            for it in safe_parse(url):
                out.append(it)
            time.sleep(0.15)
        return out[:max_items]
    return cached(f"mnews|{max_items}", lambda: _safe_wrapper(_p, log), cache=CACHE) or []
