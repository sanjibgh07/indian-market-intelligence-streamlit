"""Mother Agent - orchestrator of record and FINAL decision authority.

Responsibilities (per system spec):
  1. Collect all specialist reports for each candidate.
  2. Cross-verify: technical strength must be corroborated by news tone,
     sector tailwind and acceptable risk; conflicting signals downgrade or
     reject the idea.
  3. Apply hard risk filters (liquidity floor, risk-score floor, news red
     flags, crisis-regime gate).
  4. Rank by composite conviction and publish AT MOST 2 stocks.
  5. If nothing clears the bar -> "No high-conviction idea this week".
  6. Build the exact final output format: recommendation lines, 4-week Nifty
     outlook, confidence & disclaimer.

Composite conviction (0-100):
    0.35*technical + 0.20*fundamental + 0.15*news + 0.15*sector_tailwind
  + 0.15*risk  + regime adjustment (max +6 / -10) + sector adjustment (+/-4)
Fundamental data unavailable -> neutral 50 substitute, -3 conviction penalty
and conviction capped at MEDIUM (disclosed).

Expected return model (transparent, no fabricated targets):
  - conservative target = nearest resistance (3m high / Donchian / 52w-high
    approach) within reach, else spot + 1.0 x ATR21
  - optimistic target  = second resistance, capped at spot + 3.0 x ATR21
  - horizon = diffusion heuristic days = clamp(round(9 * m^1.4), 8, 28)
    where m = (optimistic target - spot) / ATR21; hard cap 28 days.
"""
from __future__ import annotations

import numpy as np

from agents.base import BaseAgent
from analysis import indicators as ta
from config.settings import COMPOSITE_WEIGHTS
from core.models import (Candidate, MarketContext, Q_DEGRADED, Q_OK,
                         Q_UNAVAILABLE, STRONG_BULLISH, TradePlan,
                         verdict_from_score)
from utils.helpers import clamp, ist_stamp, r2


class MotherAgent(BaseAgent):
    name = "Mother Agent"
    description = "Cross-verification, risk filters and final decision authority"

    # ------------------------------------------------------------------
    def decide(self, candidates: list[Candidate], market: MarketContext, cfg) -> tuple[list[Candidate], list[Candidate], str, float]:
        """Returns (picks, rejected, final_text, overall_confidence)."""
        regime = market.regime
        regime_score = regime.score_or(50.0) if regime else 50.0
        regime_name = (regime.details.get("regime", "UNKNOWN") if regime else "UNKNOWN")
        crisis = regime_name in ("CORRECTION", "CRISIS-RISK")

        weights = cfg.weights()
        scored: list[Candidate] = []

        for cand in candidates:
            tech = cand.tech
            fund = cand.fund
            news = cand.news
            risk = cand.risk

            liq_pass = (risk.details.get("liq_pass", True) if risk else True)
            red_flags = (news.details.get("red_flags", []) if news else [])
            risk_score = risk.score_or(50.0) if risk else 50.0
            tech_score = tech.score_or(0.0) if tech else 0.0

            # ---------- composite conviction (computed for every candidate) -----
            fund_score = fund.score_or(50.0) if fund else 50.0
            fund_missing = (fund is None) or (fund.data_quality == Q_UNAVAILABLE)
            news_score = news.score_or(50.0) if news else 50.0

            comp = (weights["technical"] * tech_score +
                    weights["fundamental"] * (50.0 if fund_missing else fund_score) +
                    weights["news"] * news_score +
                    weights["sector_macro"] * cand.sector_tailwind +
                    weights["risk"] * risk_score)

            # regime adjustment: strong tape adds a little, weak tape subtracts a lot
            comp += clamp((regime_score - 50) / 50 * 8, -10, 6)
            # sector tailwind fine-tune
            comp += clamp((cand.sector_tailwind - 50) / 50 * 4, -4, 4)
            # cross-verification: news must not contradict the technicals
            if tech_score >= 65 and news_score < 35:
                comp -= 8
            if fund_missing:
                comp -= 3
            # cross-verification: risk agent should not be fighting the trade
            if risk_score < 55:
                comp -= 4

            cand.composite = float(comp)

            # ---------- hard gates (veto rules), applied after scoring ----------
            if not liq_pass:
                cand.rejected, cand.reject_reason = True, "Liquidity floor failed (avg turnover too low)"
                scored.append(cand)
                continue
            if red_flags:
                cand.rejected = True
                cand.reject_reason = f"News red flag: {', '.join(red_flags[:3])}"
                scored.append(cand)
                continue
            if risk_score < cfg.min_risk_score:
                cand.rejected = True
                cand.reject_reason = f"Risk score {risk_score:.0f} below floor {cfg.min_risk_score:.0f}"
                scored.append(cand)
                continue
            if tech_score < cfg.min_tech_score:
                cand.rejected = True
                cand.reject_reason = f"Technical score {tech_score:.0f} below floor {cfg.min_tech_score:.0f}"
                scored.append(cand)
                continue

            # crisis gate: demand exceptionality in weak tape
            if crisis and (comp < cfg.min_conviction + 6 or tech_score < 70):
                cand.rejected = True
                cand.reject_reason = (f"Crisis regime ({regime_name}): needs composite "
                                      f">= {cfg.min_conviction + 6:.0f} and tech >= 70 "
                                      f"(got {comp:.0f}/{tech_score:.0f})")
                scored.append(cand)
                continue

            if comp < cfg.min_conviction:
                cand.rejected = True
                cand.reject_reason = (f"Composite conviction {comp:.0f} below "
                                      f"threshold {cfg.min_conviction:.0f}")
                scored.append(cand)
                continue

            # reward-to-risk gate: build the plan early and reject poor geometry
            plan = self._build_trade_plan(cand, market, cfg)
            if plan.rr_ratio < 1.0:
                cand.rejected = True
                cand.reject_reason = (f"Poor reward-to-risk ({plan.rr_ratio:.1f}): "
                                      "nearest resistance too close to entry for the stop distance")
                scored.append(cand)
                continue

            scored.append(cand)

        eligible = [c for c in scored if not c.rejected]
        eligible.sort(key=lambda c: c.composite, reverse=True)

        # ---------- sector diversification -----------------------------------
        picks: list[Candidate] = []
        sectors_seen: set[str] = set()
        for cand in eligible:
            if len(picks) >= cfg.max_picks:
                break
            if cand.sector in sectors_seen and cand.sector != "CUSTOM":
                # allow same-sector only if clearly stronger than everything else
                if picks and cand.composite < picks[0].composite + 8:
                    cand.rejected = True
                    cand.reject_reason = f"Sector concentration ({cand.sector} already picked)"
                    continue
            picks.append(cand)
            sectors_seen.add(cand.sector)

        for cand in eligible:
            if cand not in picks and not cand.rejected:
                cand.rejected = True
                cand.reject_reason = (f"Rank {eligible.index(cand) + 1}: outside top "
                                      f"{cfg.max_picks} (max picks cap)")

        # ---------- trade plans & conviction labels ----------------------------
        for cand in picks:
            # plan already built during gating; rebuild in case anything changed
            cand.plan = self._build_trade_plan(cand, market, cfg)
            cand.conviction = self._conviction_label(cand, market)

        rejected = [c for c in scored if c.rejected]
        overall_conf = self._overall_confidence(picks, market)
        final_text = self._final_text(picks, market, cfg, overall_conf, rejected)
        return picks, rejected, final_text, overall_conf

    # ------------------------------------------------------------------
    def _build_trade_plan(self, cand: Candidate, market: MarketContext, cfg) -> TradePlan:
        df_ref = cand.tech.details
        spot = cand.spot
        atr21 = float(df_ref.get("atr21") or 0) or (spot * 0.02)
        h63 = df_ref.get("high_3m")
        h52 = df_ref.get("high_52w")
        d20 = df_ref.get("donchian20_high")
        stop = float(cand.risk.details.get("stop") or (spot * 0.96))

        # Price discovery: at/near the 52-week high there is no overhead supply,
        # so targets are pure ATR projections instead of the barely-above high.
        near_52w_high = bool(h52 and h52 == h52 and spot >= h52 * 0.98)
        if near_52w_high:
            resistances = []
        else:
            # only *meaningful* overhead levels: at least 1.5% above spot
            resistances = sorted({x for x in (h63, d20, h52)
                                  if x and x == x and x >= spot * 1.015})
        reach = spot + 3.0 * atr21
        in_reach = [x for x in resistances if x <= reach]

        # conservative target: nearest meaningful resistance in reach, else +1.2 ATR
        if in_reach and in_reach[0] <= spot + 2.0 * atr21:
            t_low = in_reach[0]
        else:
            t_low = spot + 1.2 * atr21
        # optimistic: second resistance / 52w high / +2.4 ATR, capped at +3 ATR
        if len(in_reach) >= 2:
            t_high = in_reach[1]
        elif near_52w_high:
            t_high = spot + 2.4 * atr21
        elif h52 and h52 == h52 and spot < h52 <= reach:
            t_high = h52
        else:
            t_high = spot + 2.2 * atr21
        t_high = min(t_high, spot + 3.0 * atr21)
        # the optimistic target must offer >= 1.6x the stop distance to be worth
        # a 4-week commitment, bounded by a +10% sanity cap for this horizon
        risk_dist = max(spot - stop, 0.01 * spot)
        t_high = max(t_high, spot + 1.6 * risk_dist)
        t_high = min(t_high, spot * 1.10)
        if t_high <= t_low:
            t_high = min(spot * 1.10, t_low + 0.6 * atr21)

        ret_low = (t_low / spot - 1) * 100
        ret_high = (t_high / spot - 1) * 100
        # keep a minimum reward-to-risk of ~1.2 on the conservative target
        min_rr_target = spot + 1.2 * (spot - stop)
        t_low = min(t_high, max(t_low, min_rr_target, spot * 1.005))
        ret_low = (t_low / spot - 1) * 100
        m = (t_high - spot) / atr21
        horizon = int(clamp(round(9.0 * (m ** 1.4)), 8, cfg.max_hold_days))

        shares = int(cand.risk.details.get("shares") or 0)
        pos_value = float(cand.risk.details.get("position_value") or 0)
        pos_pct = float(cand.risk.details.get("position_pct") or 0)
        risk_amount = float(cand.risk.details.get("risk_amount") or 0)
        rr = (t_low - spot) / (spot - stop) if spot > stop else 0.0

        s1 = market.nifty.get('support_1')
        s1_txt = f"{s1:,.0f}" if isinstance(s1, (int, float)) else str(s1)
        invalidation = (f"Daily close below {stop:,.1f} "
                        f"(-{(spot - stop) / spot * 100:.1f}%; breaks the 4-week structure). "
                        f"Setup also void if Nifty loses {s1_txt}.")

        plan = TradePlan(
            entry=r2(spot), stop=r2(stop), stop_pct=r2((spot - stop) / spot * 100),
            target_low=r2(t_low), target_high=r2(t_high),
            ret_low_pct=r2(ret_low), ret_high_pct=r2(ret_high),
            horizon_days=horizon, shares=shares, position_value=r2(pos_value),
            position_pct=r2(pos_pct), risk_amount=r2(risk_amount), rr_ratio=r2(rr),
            invalidation=invalidation,
            time_stop=(f"Time stop: if neither target is hit by day {horizon} and the "
                       f"position is below +1%, exit and reassess."),
        )
        return plan

    # ------------------------------------------------------------------
    def _conviction_label(self, cand: Candidate, market: MarketContext) -> str:
        parts = [cand.tech, cand.fund, cand.news, cand.risk]
        confs = [p.confidence for p in parts if p is not None and p.data_quality != Q_UNAVAILABLE]
        base = float(np.mean(confs)) if confs else 40.0
        base += clamp((cand.composite - 70) / 2, -8, 10)
        fund_missing = cand.fund is None or cand.fund.data_quality == Q_UNAVAILABLE
        if fund_missing:
            base = min(base, 62.0)   # cap at MEDIUM
        base = clamp(base, 0, 95)
        return "HIGH" if base >= 72 else ("MEDIUM" if base >= 55 else "LOW")

    # ------------------------------------------------------------------
    def _overall_confidence(self, picks: list[Candidate], market: MarketContext) -> float:
        if not picks:
            # no-trade confidence: how clear is the market picture?
            reg = market.regime.confidence if market.regime else 50
            return round(clamp(0.5 * (reg or 50) + 20, 30, 80), 0)
        vals = [self._conviction_value(c) for c in picks]
        return round(clamp(float(np.mean(vals)), 0, 95), 0)

    def _conviction_value(self, cand: Candidate) -> float:
        parts = [cand.tech, cand.fund, cand.news, cand.risk]
        confs = [p.confidence for p in parts if p is not None and p.data_quality != Q_UNAVAILABLE]
        base = float(np.mean(confs)) if confs else 40.0
        base += clamp((cand.composite - 70) / 2, -8, 10)
        if cand.fund is None or cand.fund.data_quality == Q_UNAVAILABLE:
            base = min(base, 62.0)
        return clamp(base, 0, 95)

    # ------------------------------------------------------------------
    def _final_text(self, picks, market, cfg, overall_conf, rejected) -> str:
        mode_note = "  [DEMO MODE - SYNTHETIC DATA]" if cfg.demo else ""
        lines: list[str] = []
        lines.append("**Final Recommendation**")
        lines.append("")

        if not picks:
            regime_name = (market.regime.details.get("regime", "UNKNOWN")
                           if market.regime else "UNKNOWN")
            reasons = [f"- {c.symbol}: {c.reject_reason}" for c in rejected[:4]]
            lines.append("**No high-conviction idea this week.** Standing aside is a valid, "
                         "risk-first decision. Current regime: "
                         f"{regime_name}; no candidate cleared the {cfg.min_conviction:.0f}-point "
                         "conviction bar after cross-verification.")
            if reasons:
                lines.append("")
                lines.append("Closest candidates and why they were cut:")
                lines.extend(reasons)
        else:
            for i, c in enumerate(picks, 1):
                p = c.plan
                thesis = self._thesis(c)
                risks_txt = "; ".join(self._top_risks(c, 3))
                lines.append(
                    f"**Stock {i}: {c.name} ({c.symbol})** | "
                    f"Expected Return: **+{p.ret_low_pct:.1f}% to +{p.ret_high_pct:.1f}% "
                    f"in ~{p.horizon_days} days (<= {cfg.max_hold_days} days)** | "
                    f"Conviction: {c.conviction} ({c.composite:.0f}/100) | "
                    f"Thesis: {thesis} | Key Risks: {risks_txt} | "
                    f"Invalidation: {p.invalidation}"
                )
                lines.append("")
                lines.append(f"  - Trade plan: entry up to {p.entry:,.1f}; stop {p.stop:,.1f} "
                             f"(-{p.stop_pct:.1f}%); targets {p.target_low:,.1f} / {p.target_high:,.1f}; "
                             f"R:R ~{p.rr_ratio:.1f} | size {p.shares:,} shares "
                             f"(~{p.position_pct:.1f}% of Rs {cfg.capital:,.0f} capital, "
                             f"max risk Rs {p.risk_amount:,.0f})")
                lines.append(f"  - {p.time_stop}")
                lines.append("")

        lines.append("**4-Week Nifty Outlook**")
        lines.append("")
        lines.append(market.outlook_text or "Outlook unavailable.")
        if market.regime:
            lv = market.nifty  # orchestrator stores the levels dict directly here
            sc = market.nifty.get("scenarios", {})
            lines.append("")
            lines.append(f"Key levels - resistance: {lv.get('resistance_1', float('nan')):,.0f} | "
                         f"support-1: {lv.get('support_1', float('nan')):,.0f} | "
                         f"support-2: {lv.get('support_2', float('nan')):,.0f} | "
                         f"50-DMA: {lv.get('ema50', float('nan')):,.0f} | "
                         f"200-DMA: {lv.get('ema200', float('nan')):,.0f}")
            if sc:
                lines.append("")
                lines.append(f"Scenario odds: Bull {sc.get('bull', {}).get('prob', '-')}% "
                             f"(target {sc.get('bull', {}).get('target', 0):,.0f}) | "
                             f"Base {sc.get('base', {}).get('prob', '-')}% "
                             f"({sc.get('base', {}).get('range_low', 0):,.0f}-"
                             f"{sc.get('base', {}).get('range_high', 0):,.0f}) | "
                             f"Bear {sc.get('bear', {}).get('prob', '-')}% "
                             f"(target {sc.get('bear', {}).get('target', 0):,.0f})")
        lines.append("")
        lines.append("**Confidence & Disclaimer**")
        lines.append("")
        if picks:
            lines.append(f"Overall confidence: **{self._conf_word(overall_conf)}** "
                         f"({overall_conf:.0f}/100). Confidence reflects data quality and "
                         "signal agreement across agents; it is not a probability of profit.")
        else:
            lines.append(f"Overall confidence in standing aside: **{self._conf_word(overall_conf)}** "
                         f"({overall_conf:.0f}/100).")
        lines.append("")
        lines.append(f"Generated {ist_stamp()} by the Indian Equity Multi-Agent Research System"
                     f"{mode_note}. Expected returns are model-derived probabilistic estimates "
                     "from volatility and structure, NOT guarantees. Markets can invalidate any "
                     "setup overnight. This is educational research output, not investment "
                     "advice; the system is not a SEBI-registered research analyst or adviser. "
                     "Consult a registered adviser and read scheme documents before trading.")

        return "\n".join(lines)

    # ------------------------------------------------------------------
    def _thesis(self, c: Candidate) -> str:
        d = c.tech.details if c.tech else {}
        bits = []
        setup = d.get("setup_type", "")
        if setup:
            bits.append(f"{setup.replace('-', ' ').title()} setup")
        rs20 = d.get("rs_20d_pct")
        if rs20 is not None:
            bits.append(f"RS vs Nifty {rs20:+.1f}% (20d)")
        if c.sector_tailwind >= 60:
            bits.append(f"{c.sector} sector tailwind")
        if c.fund and c.fund.score is not None and c.fund.data_quality != Q_UNAVAILABLE:
            roe = (c.fund.details or {}).get("roe_pct")
            de = (c.fund.details or {}).get("de_ratio")
            fq = []
            if roe is not None:
                fq.append(f"ROE {roe:.0f}%")
            if de is not None:
                fq.append(f"D/E {de:.1f}")
            if fq:
                bits.append("fundamentals adequate (" + ", ".join(fq) + ")")
        if c.news and c.news.score is not None and c.news.score >= 58:
            bits.append("news tone supportive")
        if c.risk:
            bits.append(f"risk agent: {c.risk.verdict}")
        return "; ".join(bits) or "Composite conviction cleared threshold"

    def _top_risks(self, c: Candidate, k: int = 3) -> list[str]:
        out: list[str] = []
        for rep in (c.tech, c.news, c.risk, c.fund):
            if rep is None:
                continue
            for r in rep.risks[:2]:
                out.append(r)
        seen, dedup = set(), []
        for r in out:
            key = r[:60]
            if key not in seen:
                seen.add(key)
                dedup.append(r)
        return dedup[:k]

    def _conf_word(self, v: float) -> str:
        return "HIGH" if v >= 72 else ("MEDIUM" if v >= 55 else "LOW")
