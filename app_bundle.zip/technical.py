"""Technical Agent - price action, volume, indicators and 1-4 week structure.

Scoring (0-100):
  trend       30 pts : EMA stack, 200-DMA, ADX/DI
  momentum    25 pts : MACD histogram, RSI band, 20-day return
  structure   25 pts : proximity to 3-month high, breakout state, base quality
  volume/RS   20 pts : volume trend, relative strength vs Nifty (20d & 63d),
                       up/down volume skew
Penalties for over-extension, overbought RSI, volume dry-up.

Also classifies the setup type (breakout / pullback / trend continuation /
range / weak) which the Mother Agent uses to set the return horizon.
"""
from __future__ import annotations

import numpy as np

from agents.base import BaseAgent
from analysis import indicators as ta
from core.models import (Q_DEGRADED, Q_OK, STRONG_BULLISH, BULLISH, NEUTRAL,
                         BEARISH, STRONG_BEARISH, verdict_from_score)
from utils.helpers import clamp, r2

PENALTY_EXTENDED = 8
PENALTY_OVERBOUGHT = 8


class TechnicalAgent(BaseAgent):
    name = "Technical Agent"
    description = ("Short-term (1-4 week) price action, volume and chart structure")

    def analyze(self, symbol: str, name: str, df, bench_close) -> "AgentReport":  # noqa: F821
        try:
            return self._analyze(symbol, name, df, bench_close)
        except Exception as e:  # noqa: BLE001
            return self.fallback(symbol, why=str(e))

    # ------------------------------------------------------------------
    def _analyze(self, symbol, name, df, bench_close):
        c = df["Close"]
        spot = float(c.iloc[-1])
        ema20, ema50, ema200 = ta.ema(c, 20), ta.ema(c, 50), ta.ema(c, 200)
        rsi14 = ta.rsi(c, 14)
        _, _, hist = ta.macd(c)
        atr14 = ta.atr(df, 14)
        atr21 = ta.atr(df, 21)
        adx14, pdi, mdi = ta.adx(df, 14)
        v20, v60 = df["Volume"].rolling(20).mean(), df["Volume"].rolling(60).mean()
        d20 = ta.donchian_high(df, 20)
        h63 = ta.recent_high(c, 63)
        h52 = ta.high_52w(c)
        ret20 = float(c.iloc[-1] / c.iloc[-21] - 1) * 100 if len(c) > 21 else float("nan")
        rs20 = ta.rel_return(c, bench_close, 20) * 100 if bench_close is not None and len(bench_close) > 21 else float("nan")
        rs63 = ta.rel_return(c, bench_close, 63) * 100 if bench_close is not None and len(bench_close) > 64 else float("nan")
        skew = ta.updown_volume_skew(df, 10)

        last = lambda s: float(s.iloc[-1]) if s is not None and len(s) and not np.isnan(s.iloc[-1]) else float("nan")  # noqa: E731

        e20, e50, e200 = last(ema20), last(ema50), last(ema200)
        r14, adx_v, pdi_v, mdi_v = last(rsi14), last(adx14), last(pdi), last(mdi)
        hist_v, hist_prev = float(hist.iloc[-1]), float(hist.iloc[-2]) if len(hist) > 1 else float("nan")
        a14, a21 = last(atr14), last(atr21)
        d20v, h63v, h52v = last(d20), last(h63), last(h52)
        v20v, v60v = last(v20), last(v60)

        # ---------------- trend (30) -----------------------------------
        trend = 0.0
        if spot > e200: trend += 8
        if e50 > e200: trend += 6
        if spot > e50: trend += 6
        if e20 > e50: trend += 5
        if adx_v >= 20 and pdi_v > mdi_v: trend += 5

        # ---------------- momentum (25) ---------------------------------
        mom = 0.0
        if hist_v > 0 and hist_v > hist_prev: mom += 8
        elif hist_v > 0: mom += 4
        if 55 <= r14 <= 70: mom += 8
        elif 45 <= r14 < 55: mom += 4
        elif 70 < r14 <= 75: mom += 4
        if ret20 > 0: mom += 5
        if ret20 > 8: mom += 4

        # ---------------- structure (25) --------------------------------
        struct = 0.0
        near_high = (spot / h63v - 1) if h63v and h63v == h63v else float("nan")
        if near_high >= -0.02: struct += 10          # at/within 2% of 3m high
        elif near_high >= -0.05: struct += 7
        breakout = spot > d20v if d20v == d20v else False
        if breakout: struct += 8                      # cleared 20-day channel
        dist_ema20 = (spot / e20 - 1) / (a14 / spot) if a14 and a14 > 0 else float("nan")
        if 0 <= dist_ema20 <= 1.2: struct += 7        # healthy base above EMA20
        elif dist_ema20 > 1.2: struct += 3            # extended but trending

        # ---------------- volume / relative strength (20) ----------------
        volrs = 0.0
        if v20v > v60v: volrs += 6
        if rs20 > 0: volrs += 6
        if rs63 > 0: volrs += 4
        if skew >= 1.0: volrs += 4

        score = trend + mom + struct + volrs
        # ---------------- penalties --------------------------------------
        reasons_pen = []
        if r14 > 78:
            score -= PENALTY_OVERBOUGHT
            reasons_pen.append(f"RSI {r14:.0f} - overbought, poor fresh-entry odds")
        if dist_ema20 > 2.2:
            score -= PENALTY_EXTENDED
            reasons_pen.append(f"Price {dist_ema20:.1f} ATR above EMA20 - extended, chase risk")
        if spot < e50:
            score -= 6
        if v20v < 0.7 * v60v:
            score -= 5
            reasons_pen.append("20-day volume 30%+ below 60-day average - drying interest")
        score = clamp(score, 0, 100)

        # ---------------- setup type --------------------------------------
        in_uptrend = spot > e50 and e50 > e200
        if breakout and in_uptrend:
            setup = "BREAKOUT"
        elif in_uptrend and dist_ema20 <= 0.8:
            setup = "PULLBACK-IN-TREND"
        elif spot > e20 > e50 and 55 <= r14 <= 70:
            setup = "TREND-CONTINUATION"
        elif spot > e200:
            setup = "RANGE"
        else:
            setup = "WEAK"

        verdict = verdict_from_score(score)
        if verdict == STRONG_BULLISH:
            v = STRONG_BULLISH
        elif verdict == BULLISH:
            v = BULLISH
        elif verdict in (BEARISH, STRONG_BEARISH):
            v = verdict
        else:
            v = NEUTRAL

        q = Q_OK if len(df) >= 200 else Q_DEGRADED
        conf = clamp(65 + (10 if adx_v >= 25 else 0) + (8 if len(df) >= 240 else 0)
                     - (15 if len(df) < 200 else 0), 20, 90)

        kps = [
            f"Close {spot:,.1f} | EMA20/50/200: {e20:,.1f} / {e50:,.1f} / {e200:,.1f}",
            f"RSI(14) {r14:.1f} | ADX(14) {adx_v:.1f} (+DI {pdi_v:.0f} vs -DI {mdi_v:.0f})",
            f"MACD hist {hist_v:+.2f} ({'rising' if hist_v > hist_prev else 'fading'}) | 20d return {ret20:+.1f}%",
            f"RS vs Nifty: 20d {rs20:+.1f}% | 63d {rs63:+.1f}%",
            f"{breakout and 'Cleared' or 'Below'} 20-day Donchian high ({d20v:,.1f}) | {near_high * 100:+.1f}% vs 3-month high",
            f"Setup: {setup} | ATR(14) {a14:,.1f} ({a14 / spot * 100:.1f}% of price)",
        ]
        risks = reasons_pen + [
            f"Break of EMA50 ({e50:,.1f}) would invalidate the trend structure",
            "Sector/market-wide shock overrides stock setup",
        ]
        details = {
            "spot": r2(spot), "ema20": r2(e20), "ema50": r2(e50), "ema200": r2(e200),
            "rsi14": r2(r14), "adx14": r2(adx_v), "macd_hist": r2(hist_v),
            "atr14": r2(a14), "atr21": r2(a21), "atr_pct": r2(a14 / spot * 100),
            "donchian20_high": r2(d20v), "high_3m": r2(h63v), "high_52w": r2(h52v),
            "ret_20d_pct": r2(ret20), "rs_20d_pct": r2(rs20), "rs_63d_pct": r2(rs63),
            "vol20_vs_vol60": r2(v20v / v60v) if v60v else None,
            "updown_vol_skew": r2(skew),
            "subscores": {"trend(30)": r2(trend), "momentum(25)": r2(mom),
                          "structure(25)": r2(struct), "volume_rs(20)": r2(volrs),
                          "penalties": reasons_pen},
            "setup_type": setup,
            "rows": int(len(df)),
        }
        return self.report(verdict=v, score=score, confidence=conf, data_quality=q,
                           key_points=kps, risks=risks, details=details, symbol=symbol)
