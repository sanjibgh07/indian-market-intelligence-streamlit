# Indian Equity Multi-Agent Research Report  (DEMO - SYNTHETIC DATA)

Generated: 09-Nov-2026 16:28 IST | Mode: **DEMO** | Universe scanned: 105 | Usable: 105 | Deep-dive shortlist: 12

---

## Mother Agent - Final Verdict

**Final Recommendation**

**Stock 1: Pidilite Industries (PIDILITIND)** | Expected Return: **+6.3% to +8.4% in ~28 days (<= 28 days)** | Conviction: HIGH (83/100) | Thesis: Trend Continuation setup; RS vs Nifty +7.3% (20d); CONSUMER sector tailwind; fundamentals adequate (ROE 22%, D/E 0.8); news tone supportive; risk agent: LOW RISK | Key Risks: Break of EMA50 (2,242.6) would invalidate the trend structure; Sector/market-wide shock overrides stock setup; Keyword sentiment is coarse; earnings-day tone can flip fast | Invalidation: Daily close below 2,254.4 (-5.2%; breaks the 4-week structure). Setup also void if Nifty loses 27,662.

  - Trade plan: entry up to 2,379.0; stop 2,254.4 (-5.2%); targets 2,528.6 / 2,578.4; R:R ~1.2 | size 10 shares (~23.8% of Rs 100,000 capital, max risk Rs 1,500)
  - Time stop: if neither target is hit by day 28 and the position is below +1%, exit and reassess.

**Stock 2: Bharat Petroleum Corporation (BPCL)** | Expected Return: **+7.5% to +10.0% in ~28 days (<= 28 days)** | Conviction: HIGH (83/100) | Thesis: Pullback In Trend setup; RS vs Nifty +9.4% (20d); OIL & GAS sector tailwind; fundamentals adequate (ROE 31%, D/E 0.7); news tone supportive; risk agent: LOW RISK | Key Risks: Break of EMA50 (7,898.8) would invalidate the trend structure; Sector/market-wide shock overrides stock setup; Keyword sentiment is coarse; earnings-day tone can flip fast | Invalidation: Daily close below 7,961.6 (-6.2%; breaks the 4-week structure). Setup also void if Nifty loses 27,662.

  - Trade plan: entry up to 8,490.5; stop 7,961.6 (-6.2%); targets 9,125.1 / 9,336.7; R:R ~1.2 | size 2 shares (~17.0% of Rs 100,000 capital, max risk Rs 1,500)
  - Time stop: if neither target is hit by day 28 and the position is below +1%, exit and reassess.

**4-Week Nifty Outlook**

Regime: BULL. Nifty is in an established uptrend; momentum is positive but not euphoric. Breadth: 52% of the tracked universe above its 50-DMA and 51% above the 200-DMA. 4-week expected move (1 sigma, from ATR): about +/-8.6% around 28,909. Over the next four weeks the base case (45%) is a 28,161-29,906 grind; a push toward 31,401 (42% odds, stretch 32,897) needs the index to hold above 27,662; a break below 27,662 opens 26,416 (13% odds, stretch 24,921), with deeper support near 25,900 (200-DMA zone 27,002).

Key levels - resistance: 30,155 | support-1: 27,662 | support-2: 25,900 | 50-DMA: 28,339 | 200-DMA: 27,002

Scenario odds: Bull 42% (target 31,401) | Base 45% (28,161-29,906) | Bear 13% (target 26,416)

**Confidence & Disclaimer**

Overall confidence: **HIGH** (75/100). Confidence reflects data quality and signal agreement across agents; it is not a probability of profit.

Generated 09-Nov-2026 16:28 IST by the Indian Equity Multi-Agent Research System  [DEMO MODE - SYNTHETIC DATA]. Expected returns are model-derived probabilistic estimates from volatility and structure, NOT guarantees. Markets can invalidate any setup overnight. This is educational research output, not investment advice; the system is not a SEBI-registered research analyst or adviser. Consult a registered adviser and read scheme documents before trading.

---

## Market Context (Nifty + Macro)

**Regime: BULL** | Regime score 74/100 | Confidence 70%

| Nifty level | Value |
|---|---|
| Spot | 28,909 |
| 20-DMA (EMA) | 28,794 |
| 50-DMA (EMA) | 28,339 |
| 200-DMA (EMA) | 27,002 |
| Resistance (3m high zone) | 30,155 |
| Support 1 | 27,662 |
| Support 2 | 25,900 |
| ATR(21) | 544 |
| 4-week expected move (1 sigma) | 2,493 |

| 4-week scenario | Probability | Level(s) |
|---|---|---|
| Bull | 42% | target 31,401 (stretch 32,897) |
| Base | 45% | 28,161 - 29,906 |
| Bear | 13% | target 26,416 (stretch 24,921) |

**Macro risk-appetite score: 92/100 (RISK-ON)** | Confidence 80%

Sector tailwind (20-day momentum based): AUTO 72, HEALTHCARE 72, CONSUMER 72, OIL & GAS 72, POWER 72, CAPITAL GOODS 72, BANKS 62, FMCG 62, METALS 62, CEMENT 62, INFRA 62, LOGISTICS 62, MEDIA 62, IT 50, INSURANCE 50, PHARMA 50, RETAIL 50, ENERGY 50, DEFENCE 50, REALTY 50, NBFC/FINANCIALS 40, DIVERSIFIED 40

Breadth: 52% above 50-DMA | 51% above 200-DMA | 15 new 20d highs vs 16 lows

## Candidate Scoreboard

| Symbol | Name | Sector | Spot | Tech | Fund | News | Risk | Sector TW | Composite | Status |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|---|
| PIDILITIND | Pidilite Industries | CONSUMER | 2,379.0 | 82.0 | 72.4 | 74.4 | 83.0 | 72 | **83** | PICK |
| BPCL | Bharat Petroleum Corporation | OIL & GAS | 8,490.5 | 77.0 | 73.8 | 81.3 | 82.0 | 72 | **83** | PICK |
| HYUNDAI | Hyundai Motor India | AUTO | 1,276.1 | 75.0 | 66.2 | 91.7 | 86.0 | 72 | **83** | Rejected: Rank 3: outside top 2 (max picks cap) |
| SHREECEM | Shree Cement | CEMENT | 746.3 | 73.0 | 75.4 | 94.9 | 80.0 | 62 | **81** | Rejected: Rank 4: outside top 2 (max picks cap) |
| AXISBANK | Axis Bank | BANKS | 3,120.8 | 80.0 | 60.1 | 85.9 | 90.0 | 62 | **81** | Rejected: Rank 5: outside top 2 (max picks cap) |
| APOLLOHOSP | Apollo Hospitals Enterprise | HEALTHCARE | 1,923.6 | 72.0 | 56.8 | 97.7 | 79.0 | 72 | **80** | Rejected: Rank 6: outside top 2 (max picks cap) |
| ULTRACEMCO | UltraTech Cement | CEMENT | 769.6 | 73.0 | 63.2 | 90.7 | 90.0 | 62 | **79** | Rejected: Rank 7: outside top 2 (max picks cap) |
| TATACONSUM | Tata Consumer Products | FMCG | 1,570.4 | 76.0 | 52.8 | 89.2 | 86.0 | 62 | **78** | Rejected: Rank 8: outside top 2 (max picks cap) |
| WIPRO | Wipro | IT | 4,233.5 | 78.0 | 62.4 | 93.3 | 80.0 | 50 | **77** | Rejected: Rank 9: outside top 2 (max picks cap) |
| HCLTECH | HCL Technologies | IT | 2,862.8 | 72.0 | 64.8 | 91.2 | 86.0 | 50 | **76** | Rejected: Rank 10: outside top 2 (max picks cap) |
| CHOLAFIN | Cholamandalam Investment & Finance | NBFC/FINANCIALS | 1,871.9 | 76.0 | 69.8 | 86.5 | 87.0 | 40 | **76** | Rejected: Rank 11: outside top 2 (max picks cap) |
| SUNPHARMA | Sun Pharmaceutical Industries | PHARMA | 3,135.8 | 76.0 | 62.5 | 74.4 | 79.0 | 50 | **73** | Rejected: Rank 12: outside top 2 (max picks cap) |

## Pick 1: Pidilite Industries (PIDILITIND)

- **Sector:** CONSUMER | **Spot:** 2,379.0 | **Conviction:** HIGH (83/100)
- **Expected Return:** +6.3% to +8.4% in ~28 days (cap 28 days)
- **Entry:** up to 2,379.0 | **Stop:** 2,254.4 (-5.2%) | **Targets:** 2,528.6 / 2,578.4 | **R:R:** ~1.2
- **Position size:** 10 shares (~23.8% of Rs 100,000; max loss at stop Rs 1,500)
- **Invalidation:** Daily close below 2,254.4 (-5.2%; breaks the 4-week structure). Setup also void if Nifty loses 27,662.
- Time stop: if neither target is hit by day 28 and the position is below +1%, exit and reassess.

### Technical Agent - STRONG BULLISH (score 82.0, confidence 73%, data OK)

- Close 2,379.0 | EMA20/50/200: 2,265.7 / 2,242.6 / 2,264.3
- RSI(14) 64.0 | ADX(14) 18.0 (+DI 42 vs -DI 21)
- MACD hist +17.42 (rising) | 20d return +9.9%
- RS vs Nifty: 20d +7.3% | 63d +8.0%
- Cleared 20-day Donchian high (2,377.7) | -4.2% vs 3-month high
- Setup: TREND-CONTINUATION | ATR(14) 56.7 (2.4% of price)

- *Risk:* Break of EMA50 (2,242.6) would invalidate the trend structure
- *Risk:* Sector/market-wide shock overrides stock setup

### Fundamental & Quality Agent - STRONG BULLISH (score 72.4, confidence 85%, data OK)

- TTM revenue growth 7.1% | net income growth 20.7% | margin 11.0%
- ROE 22.5% | D/E 0.8 | FCF(TTM) positive
- PE 47.3 | PB 4.9 (absolute bands)
- Insider/promoter holding proxy: 60.5%

- *Risk:* Quarterly-statement data can lag; verify latest results before acting

### News & Sentiment Agent - STRONG BULLISH (score 74.4, confidence 41%, data DEGRADED)

- 3 headlines in last 14 days | weighted tone 74/100 (pos 2 vs neg 0 keyword hits)
- [o] PIDILITIND: management guides for healthy demand outlook
- [+] Pidilite Industries announces capacity expansion plan
- [o] PIDILITIND slips 2% as sector peers decline

- *Risk:* Keyword sentiment is coarse; earnings-day tone can flip fast
- *Risk:* Headlines are free-RSS only - no paid newsroom coverage

### Risk Agent - LOW RISK (score 83.0, confidence 70%, data OK)

- Liquidity: 20d avg turnover Rs 976 cr (PASS vs Rs 75 cr floor)
- Volatility: 20d annualised 32% (1y percentile 65) | ATR 2.4% of price
- Beta vs Nifty -0.14 | 6-month max drawdown -23.5%
- Suggested stop: 2,254.4 (-5.2%) = max(63d swing low - 0.5 ATR, spot - 2.2 ATR), bounded 2.5-9%
- Position size: 10 shares (Rs 23,790, 23.8% of capital) for max 1.5% capital risk = Rs 1,500

- *Risk:* Gap risk: overnight/global gaps can jump past the 2,254.4 stop
- *Risk:* Illiquid tape on result days: use limit orders near VWAP

## Pick 2: Bharat Petroleum Corporation (BPCL)

- **Sector:** OIL & GAS | **Spot:** 8,490.5 | **Conviction:** HIGH (83/100)
- **Expected Return:** +7.5% to +10.0% in ~28 days (cap 28 days)
- **Entry:** up to 8,490.5 | **Stop:** 7,961.6 (-6.2%) | **Targets:** 9,125.1 / 9,336.7 | **R:R:** ~1.2
- **Position size:** 2 shares (~17.0% of Rs 100,000; max loss at stop Rs 1,500)
- **Invalidation:** Daily close below 7,961.6 (-6.2%; breaks the 4-week structure). Setup also void if Nifty loses 27,662.
- Time stop: if neither target is hit by day 28 and the position is below +1%, exit and reassess.

### Technical Agent - STRONG BULLISH (score 77.0, confidence 83%, data OK)

- Close 8,490.5 | EMA20/50/200: 8,328.1 / 7,898.8 / 6,142.6
- RSI(14) 56.5 | ADX(14) 27.4 (+DI 37 vs -DI 25)
- MACD hist -39.40 (rising) | 20d return +12.0%
- RS vs Nifty: 20d +9.4% | 63d +24.8%
- Below 20-day Donchian high (8,900.0) | -3.7% vs 3-month high
- Setup: PULLBACK-IN-TREND | ATR(14) 240.4 (2.8% of price)

- *Risk:* Break of EMA50 (7,898.8) would invalidate the trend structure
- *Risk:* Sector/market-wide shock overrides stock setup

### Fundamental & Quality Agent - STRONG BULLISH (score 73.8, confidence 85%, data OK)

- TTM revenue growth 18.8% | net income growth 15.1% | margin 6.8%
- ROE 31.1% | D/E 0.7 | FCF(TTM) positive
- PE 28.5 | PB 9.0 (vs industry median PE 47.3 (n=3))
- Insider/promoter holding proxy: 48.6%

- *Risk:* Quarterly-statement data can lag; verify latest results before acting

### News & Sentiment Agent - STRONG BULLISH (score 81.3, confidence 41%, data DEGRADED)

- 3 headlines in last 14 days | weighted tone 81/100 (pos 2 vs neg 0 keyword hits)
- [+] Brokerages positive on Bharat Petroleum Corporation, raise target price
- [o] Bharat Petroleum Corporation trades flat amid mixed market cues
- [+] Analysts flag rich valuation in Bharat Petroleum Corporation after rally

- *Risk:* Keyword sentiment is coarse; earnings-day tone can flip fast
- *Risk:* Headlines are free-RSS only - no paid newsroom coverage

### Risk Agent - LOW RISK (score 82.0, confidence 70%, data OK)

- Liquidity: 20d avg turnover Rs 4,148 cr (PASS vs Rs 75 cr floor)
- Volatility: 20d annualised 37% (1y percentile 85) | ATR 2.8% of price
- Beta vs Nifty -0.21 | 6-month max drawdown -7.6%
- Suggested stop: 7,961.6 (-6.2%) = max(63d swing low - 0.5 ATR, spot - 2.2 ATR), bounded 2.5-9%
- Position size: 2 shares (Rs 16,981, 17.0% of capital) for max 1.5% capital risk = Rs 1,500

- *Risk:* Gap risk: overnight/global gaps can jump past the 7,961.6 stop
- *Risk:* Illiquid tape on result days: use limit orders near VWAP

## Rejected Ideas (Mother Agent cuts)

- **HYUNDAI** (composite 83): Rank 3: outside top 2 (max picks cap)
- **SHREECEM** (composite 81): Rank 4: outside top 2 (max picks cap)
- **AXISBANK** (composite 81): Rank 5: outside top 2 (max picks cap)
- **APOLLOHOSP** (composite 80): Rank 6: outside top 2 (max picks cap)
- **ULTRACEMCO** (composite 79): Rank 7: outside top 2 (max picks cap)
- **TATACONSUM** (composite 78): Rank 8: outside top 2 (max picks cap)
- **WIPRO** (composite 77): Rank 9: outside top 2 (max picks cap)
- **HCLTECH** (composite 76): Rank 10: outside top 2 (max picks cap)
- **CHOLAFIN** (composite 76): Rank 11: outside top 2 (max picks cap)
- **SUNPHARMA** (composite 73): Rank 12: outside top 2 (max picks cap)

## Methodology (transparent, free data only)

Composite conviction = 0.35*Technical + 0.20*Fundamental + 0.15*News + 0.15*Sector/Macro tailwind + 0.15*Risk, adjusted by the regime (max +6 / -10) and sector tailwind (+/-4). Hard gates: liquidity floor, risk-score floor, technical floor, news red flags, crisis-regime gate. Maximum 2 published picks; standing aside is a first-class outcome.

Expected return: conservative target = nearest meaningful overhead resistance (3-month high / 20-day channel / 52-week high, each >=1.5% away) or a 1.2x-stop-distance projection; optimistic target = second resistance or an ATR(21) projection, always offering >=1.6x the stop distance and capped at +10%. At 52-week highs (price discovery) targets are pure ATR projections. Horizon = diffusion heuristic on the ATR distance, capped at 28 days. Ideas with reward-to-risk below 1.0 are rejected. Position size risks at most 1.5% of capital between entry and stop.

Data sources: Yahoo Finance (prices, statements - `.NS` symbols), NSE public FII/DII endpoint (when reachable), Google News RSS, Economic Times / Moneycontrol / Business Standard RSS, Yahoo macro tickers (USD/INR, Brent, S&P 500, India VIX, NSE sector indices).

- *Data note:* DEMO MODE: all data below is synthetic and clearly labelled.

> **Disclaimer:** This report is automated educational research output generated
> from free public data sources. It is **not investment advice**. The system is
> not a SEBI-registered research analyst or investment adviser. Expected returns
> are model-derived probabilistic estimates (ATR/structure based), not guarantees.
> Markets can invalidate any setup overnight. Trade at your own risk and consult
> a SEBI-registered adviser.
