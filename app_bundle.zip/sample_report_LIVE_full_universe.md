# Indian Equity Multi-Agent Research Report

Generated: 09-Nov-2026 16:28 IST | Mode: **LIVE** | Universe scanned: 105 | Usable: 99 | Deep-dive shortlist: 12

---

## Mother Agent - Final Verdict

**Final Recommendation**

**Stock 1: JSW Steel (JSWSTEEL)** | Expected Return: **+6.4% to +8.5% in ~28 days (<= 28 days)** | Conviction: HIGH (86/100) | Thesis: Trend Continuation setup; RS vs Nifty +4.1% (20d); METALS sector tailwind; fundamentals adequate (ROE 25%, D/E 0.8); news tone supportive; risk agent: LOW RISK | Key Risks: Break of EMA50 (1,266.9) would invalidate the trend structure; Sector/market-wide shock overrides stock setup; Keyword sentiment is coarse; earnings-day tone can flip fast | Invalidation: Daily close below 1,275.3 (-5.3%; breaks the 4-week structure). Setup also void if Nifty loses 23,413.

  - Trade plan: entry up to 1,347.0; stop 1,275.3 (-5.3%); targets 1,433.0 / 1,461.7; R:R ~1.2 | size 18 shares (~24.2% of Rs 100,000 capital, max risk Rs 1,500)
  - Time stop: if neither target is hit by day 28 and the position is below +1%, exit and reassess.

**Stock 2: Mankind Pharma (MANKIND)** | Expected Return: **+7.7% to +10.0% in ~28 days (<= 28 days)** | Conviction: HIGH (85/100) | Thesis: Breakout setup; RS vs Nifty +1.4% (20d); PHARMA sector tailwind; fundamentals adequate (ROE 13%, D/E 0.3); news tone supportive; risk agent: LOW RISK | Key Risks: Price 2.9 ATR above EMA20 - extended, chase risk; Break of EMA50 (2,427.0) would invalidate the trend structure; Keyword sentiment is coarse; earnings-day tone can flip fast | Invalidation: Daily close below 2,496.9 (-6.4%; breaks the 4-week structure). Setup also void if Nifty loses 23,413.

  - Trade plan: entry up to 2,668.3; stop 2,496.9 (-6.4%); targets 2,874.0 / 2,935.1; R:R ~1.2 | size 8 shares (~21.4% of Rs 100,000 capital, max risk Rs 1,500)
  - Time stop: if neither target is hit by day 28 and the position is below +1%, exit and reassess.

**4-Week Nifty Outlook**

Regime: STRONG BULL. Nifty is in a strong uptrend above rising 50/200-DMA with healthy breadth - dips are being bought. Breadth: 86% of the tracked universe above its 50-DMA and 63% above the 200-DMA. 4-week expected move (1 sigma, from ATR): about +/-5.7% around 25,045. Over the next four weeks the base case (40%) is a 24,617-25,614 grind; a push toward 26,469 (48% odds, stretch 27,324) needs the index to hold above 23,413; a break below 23,413 opens 23,056 (12% odds, stretch 22,273), with deeper support near 21,520 (200-DMA zone 24,011).

Key levels - resistance: 25,757 | support-1: 23,413 | support-2: 21,520 | 50-DMA: 23,413 | 200-DMA: 24,011

Scenario odds: Bull 48% (target 26,469) | Base 40% (24,617-25,614) | Bear 12% (target 23,056)

**Confidence & Disclaimer**

Overall confidence: **HIGH** (84/100). Confidence reflects data quality and signal agreement across agents; it is not a probability of profit.

Generated 09-Nov-2026 16:29 IST by the Indian Equity Multi-Agent Research System. Expected returns are model-derived probabilistic estimates from volatility and structure, NOT guarantees. Markets can invalidate any setup overnight. This is educational research output, not investment advice; the system is not a SEBI-registered research analyst or adviser. Consult a registered adviser and read scheme documents before trading.

---

## Market Context (Nifty + Macro)

**Regime: STRONG BULL** | Regime score 80/100 | Confidence 70%

| Nifty level | Value |
|---|---|
| Spot | 25,045 |
| 20-DMA (EMA) | 23,550 |
| 50-DMA (EMA) | 23,413 |
| 200-DMA (EMA) | 24,011 |
| Resistance (3m high zone) | 25,757 |
| Support 1 | 23,413 |
| Support 2 | 21,520 |
| ATR(21) | 311 |
| 4-week expected move (1 sigma) | 1,424 |

| 4-week scenario | Probability | Level(s) |
|---|---|---|
| Bull | 48% | target 26,469 (stretch 27,324) |
| Base | 40% | 24,617 - 25,614 |
| Bear | 12% | target 23,056 (stretch 22,273) |

**Macro risk-appetite score: 66/100 (RISK-ON)** | Confidence 72%

Sector tailwind (20-day momentum based): IT 72, BANKS 72, NBFC/FINANCIALS 72, INSURANCE 72, AUTO 72, PHARMA 72, HEALTHCARE 72, FMCG 72, CONSUMER 72, RETAIL 72, ENERGY 72, OIL & GAS 72, POWER 72, METALS 72, CEMENT 72, INFRA 72, LOGISTICS 72, DEFENCE 72, CAPITAL GOODS 72, DIVERSIFIED 72, REALTY 72

Breadth: 86% above 50-DMA | 63% above 200-DMA | 39 new 20d highs vs 0 lows

## Candidate Scoreboard

| Symbol | Name | Sector | Spot | Tech | Fund | News | Risk | Sector TW | Composite | Status |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|---|
| JSWSTEEL | JSW Steel | METALS | 1,347.0 | 84.0 | 72.0 | 84.2 | 80.0 | 72 | **86** | PICK |
| MANKIND | Mankind Pharma | PHARMA | 2,668.3 | 88.0 | 59.0 | 99.7 | 70.0 | 72 | **85** | PICK |
| GAIL | GAIL India | OIL & GAS | 188.0 | 76.0 | 65.0 | 95.6 | 86.0 | 72 | **84** | Rejected: Rank 3: outside top 2 (max picks cap) |
| HDFCBANK | HDFC Bank | BANKS | 798.2 | 74.0 | 72.0 | 92.6 | 84.0 | 72 | **84** | Rejected: Rank 4: outside top 2 (max picks cap) |
| BAJAJ-AUTO | Bajaj Auto | AUTO | 10,979.0 | 77.0 | 71.0 | 78.8 | 87.0 | 72 | **83** | Rejected: Rank 5: outside top 2 (max picks cap) |
| PNB | Punjab National Bank | BANKS | 132.2 | 84.0 | 58.8 | 76.9 | 86.0 | 72 | **83** | Rejected: Rank 6: outside top 2 (max picks cap) |
| LT | Larsen & Toubro | INFRA | 4,185.0 | 74.0 | 60.0 | 79.6 | 90.0 | 72 | **81** | Rejected: Rank 7: outside top 2 (max picks cap) |
| HCLTECH | HCL Technologies | IT | 1,407.0 | 81.0 | 72.0 | 50.0 | 79.0 | 72 | **79** | Rejected: Rank 8: outside top 2 (max picks cap) |
| BHARTIARTL | Bharti Airtel | TELECOM | 2,072.1 | 76.0 | 66.0 | 98.2 | 80.0 | 50 | **79** | Rejected: Rank 9: outside top 2 (max picks cap) |
| TECHM | Tech Mahindra | IT | 1,805.0 | 76.0 | 69.0 | 50.0 | 73.0 | 72 | **76** | Rejected: Rank 10: outside top 2 (max picks cap) |
| ETERNAL | Eternal (Zomato) | CONSUMER | 363.5 | 77.0 | 48.0 | 50.0 | 84.0 | 72 | **74** | Rejected: Rank 11: outside top 2 (max picks cap) |
| ADANIGREEN | Adani Green Energy | POWER | 1,448.9 | 77.0 | 30.9 | 78.9 | 73.0 | 72 | **73** | Rejected: Rank 12: outside top 2 (max picks cap) |

## Pick 1: JSW Steel (JSWSTEEL)

- **Sector:** METALS | **Spot:** 1,347.0 | **Conviction:** HIGH (86/100)
- **Expected Return:** +6.4% to +8.5% in ~28 days (cap 28 days)
- **Entry:** up to 1,347.0 | **Stop:** 1,275.3 (-5.3%) | **Targets:** 1,433.0 / 1,461.7 | **R:R:** ~1.2
- **Position size:** 18 shares (~24.2% of Rs 100,000; max loss at stop Rs 1,500)
- **Invalidation:** Daily close below 1,275.3 (-5.3%; breaks the 4-week structure). Setup also void if Nifty loses 23,413.
- Time stop: if neither target is hit by day 28 and the position is below +1%, exit and reassess.

### Technical Agent - STRONG BULLISH (score 84.0, confidence 73%, data OK)

- Close 1,347.0 | EMA20/50/200: 1,282.0 / 1,266.9 / 1,244.0
- RSI(14) 65.3 | ADX(14) 24.8 (+DI 32 vs -DI 16)
- MACD hist +15.60 (fading) | 20d return +15.3%
- RS vs Nifty: 20d +4.1% | 63d +1.7%
- Below 20-day Donchian high (1,370.0) | -0.7% vs 3-month high
- Setup: TREND-CONTINUATION | ATR(14) 32.6 (2.4% of price)

- *Risk:* Break of EMA50 (1,266.9) would invalidate the trend structure
- *Risk:* Sector/market-wide shock overrides stock setup

### Fundamental & Quality Agent - STRONG BULLISH (score 72.0, confidence 85%, data OK)

- TTM revenue growth 26.5% | net income growth 141.7% | margin 14.6%
- ROE 25.1% | D/E 0.8 | FCF(TTM) negative/na
- PE 11.6 | PB 2.9 (absolute bands)
- Insider/promoter holding proxy: 0.6%

- *Risk:* Quarterly-statement data can lag; verify latest results before acting

### News & Sentiment Agent - STRONG BULLISH (score 84.2, confidence 63%, data OK)

- 14 headlines in last 14 days | weighted tone 84/100 (pos 5 vs neg 2 keyword hits)
- [o] JSWSTEEL Stock Price and Chart — NSE:JSWSTEEL - TradingView
- [-] JSWSTEEL Outlook for the Week - Equitypandit
- [o] JSW Steel (JSWSTEEL) Share Price Today (NSE), Market News - TechGraph
- [o] JSW Steel (NSEI:JSWSTEEL) Stock Forecast & Analyst Predictions - Simply Wall St

- *Risk:* Keyword sentiment is coarse; earnings-day tone can flip fast
- *Risk:* Headlines are free-RSS only - no paid newsroom coverage

### Risk Agent - LOW RISK (score 80.0, confidence 70%, data OK)

- Liquidity: 20d avg turnover Rs 283 cr (PASS vs Rs 75 cr floor)
- Volatility: 20d annualised 33% (1y percentile 86) | ATR 2.4% of price
- Beta vs Nifty 0.94 | 6-month max drawdown -12.9%
- Suggested stop: 1,275.3 (-5.3%) = max(63d swing low - 0.5 ATR, spot - 2.2 ATR), bounded 2.5-9%
- Position size: 18 shares (Rs 24,246, 24.2% of capital) for max 1.5% capital risk = Rs 1,500

- *Risk:* Gap risk: overnight/global gaps can jump past the 1,275.3 stop
- *Risk:* Illiquid tape on result days: use limit orders near VWAP

## Pick 2: Mankind Pharma (MANKIND)

- **Sector:** PHARMA | **Spot:** 2,668.3 | **Conviction:** HIGH (85/100)
- **Expected Return:** +7.7% to +10.0% in ~28 days (cap 28 days)
- **Entry:** up to 2,668.3 | **Stop:** 2,496.9 (-6.4%) | **Targets:** 2,874.0 / 2,935.1 | **R:R:** ~1.2
- **Position size:** 8 shares (~21.4% of Rs 100,000; max loss at stop Rs 1,500)
- **Invalidation:** Daily close below 2,496.9 (-6.4%; breaks the 4-week structure). Setup also void if Nifty loses 23,413.
- Time stop: if neither target is hit by day 28 and the position is below +1%, exit and reassess.

### Technical Agent - STRONG BULLISH (score 88.0, confidence 83%, data OK)

- Close 2,668.3 | EMA20/50/200: 2,461.9 / 2,427.0 / 2,359.4
- RSI(14) 68.7 | ADX(14) 27.1 (+DI 37 vs -DI 12)
- MACD hist +27.01 (rising) | 20d return +12.7%
- RS vs Nifty: 20d +1.4% | 63d +6.7%
- Cleared 20-day Donchian high (2,561.2) | +4.8% vs 3-month high
- Setup: BREAKOUT | ATR(14) 77.9 (2.9% of price)

- *Risk:* Price 2.9 ATR above EMA20 - extended, chase risk
- *Risk:* Break of EMA50 (2,427.0) would invalidate the trend structure
- *Risk:* Sector/market-wide shock overrides stock setup

### Fundamental & Quality Agent - BULLISH (score 59.0, confidence 85%, data OK)

- TTM revenue growth 21.5% | net income growth 62.3% | margin 14.6%
- ROE 12.8% | D/E 0.3 | FCF(TTM) negative/na
- PE 50.0 | PB 6.3 (absolute bands)
- Insider/promoter holding proxy: unavailable (free-source limitation)

- *Risk:* Quarterly-statement data can lag; verify latest results before acting

### News & Sentiment Agent - STRONG BULLISH (score 99.7, confidence 77%, data OK)

- 21 headlines in last 14 days | weighted tone 100/100 (pos 15 vs neg 1 keyword hits)
- [o] Mankind Pharma Share Price - Live NSE: MANKIND Stock Price & Chart - Upstox
- [+] Mankind Pharma stock surges 9% after strong Q2 results; Kotak sees big upside, other brokerages cautious - Mon
- [+] Mankind Pharma shares jump 8% as Q2 profit rises 38% to Rs 716 crore - The Economic Times
- [+] Mankind Pharma Shares Jump Nearly 8% After Q2 Profit Rises 39% - NDTV Profit

- *Risk:* Keyword sentiment is coarse; earnings-day tone can flip fast
- *Risk:* Headlines are free-RSS only - no paid newsroom coverage

### Risk Agent - LOW RISK (score 70.0, confidence 70%, data OK)

- Liquidity: 20d avg turnover Rs 194 cr (PASS vs Rs 75 cr floor)
- Volatility: 20d annualised 43% (1y percentile 96) | ATR 2.9% of price
- Beta vs Nifty 0.20 | 6-month max drawdown -15.5%
- Suggested stop: 2,496.9 (-6.4%) = max(63d swing low - 0.5 ATR, spot - 2.2 ATR), bounded 2.5-9%
- Position size: 8 shares (Rs 21,346, 21.3% of capital) for max 1.5% capital risk = Rs 1,500

- *Risk:* Gap risk: overnight/global gaps can jump past the 2,496.9 stop
- *Risk:* Illiquid tape on result days: use limit orders near VWAP

## Rejected Ideas (Mother Agent cuts)

- **GAIL** (composite 84): Rank 3: outside top 2 (max picks cap)
- **HDFCBANK** (composite 84): Rank 4: outside top 2 (max picks cap)
- **BAJAJ-AUTO** (composite 83): Rank 5: outside top 2 (max picks cap)
- **PNB** (composite 83): Rank 6: outside top 2 (max picks cap)
- **LT** (composite 81): Rank 7: outside top 2 (max picks cap)
- **HCLTECH** (composite 79): Rank 8: outside top 2 (max picks cap)
- **BHARTIARTL** (composite 79): Rank 9: outside top 2 (max picks cap)
- **TECHM** (composite 76): Rank 10: outside top 2 (max picks cap)
- **ETERNAL** (composite 74): Rank 11: outside top 2 (max picks cap)
- **ADANIGREEN** (composite 73): Rank 12: outside top 2 (max picks cap)

## Methodology (transparent, free data only)

Composite conviction = 0.35*Technical + 0.20*Fundamental + 0.15*News + 0.15*Sector/Macro tailwind + 0.15*Risk, adjusted by the regime (max +6 / -10) and sector tailwind (+/-4). Hard gates: liquidity floor, risk-score floor, technical floor, news red flags, crisis-regime gate. Maximum 2 published picks; standing aside is a first-class outcome.

Expected return: conservative target = nearest meaningful overhead resistance (3-month high / 20-day channel / 52-week high, each >=1.5% away) or a 1.2x-stop-distance projection; optimistic target = second resistance or an ATR(21) projection, always offering >=1.6x the stop distance and capped at +10%. At 52-week highs (price discovery) targets are pure ATR projections. Horizon = diffusion heuristic on the ATR distance, capped at 28 days. Ideas with reward-to-risk below 1.0 are rejected. Position size risks at most 1.5% of capital between entry and stop.

Data sources: Yahoo Finance (prices, statements - `.NS` symbols), NSE public FII/DII endpoint (when reachable), Google News RSS, Economic Times / Moneycontrol / Business Standard RSS, Yahoo macro tickers (USD/INR, Brent, S&P 500, India VIX, NSE sector indices).

- *Data note:* FII/DII flows unavailable from free NSE endpoints on this network - macro agent uses a neutral, disclosed assumption.

> **Disclaimer:** This report is automated educational research output generated
> from free public data sources. It is **not investment advice**. The system is
> not a SEBI-registered research analyst or investment adviser. Expected returns
> are model-derived probabilistic estimates (ATR/structure based), not guarantees.
> Markets can invalidate any setup overnight. Trade at your own risk and consult
> a SEBI-registered adviser.
