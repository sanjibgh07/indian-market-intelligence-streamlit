"""Indian Equity Multi-Agent Research Desk - Streamlit web application.

Run:  streamlit run app.py

Free data only. The Mother Agent is the single source of final recommendations.
"""
from __future__ import annotations

import os
import sys

import pandas as pd
import streamlit as st

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config.settings import Config, universe_for_scope  # noqa: E402
from core.models import ResearchResult                   # noqa: E402
from engine.orchestrator import ResearchOrchestrator     # noqa: E402
from utils.helpers import ist_stamp                      # noqa: E402

st.set_page_config(page_title="Indian Equity Multi-Agent Research Desk",
                   page_icon=None, layout="wide")

# ---------------------------------------------------------------------------
# Sidebar: configuration + run control
# ---------------------------------------------------------------------------
st.sidebar.title("Research Desk Controls")
st.sidebar.caption("Multi-agent stock research for NSE/BSE - free data only, "
                   "Mother Agent has final authority. Max 2 picks, <= 4-week horizon.")

scope = st.sidebar.selectbox("Universe", ["NIFTY_100", "NIFTY_50", "CUSTOM"], index=0,
                             help="NIFTY_100 = NIFTY 50 + Next 50 (editable in config/settings.py)")
custom = ""
if scope == "CUSTOM":
    custom = st.sidebar.text_area("Custom NSE symbols (comma separated)",
                                  "RELIANCE, TCS, HDFCBANK, BEL, DLF, TATAPOWER")

c1, c2 = st.sidebar.columns(2)
max_picks = c1.selectbox("Max picks", [1, 2], index=1)
shortlist_size = c2.slider("Deep-dive size", 6, 20, 12)
min_conviction = st.sidebar.slider("Min conviction (composite)", 50.0, 85.0, 68.0, 1.0,
                                   help="Ideas below this composite score are rejected by the Mother Agent")
capital = st.sidebar.number_input("Capital (Rs)", 10_000, 50_000_000, 100_000, step=10_000)
risk_pct = st.sidebar.slider("Risk per trade (% of capital)", 0.5, 3.0, 1.5, 0.25)
adv_min = st.sidebar.slider("Liquidity floor (Rs cr ADV)", 25.0, 500.0, 75.0, 25.0)
demo_mode = st.sidebar.checkbox("Demo mode (synthetic data, offline)", value=False,
                                help="Runs the full pipeline on seeded synthetic data - "
                                     "for UI walkthroughs when the network blocks data sources.")
run_btn = st.sidebar.button("Run Full Multi-Agent Research", type="primary", width="stretch")

if run_btn:
    for k in ("result", "stage_slots"):
        st.session_state.pop(k, None)

cfg = Config(scope=scope, custom_symbols=custom, max_picks=max_picks,
             shortlist_size=shortlist_size, min_conviction=min_conviction,
             capital=float(capital), risk_per_trade_pct=float(risk_pct),
             adv_min_cr=float(adv_min), demo=bool(demo_mode))


# ---------------------------------------------------------------------------
def render_agent_expander(rep, title: str):
    """One agent's report inside an expander with badge + key points."""
    if rep is None:
        return
    badge = {"OK": "", "DEGRADED": "[data degraded]", "UNAVAILABLE": "[data unavailable]"}.get(rep.data_quality, "")
    head = f"{title} - {rep.verdict} | score {rep.score if rep.score is not None else 'n/a'} {badge}"
    with st.expander(head, expanded=False):
        cA, cB, cC = st.columns(3)
        cA.metric("Score", f"{rep.score:.0f}/100" if rep.score is not None else "n/a")
        cB.metric("Confidence", f"{rep.confidence:.0f}%")
        cC.metric("Data quality", rep.data_quality)
        st.markdown("**Key points**")
        for kp in rep.key_points:
            st.markdown(f"- {kp}")
        if rep.risks:
            st.markdown("**Risks flagged**")
            for r in rep.risks:
                st.markdown(f"- {r}")


def render_results(res: ResearchResult):
    # banner -------------------------------------------------------------
    if res.mode == "DEMO":
        st.error("DEMO MODE - every number below is SYNTHETIC, for interface "
                 "walkthrough only. Uncheck demo mode in the sidebar for a live run.")
    st.caption(f"Generated {res.as_of} | universe scanned {res.universe_scanned} | "
               f"usable {res.universe_usable} | shortlist {len(res.shortlist)} | "
               f"mode {res.mode}")

    # final verdict --------------------------------------------------------
    st.subheader("Mother Agent - Final Recommendation")
    mkt = res.market
    picks = res.picks
    if picks:
        for i, c in enumerate(picks, 1):
            p = c.plan
            with st.container(border=True):
                top1, top2 = st.columns([3, 2])
                top1.markdown(
                    f"### Stock {i}: {c.name} ({c.symbol})")
                top2.markdown(
                    f"**Expected Return: +{p.ret_low_pct:.1f}% to +{p.ret_high_pct:.1f}% "
                    f"in ~{p.horizon_days} days**  \n"
                    f"Conviction: **{c.conviction}** ({c.composite:.0f}/100) | Sector: {c.sector}")
                st.markdown(f"**Thesis:** {p_thesis(c)}")
                st.markdown(
                    f"- Entry up to **{p.entry:,.1f}** | Stop **{p.stop:,.1f}** (-{p.stop_pct:.1f}%) | "
                    f"Targets **{p.target_low:,.1f} / {p.target_high:,.1f}** | R:R ~{p.rr_ratio:.1f}")
                st.markdown(
                    f"- Position: **{p.shares:,} shares** (~{p.position_pct:.1f}% of "
                    f"Rs {cfg.capital:,.0f}) | Max loss at stop: Rs {p.risk_amount:,.0f}")
                st.markdown(f"- **Invalidation:** {p.invalidation}")
                st.markdown(f"- {p.time_stop}")
                # small price chart with EMAs
                if res.market and res.market.nifty_history is not None:
                    chart = stock_chart(c.symbol)
                    if chart is not None and len(chart):
                        st.line_chart(chart, height=220)
    else:
        st.warning("**No high-conviction idea this week.** The Mother Agent chose to "
                   "stand aside - capital preservation is a valid decision.")

    # nifty outlook ----------------------------------------------------------
    st.subheader("4-Week Nifty Outlook")
    if mkt and mkt.regime:
        d = mkt.regime.details
        lv, sc = d.get("levels", {}), d.get("scenarios", {})
        a1, a2 = st.columns([3, 2])
        with a1:
            rs = "n/a" if mkt.regime.score is None else f"{mkt.regime.score:.0f}"
            st.info(f"**Regime: {d.get('regime', 'UNKNOWN')}** "
                    f"(score {rs}/100, confidence {mkt.regime.confidence:.0f}%)\n\n"
                    f"{mkt.outlook_text}")
            st.markdown("**Risks:** " + " | ".join(mkt.regime.risks))
        with a2:
            if lv:
                lv_rows = {"Spot": lv.get("spot"), "20-DMA": lv.get("ema20"),
                           "50-DMA": lv.get("ema50"), "200-DMA": lv.get("ema200"),
                           "Resistance": lv.get("resistance_1"), "Support 1": lv.get("support_1"),
                           "Support 2": lv.get("support_2"),
                           "4w expected move (1s)": lv.get("expected_move_4w_1sigma")}
                st.dataframe(pd.DataFrame(
                    [{"Level": k, "Value": v} for k, v in lv_rows.items()],
                    ).set_index("Level"), width="stretch")
            if sc:
                st.markdown(
                    f"**Scenario odds (4 weeks):** Bull {sc.get('bull', {}).get('prob', '-')}% "
                    f"(target {sc.get('bull', {}).get('target', 0):,.0f}) | "
                    f"Base {sc.get('base', {}).get('prob', '-')}% "
                    f"({sc.get('base', {}).get('range_low', 0):,.0f}-{sc.get('base', {}).get('range_high', 0):,.0f}) | "
                    f"Bear {sc.get('bear', {}).get('prob', '-')}% "
                    f"(target {sc.get('bear', {}).get('target', 0):,.0f})")
            if mkt.nifty_history is not None and len(mkt.nifty_history):
                st.line_chart(mkt.nifty_history["Close"].tail(120), height=200)
    else:
        st.warning("Regime agent could not produce an outlook (data unavailable).")

    # macro ---------------------------------------------------------------------
    if mkt and mkt.macro:
        render_agent_expander(mkt.macro, "Macro & Sector Agent")
    if mkt and mkt.regime:
        render_agent_expander(mkt.regime, "Market Regime Agent")

    # scoreboard --------------------------------------------------------------
    st.subheader("Candidate Scoreboard (deep-dive pool)")
    if res.candidates:
        rows = []
        for c in sorted(res.candidates, key=lambda x: -x.composite):
            rows.append({
                "Symbol": c.symbol, "Name": c.name, "Sector": c.sector,
                "Spot": round(c.spot, 1),
                "Tech": None if not c.tech or c.tech.score is None else round(c.tech.score),
                "Fund": None if not c.fund or c.fund.score is None else round(c.fund.score),
                "News": None if not c.news or c.news.score is None else round(c.news.score),
                "Risk": None if not c.risk or c.risk.score is None else round(c.risk.score),
                "Sect TW": round(c.sector_tailwind),
                "Composite": round(c.composite),
                "Status": "PICK" if c in res.picks else "Rejected",
            })
        st.dataframe(pd.DataFrame(rows), width="stretch", hide_index=True)

    # per-candidate agent reports ----------------------------------------------
    st.subheader("Agent Reports (expandable)")
    for c in res.candidates:
        tag = " **[PICK]**" if c in res.picks else \
              (f" *(rejected: {c.reject_reason})*" if c.rejected else "")
        with st.expander(f"{c.name} ({c.symbol}) - composite {c.composite:.0f}{tag}",
                         expanded=c in res.picks):
            render_agent_expander(c.tech, "Technical Agent")
            render_agent_expander(c.fund, "Fundamental & Quality Agent")
            render_agent_expander(c.news, "News & Sentiment Agent")
            render_agent_expander(c.risk, "Risk Agent")

    # rejected --------------------------------------------------------------------
    if res.rejected:
        st.subheader("Rejected Ideas & Why")
        for c in sorted(res.rejected, key=lambda x: -x.composite):
            st.markdown(f"- **{c.symbol}** (composite {c.composite:.0f}): {c.reject_reason}")

    # data notes --------------------------------------------------------------------
    if res.data_notes:
        with st.expander("Data quality notes"):
            for n in res.data_notes:
                st.markdown(f"- {n}")

    # download --------------------------------------------------------------------
    st.divider()
    st.subheader("Download Research Report")
    fname = f"research_report_{ist_stamp('%Y%m%d_%H%M')}.md"
    st.download_button("Download full report (Markdown)", data=res.report_md,
                       file_name=fname, mime="text/markdown", width="stretch")
    with st.expander("Preview report"):
        st.markdown(res.report_md)

    st.caption("Disclaimer: automated educational research from free data. Not investment "
               "advice. Not a SEBI-registered adviser. Expected returns are model estimates, "
               "not guarantees.")


def p_thesis(c):
    from agents.mother import MotherAgent
    return MotherAgent()._thesis(c)


def stock_chart(symbol: str):
    """Close + EMA20/50 for a pick (from the app-level cache)."""
    res = st.session_state.get("result")
    if res is None:
        return None
    df = _price_frame(symbol)
    if df is None or not len(df):
        return None
    out = pd.DataFrame({
        "Close": df["Close"],
        "EMA20": df["Close"].ewm(span=20, adjust=False).mean(),
        "EMA50": df["Close"].ewm(span=50, adjust=False).mean(),
    }).tail(180)
    return out


@st.cache_data(ttl=900, show_spinner=False)
def _price_frame(symbol: str, demo: bool = False):
    from data import demo as demo_data
    from data import yf_client
    if demo:
        return demo_data.synth_prices(symbol)
    d = yf_client.download_prices([symbol], "6mo", log=lambda *a: None)
    return d.get(symbol)


# ---------------------------------------------------------------------------
# Main flow
# ---------------------------------------------------------------------------
st.title("Indian Equity Multi-Agent Research Desk")
st.markdown("NSE/BSE only | free data sources | **max 1-2 stock picks**, each with an "
            "expected-return range and a horizon capped at 28 days | Mother Agent has "
            "final authority and may reject all ideas.")

if run_btn:
    progress_slot = st.container()
    slots = {}

    def progress(stage_key, stage_label, pct, msg):
        with progress_slot:
            if stage_key not in slots:
                slots[stage_key] = st.status(stage_label, state="running", expanded=True)
                st.session_state["stage_slots"] = None
            s = slots[stage_key]
            s.update(label=f"{stage_label} - {msg} ({pct}%)", state="running")

    try:
        with st.spinner("Running full multi-agent research pipeline..."):
            result = ResearchOrchestrator(cfg, log=lambda *a: None).run(progress)
        for s in slots.values():
            s.update(state="complete")
        st.session_state["result"] = result
        st.toast("Research run complete", icon=None)
    except Exception as e:  # noqa: BLE001
        st.error(f"Research run failed: {type(e).__name__}: {e}")
        import traceback
        with st.expander("Technical details"):
            st.code(traceback.format_exc())

if "result" in st.session_state:
    st.divider()
    render_results(st.session_state["result"])
else:
    st.info("Configure the universe and risk parameters in the sidebar, then press "
            "**Run Full Multi-Agent Research**. A live run typically takes 1-3 minutes; "
            "demo mode is instant.")
    st.markdown(
        """
**What this system does**

1. **Technical Agent** screens the whole liquid universe (trend, momentum, structure, volume, relative strength) and shortlists the strongest 1-4 week setups.
2. **Macro & Sector Agent** reads FII/DII flows, USD/INR, crude, S&P 500, India VIX and sector momentum (free endpoints; unavailable drivers are disclosed and neutralised).
3. **Market Regime Agent** classifies the Nifty regime and builds the 4-week outlook with levels and scenario odds.
4. **Fundamental & Quality, News & Sentiment, Risk agents** deep-dive the shortlist: statements-derived quality metrics, RSS tone + red-flag detection, ATR stops and position sizing.
5. **Mother Agent** cross-verifies everything, applies hard vetoes (liquidity, risk floor, red flags, crisis gate) and publishes **at most 2** names - or "No high-conviction idea this week".
"""
    )
