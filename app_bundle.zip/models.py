"""Shared data models exchanged between agents, orchestrator, app and reports."""
from __future__ import annotations

import math
from dataclasses import dataclass, field, asdict
from datetime import datetime

import pandas as pd

# Verdict vocabulary used across agents
STRONG_BULLISH = "STRONG BULLISH"
BULLISH = "BULLISH"
NEUTRAL = "NEUTRAL"
BEARISH = "BEARISH"
STRONG_BEARISH = "STRONG BEARISH"
RISK_ON = "RISK-ON"
RISK_OFF = "RISK-OFF"
UNAVAILABLE = "UNAVAILABLE"

# Data-quality flags
Q_OK, Q_DEGRADED, Q_UNAVAILABLE = "OK", "DEGRADED", "UNAVAILABLE"


def verdict_from_score(score: float) -> str:
    """Map a 0-100 agent score to the standard verdict vocabulary."""
    if score is None or (isinstance(score, float) and math.isnan(score)):
        return UNAVAILABLE
    if score >= 70:
        return STRONG_BULLISH
    if score >= 58:
        return BULLISH
    if score >= 42:
        return NEUTRAL
    if score >= 28:
        return BEARISH
    return STRONG_BEARISH


@dataclass
class AgentReport:
    """Uniform output contract for every specialist agent."""
    agent_name: str
    verdict: str = NEUTRAL
    score: float | None = 50.0          # 0-100 (higher = more supportive of a long)
    confidence: float = 50.0            # 0-100 (how much the agent trusts itself)
    data_quality: str = Q_OK            # OK | DEGRADED | UNAVAILABLE
    key_points: list[str] = field(default_factory=list)
    risks: list[str] = field(default_factory=list)
    details: dict = field(default_factory=dict)
    symbol: str | None = None
    as_of: str = ""

    def to_dict(self) -> dict:
        return asdict(self)

    def score_or(self, default: float) -> float:
        if self.score is None:
            return default
        return float(self.score)


@dataclass
class TradePlan:
    """Concrete 4-week trade plan produced by the Mother Agent."""
    entry: float = 0.0
    stop: float = 0.0
    stop_pct: float = 0.0
    target_low: float = 0.0
    target_high: float = 0.0
    ret_low_pct: float = 0.0
    ret_high_pct: float = 0.0
    horizon_days: int = 28
    shares: int = 0
    position_value: float = 0.0
    position_pct: float = 0.0
    risk_amount: float = 0.0
    rr_ratio: float = 0.0
    invalidation: str = ""
    time_stop: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Candidate:
    """A shortlisted stock carrying all its specialist reports."""
    symbol: str
    name: str
    sector: str
    spot: float = float("nan")
    tech: AgentReport | None = None
    fund: AgentReport | None = None
    news: AgentReport | None = None
    risk: AgentReport | None = None
    sector_tailwind: float = 50.0       # 0-100 from Macro agent
    composite: float = 0.0
    conviction: str = ""                # LOW / MEDIUM / HIGH
    plan: TradePlan | None = None
    rejected: bool = False
    reject_reason: str = ""

    def to_dict(self) -> dict:
        d = {
            "symbol": self.symbol, "name": self.name, "sector": self.sector,
            "spot": self.spot, "composite": round(self.composite, 1),
            "conviction": self.conviction,
            "sector_tailwind": round(self.sector_tailwind, 1),
            "rejected": self.rejected, "reject_reason": self.reject_reason,
            "tech_score": self.tech.score if self.tech else None,
            "fund_score": self.fund.score if self.fund else None,
            "news_score": self.news.score if self.news else None,
            "risk_score": self.risk.score if self.risk else None,
        }
        return d


@dataclass
class MarketContext:
    """Market-level (Nifty + macro) outputs used by the Mother Agent."""
    regime: AgentReport | None = None
    macro: AgentReport | None = None
    nifty: dict = field(default_factory=dict)     # spot, levels, expected move, scenarios
    outlook_text: str = ""
    breadth: dict = field(default_factory=dict)
    nifty_history: pd.DataFrame | None = None     # for charting in the app

    def to_dict(self) -> dict:
        return {
            "regime": self.regime.to_dict() if self.regime else None,
            "macro": self.macro.to_dict() if self.macro else None,
            "nifty": self.nifty,
            "outlook_text": self.outlook_text,
            "breadth": self.breadth,
        }


@dataclass
class ResearchResult:
    """Everything one full research run produces."""
    as_of: str = ""
    mode: str = "LIVE"                              # LIVE | DEMO
    config_summary: dict = field(default_factory=dict)
    universe_scanned: int = 0
    universe_usable: int = 0
    shortlist: list[str] = field(default_factory=list)
    candidates: list[Candidate] = field(default_factory=list)
    market: MarketContext | None = None
    picks: list[Candidate] = field(default_factory=list)
    rejected: list[Candidate] = field(default_factory=list)
    final_text: str = ""
    report_md: str = ""
    data_notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "as_of": self.as_of, "mode": self.mode,
            "config_summary": self.config_summary,
            "universe_scanned": self.universe_scanned,
            "universe_usable": self.universe_usable,
            "shortlist": self.shortlist,
            "candidates": [c.to_dict() for c in self.candidates],
            "market": self.market.to_dict() if self.market else None,
            "picks": [c.symbol for c in self.picks],
            "final_text": self.final_text,
            "data_notes": self.data_notes,
        }
