"""Central configuration for the Indian Equity Multi-Agent Research System.

Everything a user may want to tune lives here. All data sources used are free:
  - yfinance (.NS suffix for NSE stocks)  -> prices, volumes, financial statements
  - NSE public endpoints (via nsepython if installed, else a built-in client)
  - Free news RSS: Google News, Economic Times, Moneycontrol, Business Standard
  - Free macro tickers on Yahoo: USD/INR, Brent, S&P 500, India VIX, NSE sector indices
"""
from __future__ import annotations

from dataclasses import dataclass, field

# ---------------------------------------------------------------------------
# Stock universe: NIFTY 50 + NIFTY NEXT 50 (large & liquid names only).
# NOTE: Index constituents change periodically (SEBI/exchange reviews).
#       This list is a config file - edit it any time. Tickers that fail to
#       resolve on Yahoo/NSE are skipped gracefully by the pipeline.
# ---------------------------------------------------------------------------
UNIVERSE_NIFTY_50 = [
    ("RELIANCE",  "Reliance Industries",            "OIL & GAS"),
    ("HDFCBANK",  "HDFC Bank",                      "BANKS"),
    ("ICICIBANK", "ICICI Bank",                     "BANKS"),
    ("INFY",      "Infosys",                        "IT"),
    ("TCS",       "Tata Consultancy Services",      "IT"),
    ("BHARTIARTL","Bharti Airtel",                  "TELECOM"),
    ("SBIN",      "State Bank of India",            "BANKS"),
    ("LT",        "Larsen & Toubro",                "INFRA"),
    ("ITC",       "ITC",                            "FMCG"),
    ("HINDUNILVR","Hindustan Unilever",             "FMCG"),
    ("BAJFINANCE","Bajaj Finance",                  "NBFC/FINANCIALS"),
    ("MARUTI",    "Maruti Suzuki India",            "AUTO"),
    ("M&M",       "Mahindra & Mahindra",            "AUTO"),
    ("SUNPHARMA", "Sun Pharmaceutical Industries",  "PHARMA"),
    ("AXISBANK",  "Axis Bank",                      "BANKS"),
    ("KOTAKBANK", "Kotak Mahindra Bank",            "BANKS"),
    ("NTPC",      "NTPC",                           "POWER"),
    ("ULTRACEMCO","UltraTech Cement",               "CEMENT"),
    ("TATAMOTORS","Tata Motors",                    "AUTO"),   # verify post-demerger ticker (TMLCV/TMPV)
    ("TATASTEEL", "Tata Steel",                     "METALS"),
    ("ASIANPAINT","Asian Paints",                   "CONSUMER"),
    ("TITAN",     "Titan Company",                  "CONSUMER"),
    ("POWERGRID", "Power Grid Corporation",         "POWER"),
    ("ADANIENT",  "Adani Enterprises",              "DIVERSIFIED"),
    ("ADANIPORTS","Adani Ports & SEZ",              "LOGISTICS"),
    ("COALINDIA", "Coal India",                     "ENERGY"),
    ("BAJAJFINSV","Bajaj Finserv",                  "NBFC/FINANCIALS"),
    ("WIPRO",     "Wipro",                          "IT"),
    ("HCLTECH",   "HCL Technologies",               "IT"),
    ("TECHM",     "Tech Mahindra",                  "IT"),
    ("NESTLEIND", "Nestle India",                   "FMCG"),
    ("GRASIM",    "Grasim Industries",              "CEMENT"),
    ("JSWSTEEL",  "JSW Steel",                      "METALS"),
    ("HINDALCO",  "Hindalco Industries",            "METALS"),
    ("DRREDDY",   "Dr Reddy's Laboratories",        "PHARMA"),
    ("CIPLA",     "Cipla",                          "PHARMA"),
    ("EICHERMOT", "Eicher Motors",                  "AUTO"),
    ("BAJAJ-AUTO","Bajaj Auto",                     "AUTO"),
    ("HEROMOTOCO","Hero MotoCorp",                  "AUTO"),
    ("ONGC",      "Oil & Natural Gas Corporation",  "OIL & GAS"),
    ("APOLLOHOSP","Apollo Hospitals Enterprise",    "HEALTHCARE"),
    ("SBILIFE",   "SBI Life Insurance",             "INSURANCE"),
    ("HDFCLIFE",  "HDFC Life Insurance",            "INSURANCE"),
    ("TRENT",     "Trent",                          "RETAIL"),
    ("BEL",       "Bharat Electronics",             "DEFENCE"),
    ("SHRIRAMFIN","Shriram Finance",                "NBFC/FINANCIALS"),
    ("JIOFIN",    "Jio Financial Services",         "NBFC/FINANCIALS"),
    ("ETERNAL",   "Eternal (Zomato)",               "CONSUMER"),
    ("TATACONSUM","Tata Consumer Products",         "FMCG"),
    ("INDUSINDBK","IndusInd Bank",                  "BANKS"),
    ("INDIGO",    "InterGlobe Aviation (IndiGo)",   "AVIATION"),
    ("MAXHEALTH", "Max Healthcare Institute",       "HEALTHCARE"),
]

UNIVERSE_NIFTY_NEXT_50 = [
    ("ADANIENSOL","Adani Energy Solutions",         "POWER"),
    ("ADANIGREEN","Adani Green Energy",             "POWER"),
    ("ADANIPOWER","Adani Power",                    "POWER"),
    ("AMBUJACEM", "Ambuja Cements",                 "CEMENT"),
    ("BANKBARODA","Bank of Baroda",                 "BANKS"),
    ("BAJAJHLDNG","Bajaj Holdings & Investment",    "NBFC/FINANCIALS"),
    ("BPCL",      "Bharat Petroleum Corporation",   "OIL & GAS"),
    ("BOSCHLTD",  "Bosch India",                    "AUTO"),
    ("BRITANNIA", "Britannia Industries",           "FMCG"),
    ("CANBK",     "Canara Bank",                    "BANKS"),
    ("CGPOWER",   "CG Power & Industrial Solutions","CAPITAL GOODS"),
    ("CHOLAFIN",  "Cholamandalam Investment & Finance","NBFC/FINANCIALS"),
    ("DABUR",     "Dabur India",                    "FMCG"),
    ("DIVISLAB",  "Divi's Laboratories",            "PHARMA"),
    ("DLF",       "DLF",                            "REALTY"),
    ("DMART",     "Avenue Supermarts (DMart)",      "RETAIL"),
    ("GAIL",      "GAIL India",                     "OIL & GAS"),
    ("GODREJCP",  "Godrej Consumer Products",       "FMCG"),
    ("HAL",       "Hindustan Aeronautics",          "DEFENCE"),
    ("HAVELLS",   "Havells India",                  "CAPITAL GOODS"),
    ("ICICIGI",   "ICICI Lombard General Insurance","INSURANCE"),
    ("ICICIPRULI","ICICI Prudential Life Insurance","INSURANCE"),
    ("INDHOTEL",  "Indian Hotels Company",          "CONSUMER"),
    ("IOC",       "Indian Oil Corporation",         "OIL & GAS"),
    ("IRFC",      "Indian Railway Finance Corporation","NBFC/FINANCIALS"),
    ("JINDALSTEL","Jindal Steel & Power",           "METALS"),
    ("JSWENERGY", "JSW Energy",                     "POWER"),
    ("LODHA",     "Macrotech Developers (Lodha)",   "REALTY"),
    ("LICI",      "Life Insurance Corporation",     "INSURANCE"),
    ("LTIM",      "LTIMindtree",                    "IT"),
    ("MANKIND",   "Mankind Pharma",                 "PHARMA"),
    ("MOTHERSON", "Samvardhana Motherson International","AUTO"),
    ("NHPC",      "NHPC",                           "POWER"),
    ("PIDILITIND","Pidilite Industries",            "CONSUMER"),
    ("PFC",       "Power Finance Corporation",      "NBFC/FINANCIALS"),
    ("PNB",       "Punjab National Bank",           "BANKS"),
    ("RECLTD",    "REC",                            "NBFC/FINANCIALS"),
    ("SHREECEM",  "Shree Cement",                   "CEMENT"),
    ("SIEMENS",   "Siemens India",                  "CAPITAL GOODS"),
    ("SRF",       "SRF",                            "DIVERSIFIED"),
    ("TATAPOWER", "Tata Power",                     "POWER"),
    ("TORNTPHARM","Torrent Pharmaceuticals",        "PHARMA"),
    ("TVSMOTOR",  "TVS Motor Company",              "AUTO"),
    ("UNITDSPR",  "United Spirits",                 "FMCG"),
    ("VBL",       "Varun Beverages",                "FMCG"),
    ("VEDL",      "Vedanta",                        "METALS"),
    ("ZYDUSLIFE", "Zydus Lifesciences",             "PHARMA"),
    ("PERSISTENT","Persistent Systems",             "IT"),
    ("POLYCAB",   "Polycab India",                  "CAPITAL GOODS"),
    ("DIXON",     "Dixon Technologies",             "CAPITAL GOODS"),
    ("HYUNDAI",   "Hyundai Motor India",            "AUTO"),
    ("PHOENIXLTD","Phoenix Mills",                  "REALTY"),
    ("KALYANKJIL","Kalyan Jewellers India",         "CONSUMER"),
]

# Sector -> NSE sector index tradable on Yahoo Finance (used by Macro agent
# to compute the sector tailwind). Sectors not mapped fall back to NIFTY 50.
SECTOR_INDEX_MAP = {
    "IT":             "^CNXIT",
    "BANKS":          "^NSEBANK",
    "NBFC/FINANCIALS":"NIFTY_FIN_SERVICE.NS",
    "INSURANCE":      "NIFTY_FIN_SERVICE.NS",
    "AUTO":           "^CNXAUTO",
    "PHARMA":         "^CNXPHARMA",
    "HEALTHCARE":     "^CNXPHARMA",
    "FMCG":           "^CNXFMCG",
    "CONSUMER":       "^CNXFMCG",
    "RETAIL":         "^CNXFMCG",
    "ENERGY":         "^CNXENERGY",
    "OIL & GAS":      "^CNXENERGY",
    "POWER":          "^CNXENERGY",
    "METALS":         "^CNXMETAL",
    "CEMENT":         "^CNXINFRA",
    "INFRA":          "^CNXINFRA",
    "LOGISTICS":      "^CNXINFRA",
    "DEFENCE":        "^CNXINFRA",
    "CAPITAL GOODS":  "^CNXINFRA",
    "DIVERSIFIED":    "^CNXINFRA",
    "MEDIA":          "^CNXMEDIA",
    "REALTY":         "^CNXREALTY",
    "TELECOM":        None,   # no free sector index - benchmark = NIFTY 50
    "AVIATION":       None,
}

# Free RSS news feeds (market-level). Per-symbol news comes from Google News RSS.
MARKET_RSS_FEEDS = [
    ("Economic Times - Top Stories",
     "https://economictimes.indiatimes.com/rssfeedstopstories.cms"),
    ("Economic Times - Markets",
     "https://economictimes.indiatimes.com/markets/rssfeeds/1977021501.cms"),
    ("Moneycontrol - Buzzing Stocks",
     "https://www.moneycontrol.com/rss/buzzingstocks.xml"),
    ("Moneycontrol - Business",
     "https://www.moneycontrol.com/rss/business.xml"),
    ("Business Standard - Markets",
     "https://www.business-standard.com/rss/markets-106.rss"),
]

# Agent weights used by the Mother Agent's composite conviction score.
# Must sum to 1.0.
COMPOSITE_WEIGHTS = {
    "technical": 0.35,
    "fundamental": 0.20,
    "news": 0.15,
    "sector_macro": 0.15,
    "risk": 0.15,
}


@dataclass
class Config:
    """All tunable knobs of the research pipeline."""

    # -- universe / scope ---------------------------------------------------
    scope: str = "NIFTY_100"          # NIFTY_50 | NIFTY_100 | CUSTOM
    custom_symbols: str = ""          # comma / newline separated, used when scope=CUSTOM
    period: str = "1y"                # price history window for indicators
    min_rows: int = 140               # min daily bars required to analyse a stock

    # -- pipeline sizing ----------------------------------------------------
    shortlist_size: int = 12          # names taken into the deep-dive stage
    max_picks: int = 2                # hard cap mandated by the system spec

    # -- conviction gates (Mother Agent) -------------------------------------
    min_conviction: float = 68.0      # composite score needed to be published
    min_tech_score: float = 55.0      # technical agent minimum to be eligible
    min_risk_score: float = 45.0      # risk agent minimum to be eligible

    # -- liquidity / tradability --------------------------------------------
    adv_min_cr: float = 75.0          # min 20-day avg daily turnover in Rs crore
    fx_fallback: float = 90.0         # USD/INR fallback if live quote unavailable

    # -- position sizing (Risk Agent) ----------------------------------------
    capital: float = 100_000.0        # trading capital (Rs)
    risk_per_trade_pct: float = 1.5   # max % of capital lost at stop
    max_position_pct: float = 25.0    # max % of capital in a single position

    # -- horizon --------------------------------------------------------------
    max_hold_days: int = 28           # calendar-day horizon cap (4 weeks)

    # -- news / sentiment ------------------------------------------------------
    news_days: int = 14               # lookback for stock news
    news_max_per_symbol: int = 25     # max headlines analysed per symbol

    # -- macro ------------------------------------------------------------------
    fii_sessions: int = 5             # FII/DII sessions aggregated

    # -- misc ---------------------------------------------------------------------
    demo: bool = False                # DEMO mode: synthetic data, clearly labelled
    request_pause: float = 0.25       # polite pause between per-ticker API calls

    def weights(self) -> dict:
        return dict(COMPOSITE_WEIGHTS)

    def summary(self) -> dict:
        return {
            "scope": self.scope, "period": self.period,
            "shortlist_size": self.shortlist_size, "max_picks": self.max_picks,
            "min_conviction": self.min_conviction,
            "min_tech_score": self.min_tech_score,
            "min_risk_score": self.min_risk_score,
            "adv_min_cr": self.adv_min_cr,
            "capital": self.capital,
            "risk_per_trade_pct": self.risk_per_trade_pct,
            "max_position_pct": self.max_position_pct,
            "max_hold_days": self.max_hold_days,
            "demo": self.demo,
        }


def universe_for_scope(cfg: Config) -> list[tuple[str, str, str]]:
    """Return the (symbol, name, sector) list for the configured scope."""
    if cfg.scope == "NIFTY_50":
        return list(UNIVERSE_NIFTY_50)
    if cfg.scope == "CUSTOM":
        out = []
        for tok in cfg.custom_symbols.replace("\n", ",").split(","):
            sym = tok.strip().upper()
            if not sym:
                continue
            if "." not in sym:
                sym += ".NS_YF"  # marker; yf client adds .NS
            out.append((sym.replace(".NS_YF", ""), sym.replace(".NS_YF", ""), "CUSTOM"))
        return out
    return list(UNIVERSE_NIFTY_50) + list(UNIVERSE_NIFTY_NEXT_50)
